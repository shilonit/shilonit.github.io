import xbmc

REFRESH_COMMAND = 'RunPlugin(plugin://plugin.video.tvisrael/?mode=4)'
xbmc.executebuiltin(REFRESH_COMMAND)
xbmc.executebuiltin(f'AlarmClock(tvisrael,{REFRESH_COMMAND},10:00:00,silent,loop)')
