import collections
import filecmp
import json
import os
import re
import shutil
import sys
import time
import xml.etree.ElementTree as ET
from urllib.parse import unquote, urlparse

import epglist as epg
import requests
import user_agent
from import_xbmc import xbmc, xbmcaddon, xbmcgui, xbmcvfs

#########################################################
# Common variables and functions

Addon_ID = "plugin.video.tvisrael"
Addon_Name = "TV Israel"
Addon = xbmcaddon.Addon(Addon_ID)
Addon_Ver = Addon.getAddonInfo("version")
Addon_Path = Addon.getAddonInfo("path")
Addon_Icon = Addon.getAddonInfo("icon")
M3U_Name = "tvisrael.m3u"
epg_name = "epg.xml"
Settings_Name = "settings.xml"
Channels_list = "channel_list.json"
LOGOS_MAX_AGE = 12 * 3600  # 12 hours
user_agent = user_agent.generate_user_agent()

# Define file paths
profile_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
logos_dir = xbmcvfs.translatePath(os.path.join(profile_dir, "logos"))
images_dir = xbmcvfs.translatePath(os.path.join(Addon_Path, "resources", "images"))
m3u_file = os.path.join(profile_dir, M3U_Name)
user_settings = os.path.join(profile_dir, Settings_Name)
main_settings = os.path.join(Addon_Path, "resources", Settings_Name)
channels_path = os.path.join(profile_dir, Channels_list)
app_logo = os.path.join(images_dir, "tv.jpg")
epg_file = os.path.join(profile_dir, epg_name)
github_base = "https://raw.githubusercontent.com/shilonit"
github_epg = f"{github_base}/epgtools/main/sport/{epg_name}.gz"
github_chlist = f"{github_base}/epgtools/main/sport/{Channels_list}"

##########################################################

# Make sure profile directory exists
if not os.path.exists(profile_dir):
    os.makedirs(profile_dir)

channels_cache = None


def load_channels():
    global channels_cache
    if channels_cache is not None:
        return channels_cache
    try:
        with open(channels_path, "r", encoding="utf-8") as f:
            channels_cache = json.load(f)
        return channels_cache
    except (FileNotFoundError, OSError, ValueError, TypeError, UnicodeError) as e:
        xbmc.log(f"[main] Failed loading channel_list.json: {e}", xbmc.LOGERROR)
        channels_cache = []
        return channels_cache


channels_loaded = load_channels()


# Utility function to safely get handle from arguments
def get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


# Get Addon_Icon full path
def get_addon_icon(Addon_Icon):
    return os.path.join(images_dir, Addon_Icon)


# Check if an addon is installed
def is_addon_installed(addonid):
    return xbmc.getCondVisibility(f"System.HasAddon({addonid})")


# Install addon
def install_addon(addonid):
    xbmc.executebuiltin(f"InstallAddon({addonid})")


# Check if addon is enabled
def is_addon_enabled(addonid):
    try:
        json_request = (
            f'{{"jsonrpc":"2.0",'
            f'"method":"Addons.GetAddonDetails",'
            f'"params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'
        )
        response = json.loads(xbmc.executeJSONRPC(json_request))

        return response["result"]["addon"]["enabled"]
    except json.JSONDecodeError:
        return False


# Get localized string
def get_locale_string(id):
    return Addon.getLocalizedString(id)


# Get label color
def get_label_color(text, key_color=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(key_color)
    if bold:
        text = f"[B]{text}[/B]"
    return text if color == "none" else f"[COLOR {color}]{text}[/COLOR]"


# Read and return settings from addon
def get_addon_setting(key):
    return Addon.getSetting(key)


# Read a list from a file
def read_list(fileName):
    try:
        with open(fileName, "r", encoding="utf-8") as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except (OSError, UnicodeError, ValueError, TypeError) as ex:
        xbmc.log(str(ex), 3)
        return []


# Escape XML special characters
def escape_xml(text):
    if isinstance(text, bytes):
        text = text.decode("utf-8")
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


# Check if file is older than a given threshold
def is_file_old(filename, deltaInSec=10800):
    last_update = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - last_update) > deltaInSec


# Get text content from a file
def get_text_file(filename):
    if os.path.isfile(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    return ""


def clean_user_settings():
    active_keys = set()
    try:
        tree = ET.parse(main_settings)
        root = tree.getroot()
        for category in root.findall("category"):
            for setting in category.findall("setting"):
                sid = setting.get("id")
                if sid:
                    active_keys.add(sid)
    except (FileNotFoundError, OSError, ET.ParseError) as e:
        xbmc.log(f"Error reading resource settings file: {e}", xbmc.LOGERROR)
        return
    try:
        with open(user_settings, "r", encoding="utf-8") as f:
            content = f.read()
        pattern = r'<setting id="([^"]+)"[^>]*?(?:>(.*?)</setting>|/>)'
        content = re.sub(
            pattern, lambda m: m.group(0) if m.group(1) in active_keys else "", content
        )
        # Remove empty lines
        cleaned_lines = [line for line in content.splitlines() if line.strip()]
        final_content = "\n".join(cleaned_lines) + "\n"
        with open(user_settings, "w", encoding="utf-8") as f:
            f.write(final_content)
        xbmc.log("Unused settings cleaned successfully", xbmc.LOGINFO)
    except (OSError, UnicodeError, ValueError) as e:
        xbmc.log(f"Error cleaning user settings: {e}", xbmc.LOGERROR)


# Check if the links file is old and needs to be updated
def update_epg_files():
    # Convert hours to seconds
    epg_delta_sec = Addon.getSettingInt("update_EPG_interval") * 3600
    if is_file_old(epg_file, epg_delta_sec):
        xbmc.log("[update_epg_files] Updating EPG file", xbmc.LOGDEBUG)
        try:
            epg.fetch_and_build_epg()
        except (AttributeError, OSError, ValueError, TypeError) as e:
            xbmc.log(f"Failed to update EPG file: {e}", xbmc.LOGERROR)


# Get channel name based on current language
def get_local_lang_name(item):
    lang = xbmc.getLanguage(xbmc.ISO_639_1)
    key = f"name_{lang}"
    if key in item:
        return item[key]
    # Fallback to English
    return item.get("name_en", "")


# Get visible channels - exclude channels set to false
def get_visible_channels():
    visible = []
    for channel in channels_loaded:
        tvgid = channel.get("tvgid")
        if tvgid and get_addon_setting(tvgid) != "false":
            visible.append(channel)
    return visible


# Create IPTV files and launch the addon
# Returns True if the M3U changed. With restart=False the caller restarts the client.
def make_iptv_files(show_progress=False, restart=True):
    token = get_addon_setting("user_token")
    if not token:
        xbmc.log("[IPTV] No user token – skipping IPTV build", xbmc.LOGWARNING)
        return False
    return epg.generate_iptv_list(
        get_visible_channels(), show_progress=show_progress, restart=restart
    )


def get_playlist_url_and_access_key(reset_token=True):
    access_key = Addon.getSetting("access_key").strip()
    if not access_key:
        notify(30700, 30714)
        return None, None
    if reset_token:
        Addon.setSetting("user_token", "")
    playlist_url = f"http://af-play.com/playlist/{access_key}.m3u8"
    xbmc.log(f"[Playlist] Generated URL: {playlist_url}", xbmc.LOGDEBUG)
    return playlist_url, access_key


# Download channel logos based on the playlist
# max_age (seconds): skip if the logos folder was refreshed.
def download_channel_logos(silent=False, max_age=None):
    if max_age and os.path.isdir(logos_dir):
        age = time.time() - os.path.getmtime(logos_dir)
        if age < max_age:
            xbmc.log(
                f"[Logos] Refreshed {age / 3600:.1f}h ago - skipping download",
                xbmc.LOGDEBUG,
            )
            return False
    if silent and not Addon.getSetting("access_key").strip():
        return False
    if not silent:
        notify(30702, 30611)
    playlist_url, _ = get_playlist_url_and_access_key(reset_token=False)

    if not playlist_url:
        xbmc.log("[Logos] No access_key – cannot download logos", xbmc.LOGWARNING)
        return False

    headers = {"User-Agent": user_agent}
    try:
        r = requests.get(playlist_url, headers=headers, timeout=15)
        r.raise_for_status()
        text = r.text
    except requests.RequestException as e:
        xbmc.log(f"[Logos] Failed to fetch playlist: {e}", xbmc.LOGERROR)
        return False

    # Download into a temp folder
    tmp_dir = logos_dir + "_tmp"
    shutil.rmtree(tmp_dir, ignore_errors=True)
    os.makedirs(tmp_dir)

    playlist_to_internal_tvgid = {}
    for ch in channels_loaded:
        nid = ch.get("nid")
        internal_tvgid = ch.get("tvgid")
        if nid and internal_tvgid:
            playlist_to_internal_tvgid[nid] = internal_tvgid

    downloaded = 0
    failed = 0

    for line in text.splitlines():
        line = line.strip()
        if 'tvg-logo="' in line:
            start = line.find('tvg-logo="') + len('tvg-logo="')
            end = line.find('"', start)
            logo_url = line[start:end]

            tvg_start = line.find('tvg-id="') + len('tvg-id="')
            tvg_end = line.find('"', tvg_start)
            playlist_tvgid = line[tvg_start:tvg_end].strip()

            if not playlist_tvgid:
                continue

            internal_tvgid = playlist_to_internal_tvgid.get(playlist_tvgid)
            if not internal_tvgid:
                xbmc.log(
                    f"[Logos] No internal tvgid found for playlist tvg-id: {playlist_tvgid}",
                    xbmc.LOGWARNING,
                )
                continue

            ext = os.path.splitext(urlparse(logo_url).path)[1]
            if not ext:
                ext = ".png"

            filename = f"{internal_tvgid}{ext}"
            local_path = os.path.join(tmp_dir, filename)
            try:
                img_r = requests.get(logo_url, headers=headers, timeout=10, stream=True)
                img_r.raise_for_status()
                with open(local_path, "wb") as f:
                    f.writelines(img_r.iter_content(8192))
                xbmc.log(
                    f"[Logos] Saved as internal tvgid: {filename} (from {playlist_tvgid})",
                    xbmc.LOGDEBUG,
                )
                downloaded += 1
            except (requests.RequestException, OSError, ValueError) as e:
                xbmc.log(
                    f"[Logos] Failed {internal_tvgid} ({playlist_tvgid}): {e}",
                    xbmc.LOGWARNING,
                )
                failed += 1
    xbmc.log(f"[Logos] Finished: {downloaded} saved, {failed} failed", xbmc.LOGINFO)

    if downloaded == 0:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        xbmc.log(
            "[Logos] Nothing downloaded - keeping the existing logos", xbmc.LOGWARNING
        )
        return False

    # Logos whose content changed
    changed = set()
    for name in os.listdir(tmp_dir):
        old_path = os.path.join(logos_dir, name)
        if not os.path.isfile(old_path) or not filecmp.cmp(
            old_path, os.path.join(tmp_dir, name), shallow=False
        ):
            changed.add(name)

    # Keep old logos that failed
    if os.path.isdir(logos_dir):
        for name in os.listdir(logos_dir):
            if not os.path.exists(os.path.join(tmp_dir, name)):
                shutil.copy2(os.path.join(logos_dir, name), tmp_dir)
    old_dir = logos_dir + "_old"
    shutil.rmtree(old_dir, ignore_errors=True)
    if os.path.isdir(logos_dir):
        os.rename(logos_dir, old_dir)
    os.rename(tmp_dir, logos_dir)
    os.utime(logos_dir)
    shutil.rmtree(old_dir, ignore_errors=True)

    if changed:
        clear_logo_textures(changed)

    if not silent:
        notify(30702, 30612)
    return True


# Removes cached textures
def clear_logo_textures(file_names):
    names = {n.lower() for n in file_names}
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Textures.GetTextures",
        "params": {
            "properties": ["url"],
            # Matches plain, Windows and URL-encoded (image://) paths alike
            "filter": {"field": "url", "operator": "contains", "value": Addon_ID},
        },
    }
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (TypeError, ValueError, RuntimeError) as e:
        xbmc.log(f"[Logos] Failed reading texture cache: {e}", xbmc.LOGERROR)
        return
    removed = 0
    for texture in resp.get("result", {}).get("textures", []):
        url = unquote(texture.get("url", "")).replace("\\", "/").lower()
        if "/logos/" not in url or url.rstrip("/").rsplit("/", 1)[-1] not in names:
            continue
        xbmc.executeJSONRPC(
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "Textures.RemoveTexture",
                    "params": {"textureid": texture["textureid"]},
                }
            )
        )
        removed += 1
    xbmc.log(
        f"[Logos] {len(names)} logos changed, {removed} cached textures cleared",
        xbmc.LOGINFO,
    )


# Fetch the playlist and extract the user token, then save it in settings
def update_epg():
    update_epg_files()
    make_iptv_files()


# Download channel logos and save with internal tvgid as filename
def update_channels():
    download_channel_logos()
    settings_changed = epg.set_iptv_client_settings(restart=False)
    clean_user_settings()
    notify(30702, 30420)
    update_epg_files()
    m3u_changed = make_iptv_files(restart=False)
    # A single restart applies both the settings and the M3U changes
    if settings_changed or m3u_changed:
        epg.restart_pvr_client()


def channel_list_features():
    local_path = os.path.join(profile_dir, Channels_list)
    try:
        r = requests.get(github_chlist, timeout=10)
        r.raise_for_status()
        remote_data = r.json()
        remote_version = remote_data[0].get("version") if remote_data else "0"
        local_version = "0"
        # If local file exists, read its version
        if os.path.isfile(local_path):
            try:
                with open(local_path, "r", encoding="utf-8") as f:
                    local_data = json.load(f)
                    local_version = (
                        local_data[0].get("version", "0") if local_data else "0"
                    )
            except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
                xbmc.log(
                    f"[Settings] Failed reading local channel_list.json: {exc}",
                    xbmc.LOGWARNING,
                )

        # Check if category is empty (no channels) - run after add-on update.
        def is_category_empty():
            try:
                with open(main_settings, "r", encoding="utf-8") as f:
                    content = f.read()
                start = content.find('<category label="30504">')
                end = content.find("</category>", start)
                if start == -1 or end == -1:
                    return True
                inner = content[start:end]
                return 'id="' not in inner
            except (OSError, ValueError, TypeError) as exc:
                xbmc.log(
                    f"[Settings] Failed checking channel category state: {exc}",
                    xbmc.LOGWARNING,
                )
                return True

        # If versions match but category is empty, regenerate channels.
        if remote_version == local_version and local_version != "0":
            if not is_category_empty():
                xbmc.log(
                    f"[Settings] channel_list version {remote_version} - no change",
                    xbmc.LOGINFO,
                )
                update_epg()
                return False
            else:
                xbmc.log(
                    "[Settings] category empty - regenerating despite same version",
                    xbmc.LOGINFO,
                )
        # If remote version is newer or category is empty, update local file and settings
        with open(local_path, "w", encoding="utf-8") as f:
            json.dump(remote_data, f, ensure_ascii=False, indent=2)
        channels = remote_data[1:]
        new_category = (
            '<category label="30504">\n		<setting type="lsep" label="30505" />\n'
        )
        for ch in channels:
            tvgid = ch.get("tvgid")
            name = get_local_lang_name(ch)
            if tvgid and name:
                new_category += f'		<setting id="{tvgid}" type="bool" label="{name}" default="true" />\n'
        new_category += "	</category>"
        with open(main_settings, "r", encoding="utf-8") as f:
            content = f.read()
        start = content.find('<category label="30504">')
        end = content.find("</category>", start) + len("</category>")
        if start == -1 or end == -1:
            xbmc.log("[Settings] Could not find category 30504", xbmc.LOGERROR)
            return
        new_content = content[:start] + new_category + content[end:]
        with open(main_settings, "w", encoding="utf-8") as f:
            f.write(new_content)
        xbmc.log(
            f"[Settings] Generated {len(channels)} dynamic channels (version {remote_version})",
            xbmc.LOGINFO,
        )
        update_channels()
        return True
    except (
        OSError,
        ValueError,
        TypeError,
        KeyError,
        IndexError,
        AttributeError,
        requests.RequestException,
        json.JSONDecodeError,
    ) as e:
        xbmc.log(f"[Settings] Failed to generate channel settings: {e}", xbmc.LOGERROR)


def notify(
    title_id: int,
    message_id: int,
    duration: int = 2500,
    icon: str | None = None,
) -> None:
    title = get_locale_string(title_id)
    message = get_locale_string(message_id)
    # app_logo default
    if icon is None:
        icon = app_logo
    xbmc.executebuiltin(f'Notification({title}, {message}, {duration}, "{icon}")')


# Compare two version strings
def compare_versions(v1, v2):
    parts1 = list(map(int, v1.split(".")))
    parts2 = list(map(int, v2.split(".")))
    return parts1 > parts2


# Check for updates and notify if available
def check_version(startup=False):
    url = f"{github_base}/shilonit.github.io/master/addons.xml"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:

        xbmc.log(
            f"[check_version] Error fetching addons.xml: {e} (URL: {url})",
            xbmc.LOGERROR,
        )
        return

    pattern = rf'<addon id="{Addon_ID}".*?version="([\d\.]+)"'
    match = re.search(pattern, response.text)
    if not match:
        xbmc.log("[check_version] Failed to find version in addons.xml", xbmc.LOGERROR)
        return

    remote_version = match.group(1)
    if compare_versions(remote_version, Addon_Ver):
        notify(30703, 30712)
        xbmc.executebuiltin("UpdateAddonRepos()")
        return

    xbmc.log(f"[check_version] No update available. startup={startup}", xbmc.LOGDEBUG)

    # If the version is up-to-date and NOT in startup mode, notify the user
    if not startup:
        notify(30702, 30713)


def open_window(epg_file):
    dialog = xbmcgui.WindowXMLDialog(epg_file, Addon_Path)
    dialog.doModal()
    del dialog
