import bisect
import glob
import gzip
import io
import itertools
import json
import os
import re
import time
from collections import defaultdict
from datetime import datetime, timezone
from xml.etree import ElementTree as ET

import common
import requests
from import_xbmc import xbmc, xbmcaddon, xbmcgui, xbmcvfs


def get_af_base():
    server_choice = common.Addon.getSettingInt("server")
    servers = {
        0: "bethoven",
        1: "chopin",
        2: "tchaikovsky",
    }
    return f"http://{servers[server_choice]}.af-stream.com:8080"


AF_EPG_URL = "http://af-play.com/xmltv.xml.gz"
EPG_PAST_DAYS = 7
IPTV_ADDON_ID = "pvr.iptvsimple"
IPTV_NAME = "IPTV Simple Client"


# Downloads an XMLTV file from the given URL and returns the raw bytes.
def download_xmltv(url, timeout=60):
    try:
        r = requests.get(
            url, headers={"User-Agent": common.user_agent}, timeout=timeout
        )
        r.raise_for_status()
        raw = r.content
        if raw[:2] == b"\x1f\x8b":  # gzip magic
            raw = gzip.decompress(raw)
        if not raw.lstrip().startswith(b"<"):
            xbmc.log(
                f"[EPG] Invalid XML from {url}, first bytes={raw[:100]!r}",
                xbmc.LOGERROR,
            )
            return None
        xbmc.log(f"[EPG] Downloaded {url} xml bytes={len(raw)}", xbmc.LOGDEBUG)
        return raw
    except (
        requests.RequestException,
        OSError,
        EOFError,
        ValueError,
        TypeError,
    ) as e:
        xbmc.log(f"[EPG] Failed downloading {url}: {e}", xbmc.LOGERROR)
        return None


# Converts an XMLTV time to a Unix timestamp.
def parse_xmltv_time(value):
    if not value:
        return None
    value = value.strip()
    try:
        return datetime.strptime(value, "%Y%m%d%H%M%S %z").timestamp()
    except ValueError:
        pass
    try:
        return (
            datetime.strptime(value[:14], "%Y%m%d%H%M%S")
            .replace(tzinfo=timezone.utc)
            .timestamp()
        )
    except ValueError:
        return None


# Streams through an XMLTV document and keeps only channels/programmes
# whose channel id passes keep(). Keeps memory low on large files.
def parse_xmltv(raw, keep):
    channels, programmes = {}, []
    root = None
    for event, elem in ET.iterparse(io.BytesIO(raw), events=("start", "end")):
        if event == "start":
            if root is None:
                root = elem
            continue
        if elem.tag == "channel":
            if keep(elem.get("id")):
                channels[elem.get("id")] = elem
        elif elem.tag == "programme":
            if keep(elem.get("channel")):
                programmes.append(elem)
        else:
            continue
        try:
            root.remove(elem)  # release the parsed element from the tree
        except ValueError:
            pass
    return channels, programmes


def strip_lang(prog):
    for elem in prog.findall("title") + prog.findall("desc"):
        elem.attrib.pop("lang", None)


# Per-channel index of accepted programmes for fast overlap checks:
# sorted starts + running maximum of ends (handles overlapping source data).
def build_overlap_index(accepted):
    index = {}
    for tvgid, items in accepted.items():
        ranges = sorted((s, e) for s, e, _ in items)
        index[tvgid] = (
            [r[0] for r in ranges],
            list(itertools.accumulate((r[1] for r in ranges), max)),
        )
    return index


# True if [start, stop) overlaps any range in the channel index.
def overlaps(start, stop, channel_index):
    if not channel_index:
        return False
    starts, max_ends = channel_index
    i = bisect.bisect_left(starts, stop)  # ranges[:i] start before our stop
    return i > 0 and max_ends[i - 1] > start


# Reads programmes from raw XMLTV as (tvgid, start, stop, element).
# to_tvgid maps the source channel id to our tvgid (None = skip);
# keep(start, stop) filters by time.
def read_programmes(raw, to_tvgid, keep):
    channels, progs = parse_xmltv(raw, lambda cid: to_tvgid(cid) is not None)
    items = []
    for p in progs:
        start = parse_xmltv_time(p.get("start"))
        if start is None:
            continue
        stop = parse_xmltv_time(p.get("stop")) or start + 1
        if not keep(start, stop):
            continue
        tvgid = to_tvgid(p.get("channel"))
        p.set("channel", tvgid)
        items.append((tvgid, start, stop, p))
    return channels, items


# Merges EPG layers by priority. A programme is added only if it doesn't overlap
# a programme from a higher-priority layer on the same channel:
#   1. previous_raw - our existing file, finished programmes only (past data is kept)
#   2. primary_raw  - common.github_epg (keyed by tvgid)
#   3. secondary_raw - AF EPG (keyed by nid)
# Programmes that ended more than EPG_PAST_DAYS ago are dropped.
def merge_epg(primary_raw, secondary_raw, channels, previous_raw=None):
    nid_to_tvgid = {
        ch["nid"]: ch["tvgid"] for ch in channels if ch.get("nid") and ch.get("tvgid")
    }
    tvgids = [ch["tvgid"] for ch in channels if ch.get("tvgid")]
    tvgid_set = set(tvgids)
    now = time.time()
    min_ts = now - EPG_PAST_DAYS * 86400

    def own_id(cid):
        return cid if cid in tvgid_set else None

    def in_window(start, stop):
        return stop >= min_ts

    def finished(start, stop):
        return min_ts <= stop <= now

    layers = []
    channel_elems = {}
    if previous_raw:
        try:
            chs, items = read_programmes(previous_raw, own_id, finished)
            layers.append(("previous", items))
            channel_elems.update(chs)
        except ET.ParseError as e:
            xbmc.log(f"[EPG] Ignoring invalid existing EPG: {e}", xbmc.LOGWARNING)
    if primary_raw:
        chs, items = read_programmes(primary_raw, own_id, in_window)
        layers.append(("primary", items))
        channel_elems.update(chs)
    if secondary_raw:
        _, items = read_programmes(secondary_raw, nid_to_tvgid.get, in_window)
        for item in items:
            strip_lang(item[3])
        layers.append(("af", items))

    accepted = defaultdict(list)  # tvgid -> [(start, stop, element)]
    stats = []
    for name, items in layers:
        index = build_overlap_index(accepted)
        added = dropped = 0
        for tvgid, start, stop, p in items:
            if overlaps(start, stop, index.get(tvgid)):
                dropped += 1
                continue
            accepted[tvgid].append((start, stop, p))
            added += 1
        stats.append(f"{name}={added} (overridden {dropped})")

    root = ET.Element("tv", {"generator-info-name": common.Addon_ID})
    for ch in channels:
        tvgid = ch.get("tvgid")
        if not tvgid:
            continue
        ch_elem = channel_elems.get(tvgid)
        if ch_elem is None:
            ch_elem = ET.Element("channel", {"id": tvgid})
            ET.SubElement(ch_elem, "display-name").text = (
                common.get_local_lang_name(ch) or tvgid
            )
        root.append(ch_elem)

    total = 0
    for tvgid in tvgids:
        for _, _, p in sorted(accepted.get(tvgid, []), key=lambda x: x[0]):
            root.append(p)
            total += 1

    xbmc.log(f"[EPG] Merged {total} programmes: {', '.join(stats)}", xbmc.LOGINFO)
    return root, total


# Fetches both EPG sources, merges them and saves the result to common.epg_file.
# The refresh interval is checked by the caller (common.update_epg_files);
# force=True marks a manual refresh from settings.
# No PVR restart here: IPTV Simple re-reads the file on its own refresh timer
# (m3uRefreshMode=1) and then triggers a full EPG update in Kodi for every channel.
def fetch_and_build_epg(force=False, notify=None):
    if common.get_addon_setting("use_IPTV") != "true":
        return
    if notify is None:
        notify = force

    # Only channels that are shown - hidden channels have no stream in the M3U
    channels = common.get_visible_channels()
    if not channels:
        return

    primary_raw = download_xmltv(common.github_epg)
    secondary_raw = download_xmltv(AF_EPG_URL, timeout=90)
    if not primary_raw and not secondary_raw:
        xbmc.log(
            "[EPG] Both EPG sources failed - keeping the existing file", xbmc.LOGERROR
        )
        return

    # The existing file keeps priority for past programmes
    previous_raw = None
    if os.path.isfile(common.epg_file):
        try:
            with open(common.epg_file, "rb") as f:
                previous_raw = f.read()
        except OSError as e:
            xbmc.log(f"[EPG] Failed reading existing EPG: {e}", xbmc.LOGWARNING)

    try:
        root, total = merge_epg(primary_raw, secondary_raw, channels, previous_raw)
    except (AttributeError, KeyError, TypeError, ValueError, ET.ParseError) as e:
        xbmc.log(f"[EPG] Failed merging EPG due to invalid data: {e}", xbmc.LOGERROR)
        return
    if total == 0:
        xbmc.log(
            "[EPG] Merged EPG is empty - keeping the existing file", xbmc.LOGWARNING
        )
        return

    # Write to a temp file and swap atomically, so IPTV Simple never reads a half-written file
    tmp_file = common.epg_file + ".tmp"
    try:
        ET.ElementTree(root).write(tmp_file, encoding="utf-8", xml_declaration=True)
        os.replace(tmp_file, common.epg_file)
        xbmc.log(
            "[EPG] EPG XML saved successfully - IPTV Simple will load it on its next auto refresh",
            xbmc.LOGINFO,
        )
        if notify:  # manual refresh from settings
            common.notify(30702, 30408)
    except (OSError, TypeError, ValueError) as e:
        xbmc.log(f"[EPG] Failed writing EPG XML: {e}", xbmc.LOGERROR)
        try:
            os.remove(tmp_file)
        except OSError:
            pass


# Global flag to prevent multiple simultaneous IPTV refreshes
pvr_refreshing = False


def jsonrpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        request["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (TypeError, ValueError, RuntimeError):
        return {}


def is_iptv_enabled():
    resp = jsonrpc(
        "Addons.GetAddonDetails", {"addonid": IPTV_ADDON_ID, "properties": ["enabled"]}
    )
    return bool(resp.get("result", {}).get("addon", {}).get("enabled"))


def set_iptv_enabled(enabled, timeout=8000, check_interval=250):
    resp = jsonrpc(
        "Addons.SetAddonEnabled", {"addonid": IPTV_ADDON_ID, "enabled": enabled}
    )
    if resp.get("result") != "OK":
        xbmc.log(
            f"[restart_pvr_client] SetAddonEnabled({enabled}) failed: {resp}",
            xbmc.LOGERROR,
        )
        return False
    waited = 0
    while waited < timeout:
        if is_iptv_enabled() == enabled:
            return True
        xbmc.sleep(check_interval)
        waited += check_interval
    xbmc.log(
        f"[restart_pvr_client] Timeout waiting for enabled={enabled}", xbmc.LOGWARNING
    )
    return False


def is_pvr_playing():
    return xbmc.getCondVisibility(
        "PVR.IsPlayingTv | PVR.IsPlayingRadio | PVR.IsPlayingRecording"
    )


# Restarts IPTV Simple Client (disable + enable via JSON-RPC)
# Note: this restarts ALL IPTV Simple instances and the PVR Manager.
def restart_pvr_client(show_progress=False):
    global pvr_refreshing
    xbmc.log(
        f"[restart_pvr_client] {IPTV_NAME} Starting (show_progress={show_progress})",
        xbmc.LOGDEBUG,
    )

    if pvr_refreshing:
        xbmc.log(
            "[restart_pvr_client] Refresh already in progress - skipping", xbmc.LOGDEBUG
        )
        return False

    if is_pvr_playing():
        xbmc.log(
            "[restart_pvr_client] PVR is playing - restart postponed, "
            "IPTV Simple auto refresh will load the new files",
            xbmc.LOGINFO,
        )
        return False

    pvr_refreshing = True
    progress = None
    show_toast = not xbmc.Player().isPlaying()
    if not show_toast:
        show_progress = False
    try:
        if show_progress:
            progress = xbmcgui.DialogProgress()
            progress.create(
                common.get_locale_string(30403), common.get_locale_string(30423)
            )
            progress.update(
                33, common.get_locale_string(30424).format(step="1", IPTV=IPTV_NAME)
            )

        ok = set_iptv_enabled(False)
        xbmc.sleep(1000)
        ok = set_iptv_enabled(True) and ok

        if show_progress:
            progress.update(
                66, common.get_locale_string(30425).format(step="2", IPTV=IPTV_NAME)
            )

        ok = wait_for_pvr(timeout=60000) and ok
        if show_toast:
            common.notify(30702, 30421 if ok else 30422)
        return ok
    except (
        AttributeError,
        KeyError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as e:
        xbmc.log(
            f"[restart_pvr_client] Failed to restart {IPTV_NAME}: {e}", xbmc.LOGERROR
        )
        # Never leave the client disabled
        if not is_iptv_enabled():
            set_iptv_enabled(True)
        if show_toast:
            common.notify(30702, 30422)
        return False
    finally:
        if progress:
            progress.close()
        pvr_refreshing = False


# Waits until the PVR Manager is started and channels are loaded.
def wait_for_pvr(timeout=60000, check_interval=500):
    start_time = time.time()
    xbmc.log("[wait_for_pvr] Waiting for PVR Manager and channels...", xbmc.LOGDEBUG)
    monitor = xbmc.Monitor()

    while (time.time() - start_time) * 1000 < timeout:
        props = jsonrpc("PVR.GetProperties", {"properties": ["available"]})
        if props.get("result", {}).get("available"):
            data = jsonrpc("PVR.GetChannels", {"channelgroupid": "alltv"})
            channel_count = len(data.get("result", {}).get("channels", []))
            if channel_count > 0:
                xbmc.log(
                    f"[wait_for_pvr] PVR ready - {channel_count} channels "
                    f"after {time.time() - start_time:.1f}s",
                    xbmc.LOGDEBUG,
                )
                return True
        if monitor.waitForAbort(check_interval / 1000):
            return False
    xbmc.log("[wait_for_pvr] Timeout - PVR not ready", xbmc.LOGWARNING)
    return False


# Generates the IPTV list in M3U format.
# Returns True if the list changed. With restart=False the caller restarts the client.
def generate_iptv_list(videos, show_progress=False, restart=True):
    iptv_list = '#EXTM3U catchup-type="shift"\n'

    for video in videos:
        try:
            tvg_id = video.get("tvgid", "")
            if tvg_id:
                logo_filename = f"{tvg_id}.png"
                tvg_logo = f"special://userdata/addon_data/{common.Addon_ID}/logos/{logo_filename}"
            else:
                tvg_logo = ""
            view_name = common.get_local_lang_name(video)
            group = f' group-title="{common.get_locale_string(30300)}"'
            url = f'{get_af_base()}/s/{common.get_addon_setting("user_token")}/{video.get("nid", "")}/video.m3u8'
            iptv_list += f'\n#EXTINF:-1 tvg-id="{tvg_id}"{group} tvg-logo="{tvg_logo}" catchup-days="7",{view_name}\n{url}\n'
        except (
            AttributeError,
            KeyError,
            OSError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as ex:
            xbmc.log(
                f'Error processing video {video.get("name", "Unknown")}: {ex}',
                xbmc.LOGERROR,
            )

    # Compare and write the new IPTV list to file if changed
    if not is_list_equal(common.m3u_file, iptv_list):
        xbmc.log(
            "[generate_iptv_list] Channels list changed – applying changes",
            xbmc.LOGDEBUG,
        )
        with open(common.m3u_file, "w", encoding="utf-8") as f:
            f.write(str(iptv_list))
        # A channel was shown again (or added) - rebuild the EPG before the restart
        visible_ids = {v.get("tvgid") for v in videos if v.get("tvgid")}
        missing = visible_ids - epg_channel_ids()
        if missing:
            xbmc.log(f"[EPG] No EPG for {sorted(missing)} - rebuilding", xbmc.LOGINFO)
            fetch_and_build_epg(force=True, notify=False)
        if restart:
            restart_pvr_client(show_progress=show_progress)
        return True
    return False


# Returns the channel ids in the existing EPG file (channels are written first).
def epg_channel_ids():
    ids = set()
    if not os.path.isfile(common.epg_file):
        return ids
    try:
        for _, elem in ET.iterparse(common.epg_file, events=("end",)):
            if elem.tag == "channel":
                ids.add(elem.get("id"))
            elif elem.tag == "programme":
                break  # no more channels after the first programme
    except (ET.ParseError, OSError):
        pass
    return ids


# Checks if the new IPTV list is different from the old one.
def is_list_equal(file_path, new_list):
    if os.path.isfile(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            old_list = f.read()
        return old_list == new_list
    return False


# Enables the IPTV client if not already enabled.
def enable_iptv_client():
    try:
        if not common.is_addon_installed("pvr.iptvsimple"):
            common.install_addon("pvr.iptvsimple")
        if not common.is_addon_enabled("pvr.iptvsimple"):
            xbmc.executebuiltin("EnableAddon(pvr.iptvsimple)")
        return True
    except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as ex:
        xbmc.log(f"Error enabling IPTV client: {ex}", xbmc.LOGERROR)
    return False


# Opens the IPTV client settings.
def open_iptv_client_settings():
    if enable_iptv_client():
        xbmc.executebuiltin("Addon.OpenSettings(pvr.iptvsimple)")


INSTANCE_FILE_RE = re.compile(r"instance-settings-(\d+)\.xml$")


# Returns {index: path} of IPTV Simple instance settings files.
def list_instance_files(profile_dir):
    files = {}
    for path in glob.glob(os.path.join(profile_dir, "instance-settings-*.xml")):
        match = INSTANCE_FILE_RE.search(path)
        if match:
            files[int(match.group(1))] = path
    return files


def read_instance_settings(path):
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as ex:
        xbmc.log(f"[IPTV setup] Cannot read {path}: {ex}", xbmc.LOGWARNING)
        return None
    return {s.get("id"): (s.text or "") for s in root.findall("setting")}


# Finds this plugin's instance file (by instance name or M3U path).
# If none exists, returns a new path with the next free index (Kodi indexes start at 1).
def find_instance_file(profile_dir):
    files = list_instance_files(profile_dir)
    for index in sorted(files):
        values = read_instance_settings(files[index])
        if not values:
            continue
        if (
            values.get("kodi_addon_instance_name") == common.Addon_Name
            or values.get("m3uPath") == common.m3u_file
        ):
            return files[index]
    new_index = max(files, default=0) + 1
    path = os.path.join(profile_dir, f"instance-settings-{new_index}.xml")
    xbmc.log(f"[IPTV setup] Creating new settings file: {path}", xbmc.LOGINFO)
    return path


# Writes the given settings into an instance file. Returns True if anything changed.
def update_instance_file(path, settings):
    root = None
    if os.path.isfile(path):
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as ex:
            xbmc.log(
                f"[IPTV setup] Invalid XML in {path}, recreating: {ex}", xbmc.LOGWARNING
            )
    if root is None or root.tag != "settings":
        root = ET.Element("settings")

    changed = False
    if root.get("version") != "2":
        root.set("version", "2")
        changed = True

    existing = {s.get("id"): s for s in root.findall("setting")}
    for key, val in settings.items():
        elem = existing.get(key)
        if elem is None:
            elem = ET.SubElement(root, "setting", {"id": key})
        elif (elem.text or "") == val:
            continue
        elem.text = val
        elem.attrib.pop("default", None)
        changed = True

    if changed:
        if hasattr(ET, "indent"):
            ET.indent(root, space="    ")
        tmp_path = path + ".tmp"
        ET.ElementTree(root).write(tmp_path, encoding="utf-8")
        os.replace(tmp_path, path)
    return changed


# Sets the IPTV client settings.
# Returns True if the settings changed. With restart=False the caller restarts the client.
def set_iptv_client_settings(restart=True):
    if not enable_iptv_client():
        return False
    settings = {
        "kodi_addon_instance_name": common.Addon_Name,
        "kodi_addon_instance_enabled": "true",
        "m3uPathType": "0",
        "m3uPath": common.m3u_file,
        "epgPathType": "0",
        "epgPath": common.epg_file,
        "startNum": "1",
        "m3uRefreshMode": "1",
        "m3uRefreshIntervalMins": "5",
        "timeshiftEnabled": "true",
        "catchupEnabled": "true",
        "catchupDays": "7",
    }
    try:
        iptv_addon = xbmcaddon.Addon(IPTV_ADDON_ID)
        profile_dir = xbmcvfs.translatePath(iptv_addon.getAddonInfo("profile"))
        os.makedirs(profile_dir, exist_ok=True)
        target_file = find_instance_file(profile_dir)
        if update_instance_file(target_file, settings):
            xbmc.log(
                f"[IPTV setup] Updated IPTV settings in {target_file}", xbmc.LOGINFO
            )
            if restart:
                restart_pvr_client()
            return True
        xbmc.log("[IPTV setup] No changes needed in IPTV settings", xbmc.LOGDEBUG)
    except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as ex:
        xbmc.log(f"[IPTV setup] IPTV setup error: {ex}", xbmc.LOGERROR)
    return False
