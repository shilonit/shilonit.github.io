# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl, urlparse
import xbmcgui, xbmcplugin, xbmc
import resources.lib.common as common
import resources.lib.channels as channels
import resources.lib.epglist as epg

# Global variables
addon_handle = common.GetHandle()
channels_list = channels.Tvs

def get_url(**kwargs):
    return '{0}?{1}'.format(sys.argv[0], urlencode(kwargs))

def CategoriesList():
    xbmcplugin.setPluginCategory(addon_handle, common.GetLabelColor(common.GetLocaleString(30402), bold=True, color="none"))
    xbmcplugin.setContent(addon_handle, 'videos')
    img_tv = common.GetIconFullPath('tv.jpg')
    img_sports = common.GetIconFullPath('sports.jpg')
    channels_name = common.GetLabelColor(common.GetLocaleString(30600), bold=True, color="none")
    settings_name = common.GetLabelColor(common.GetLocaleString(30401), bold=True, color="none")
    list_items = []

    channels_url = get_url(mode=7)
    channels_list_item = xbmcgui.ListItem(label=channels_name)
    channels_list_item.setArt({'thumb': img_sports, 'icon': img_sports, 'fanart': img_sports})
    channels_list_item.setInfo('video', {'title': channels_name, 'genre': channels_name, 'mediatype': 'video'})
    list_items.append((channels_url, channels_list_item, False))

    settings_url = get_url(mode=2)
    settings_list_item = xbmcgui.ListItem(label=settings_name)
    settings_list_item.setArt({'thumb': img_tv, 'icon': img_tv, 'fanart': img_tv})
    settings_list_item.setInfo('video', {'title': settings_name, 'genre': settings_name, 'mediatype': 'video'})
    list_items.append((settings_url, settings_list_item, False))

    xbmcplugin.addDirectoryItems(addon_handle , list_items)
    xbmcplugin.endOfDirectory(addon_handle)

def play_video(channel_id):
    if not channel_id:
        xbmcgui.Dialog().ok('Error', 'Channel ID is missing.')
        return

    channel = next((ch for ch in channels_list if ch['id'] == channel_id), None)
    if not channel:
        xbmcgui.Dialog().ok('Error', f'Channel with ID {channel_id} not found.')
        return

    srv = channel['srv']
    origin = ''

    try:
        if srv == 'top':
            base_url = f'https://topembed.mizhls.ru/lb//{channel_id}/playlist.m3u8'
            origin = 'https://topembed.pw'

        elif srv == 'ddy':
            import requests
            from bs4 import BeautifulSoup 

            url = f'https://dlhd.so/embed/stream-{channel_id}.php'
            response = requests.get(url, stream=True)
            response.raise_for_status()  # Check for HTTP errors

            content_type = response.headers.get('Content-Type', '') # Check content type
            if 'text/html' in content_type:
                # Read and the content
                content = response.text
                soup = BeautifulSoup(content, 'html.parser')
                iframe_tags = soup.find_all('iframe')

                for iframe in iframe_tags:
                    src = iframe.get('src')
                    if src:
                        parsed_url = urlparse(src)
                        origin = f"{parsed_url.scheme}://{parsed_url.netloc}"

            else:
                xbmcgui.Dialog().ok('Error', f'Unexpected content type: {content_type}')
                return

            base_url = f'https://webhdrunns.mizhls.ru/lb/premium{channel_id}/index.m3u8'

        else:
            xbmcgui.Dialog().ok('Error', 'Unsupported server type.')
            return

        headers = {
            'Accept': '*/*',
            'Accept-Language': 'q=0.8,en-US;q=0.5,en;q=0.3',
            'Connection': 'keep-alive',
            'Origin': origin,
            'Referer': origin + '/',
            'User-Agent': common.userAgent
        }

        link = f'{base_url}|{urlencode(headers)}'
        play_item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=True, listitem=play_item)

    except requests.RequestException as e:
        xbmcgui.Dialog().ok('Error', f'Network error: {e}')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'An unexpected error occurred: {e}')

def GetAllChannels():
	userChannels = []
	for channel in channels_list:
		channel['index'] = common.GetIntSetting(channel['nid'], channel['index'])
	sorted_channels  = sorted(channels_list, key=lambda k: k['index']) 
	for channel in sorted_channels:
		if channel['index'] != 0:
			userChannels.append(channel)
	userChannels = sorted(userChannels, key=lambda k: k['index'])
	return userChannels

def MakeIPTVfiles():
	epg.MakeIPTVlist(GetAllChannels())
	if common.isFileOld(common.epgFile):
		epg.GetEPG()
	epg.MakeChannelsGuide()

def first_run():
     MakeIPTVfiles()
     epg.SetIptvClientSettings()
#     sys.exit()

def open_settings():
    xbmc.executebuiltin(f'Addon.OpenSettings({common.AddonID})')

def launch_EPG():
     xbmc.executebuiltin('ActivateWindow(TVGuide,pvr://channels/tv/TVIsrael)')

def open_pvrsettings():
     xbmc.executebuiltin('ActivateWindow(pvrsettings)')

def router(paramstring):
    params = dict(parse_qsl(paramstring))    
    if params:
        mode = params.get('mode')
        url = params.get('url')
        if mode == '-1':
            CategoriesList()
        elif mode == '1' and url:
            play_video(url)
        elif mode == '2':
            open_settings()
        elif mode == '3':
            epg.OpenIptvClientSettings()
            sys.exit()
        elif mode == '4':
            MakeIPTVfiles()
            sys.exit()
        elif mode == '5':
            epg.SetIptvClientSettings()
            sys.exit()
        elif mode == '6':
            epg.GetEPG()
        elif mode == '7':
            launch_EPG()
        elif mode == '8':
            open_pvrsettings()
            sys.exit()
        elif mode == '9':
            first_run()
        else:
            xbmcgui.Dialog().ok('Error', f'Invalid mode value: {mode}')
            sys.exit()
    else:
        CategoriesList()

if __name__ == '__main__':
    router(sys.argv[2][1:])