# -*- coding: utf-8 -*-
import base64, json, re
from typing import Optional, Tuple, Dict
from urllib.parse import urlparse, quote, urlencode

import requests
from bs4 import BeautifulSoup

import common
import channel_list as channels
from import_xbmc import xbmc

# Globals
BASE_URL = "https://daddylive.sx"
TOP_URL = "https://topembed.pw/"
DDY2_URL = "https://lovecdn.ru"

channels_list = channels.Tvs

session = requests.Session()
session.headers.update({"User-Agent": common.user_agent})

# For main.py
SRV_INLINE_HEADERS = {"ddy", "ap2", "top"}

# Config helpers
def get_value(key: str) -> Optional[str]:
    try:
        with open(common.links_path, "r", encoding="utf-8") as f:
            return json.load(f).get(key)
    except Exception as e:
        xbmc.log(f"[get_value] Error reading {key}: {e}", xbmc.LOGERROR)
        return None


def get_url(key: str) -> str:
    global BASE_URL, TOP_URL, DDY2_URL
    m = {"base_url": "BASE_URL", "top_url": "TOP_URL", "ddy2_url": "DDY2_URL"}
    if key in m:
        val = get_value(key)
        if val:
            globals()[m[key]] = val
        return globals()[m[key]]
    return ""


# HTTP helpers
def http_get(
    url: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    allow_redirects: bool = False,
    timeout: int = 15,
    retries: int = 3,
    delay_ms: int = 1000,
) -> Optional[requests.Response]:
    for attempt in range(1, retries + 1):
        try:
            r = session.get(
                url,
                headers=headers or {},
                timeout=timeout,
                allow_redirects=allow_redirects,
            )
            if 400 <= r.status_code:
                r.raise_for_status()
            return r
        except Exception as e:
            xbmc.log(
                f"[http_get] {attempt}/{retries} failed for {url} hdrs={headers}: {e}",
                xbmc.LOGERROR,
            )
            xbmc.sleep(delay_ms)
    xbmc.log(f"[http_get] all {retries} attempts failed for {url}", xbmc.LOGERROR)
    return None


def make_same_origin_headers(origin: str) -> Dict[str, str]:
    o = origin.rstrip("/")
    return {"Origin": o, "Referer": o + "/", "User-Agent": common.user_agent}


# Shared helpers used by DDY/AP/TOP
def extract_first(p: re.Pattern, text: str, name: str) -> str:
    m = p.search(text)
    if not m:
        raise RuntimeError(f"Missing '{name}' in the HTML/JS (pattern not found).")
    return m.groupdict().get("val") or m.group(1)


# DDY/AP/TOP
def build_iframe_url(base_iframe_url: str, srv: str, channel_id: str) -> Optional[str]:
    if not base_iframe_url:
        return None
    base_iframe_url = base_iframe_url.rstrip("/")

    if srv in ("ddy", "ap2"):
        path = "premiumtv/daddyhd.php" if srv == "ddy" else "maxsport.php"
        return f"{base_iframe_url}/{path}?id={channel_id}"
    elif srv == "top":
        return f"{get_url('top_url')}/channel/YesSport{channel_id}[Israel]"
    elif srv == "ddy2":
        return f"{get_url('ddy2_url')}/daddy.php?stream={channel_id}"
    return None


def extract_auth_data(page_content: str) -> dict:
    ck = re.search(r'const\s+CHANNEL_KEY\s*=\s*"([^"]+)"', page_content)
    channel_key = ck.group(1) if ck else None
    xjz = re.search(r'const\s+XJZ\s*=\s*"([^"]+)"', page_content)
    if not xjz:
        return {}
    try:
        decoded_json = base64.b64decode(xjz.group(1)).decode()
        parts = json.loads(decoded_json)
        for k, v in list(parts.items()):
            try:
                val = base64.b64decode(v).decode()
                # Temp fix for DaddyLive change
                if k == "b_script" and val == "a.php":
                    val = "auth.php"
                parts[k] = val
            except Exception:
                pass
        return {
            "channel_key": channel_key,
            "auth_ts": parts.get("b_ts"),
            "auth_rnd": parts.get("b_rnd"),
            "auth_sig": parts.get("b_sig"),
            "auth_url": (parts.get("b_host") or "") + (parts.get("b_script") or ""),
        }
    except Exception as e:
        xbmc.log(f"[extract_auth_data] {e}", xbmc.LOGERROR)
        return {}


def authenticate(
    channel_key,
    auth_ts,
    auth_rnd,
    auth_sig,
    auth_url,
    ddy_final,
    headers: Optional[dict] = None,
) -> bool:
    if not auth_url:
        xbmc.log("[authenticate] missing auth_url", xbmc.LOGERROR)
        return False
    url = f"{auth_url}?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    hdrs = dict(headers or {})
    hdrs["Host"] = ddy_final or ""
    resp = http_get(url, headers=hdrs)
    if not resp:
        return False
    try:
        return resp.json().get("status") == "ok"
    except Exception:
        xbmc.log("authenticate: invalid JSON", xbmc.LOGERROR)
        return False


def get_server_key(channel_key, origin) -> Optional[str]:
    try:
        url = f"{origin}/server_lookup.php?channel_id={channel_key}"
        r = session.get(url, timeout=5)
        if not r.ok:
            xbmc.log(f"get_server_key: HTTP {r.status_code} for {url}", xbmc.LOGERROR)
            return None
        return r.json().get("server_key")
    except Exception as e:
        xbmc.log(f"get_server_key: {e}", xbmc.LOGERROR)
        return None


def build_m3u8_url(channel_key, server_key, dynamic_domain) -> str:
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"


def resolve_ddy_like(channel_id: str, srv: str) -> Tuple[Optional[str], Optional[dict]]:
    base_iframe_url = get_value("iframe_url")
    iframe_url = build_iframe_url(base_iframe_url, srv, channel_id)
    ddy_final = get_value("ddy_final")
    if not iframe_url:
        xbmc.log("[resolve_ddy_like] failed to build iframe_url", xbmc.LOGERROR)
        return None, {}

    # Fetch iframe page ONCE
    resp = http_get(iframe_url)
    if not resp:
        xbmc.log("[resolve_ddy_like] failed to fetch iframe content", xbmc.LOGERROR)
        return None, {}

    page = resp.text or ""
    auth = extract_auth_data(page)
    channel_key = auth.get("channel_key") or (
        "premium" + str(channel_id) if srv == "ddy" else None
    )
    if not channel_key:
        xbmc.log("[resolve_ddy_like] missing channel_key", xbmc.LOGERROR)
        return None, {}

    origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
    if all(auth.get(k) for k in ("auth_ts", "auth_rnd", "auth_sig", "auth_url")):
        hdrs = make_same_origin_headers(origin)
        if not authenticate(
            channel_key,
            auth["auth_ts"],
            auth["auth_rnd"],
            auth["auth_sig"],
            auth["auth_url"],
            ddy_final,
            headers=hdrs,
        ):
            xbmc.log("[resolve_ddy_like] auth failed", xbmc.LOGERROR)
            return None, {}

    server_key = get_server_key(channel_key, origin)
    if not server_key:
        xbmc.log("[resolve_ddy_like] server_key not found", xbmc.LOGERROR)
        return None, {}

    m3u8 = build_m3u8_url(channel_key, server_key, ddy_final)
    return m3u8, make_same_origin_headers(origin)


def get_m3u8_ddy(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    ch = next((c for c in channels_list if c["id"] == channel_id), None)
    srv = ch.get("srv", "ddy") if ch else "ddy"
    return resolve_ddy_like(channel_id, srv)

#  DDY2
EMBED_IFRAME_RE = re.compile(
    r"""src=['"](?P<u>https?://[^"']+/(?P<cid>[^/"']+)/embed\.html\?[^"'#]*?token=(?P<tok>[A-Za-z0-9\-]+)[^"'#]*?)['"]""",
    re.IGNORECASE,
)

def _find_embed_token_src(html: str) -> Optional[Tuple[str, str, str]]:
    m = EMBED_IFRAME_RE.search(html or "")
    if m:
        return m.group("u"), m.group("cid"), m.group("tok")
    try:
        soup = BeautifulSoup(html or "", "html.parser")
        for fr in soup.find_all("iframe"):
            src = fr.get("src") or ""
            if "embed.html" in src and "token=" in src:
                m2 = re.search(r"/([^/]+)/embed\.html", src)
                m3 = re.search(r"[?&]token=([A-Za-z0-9\-]+)", src)
                if m2 and m3:
                    return src, m2.group(1), m3.group(1)
    except Exception:
        pass
    return None


def get_m3u8_ddy2(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    base_iframe_url = get_value("iframe_url")
    iframe_url = build_iframe_url(base_iframe_url, "ddy2", channel_id)
    if not iframe_url:
        xbmc.log("[get_m3u8_ddy2] failed to build iframe_url", xbmc.LOGERROR)
        return None, {}
    referer_origin = get_url("base_url")
    first_hdrs = make_same_origin_headers(referer_origin)
    resp = http_get(iframe_url, headers=first_hdrs, allow_redirects=True)
    if not resp or not (resp.text or "").strip():
        xbmc.log("[get_m3u8_ddy2] failed to fetch iframe page", xbmc.LOGERROR)
        return None, first_hdrs
    found = _find_embed_token_src(resp.text)
    if not found:
        xbmc.log("[get_m3u8_ddy2] embed iframe with token not found", xbmc.LOGERROR)
        return None, first_hdrs
    full_embed_url, cid_from_iframe, token = found
    cid = cid_from_iframe or str(channel_id)
    p = urlparse(full_embed_url)
    embed_origin = get_url("ddy2_url")
    pre_hdrs = make_same_origin_headers(embed_origin)
    pre = http_get(full_embed_url, headers=pre_hdrs, allow_redirects=True)
    if not pre:
        xbmc.log("[get_m3u8_ddy2] prefetch embed.html failed", xbmc.LOGERROR)
        return None, pre_hdrs
    final = f"{p.scheme}://{p.netloc}/{cid}/index.fmp4.m3u8?token={token}"
    stream_hdrs = {"Referer": full_embed_url, "User-Agent": common.user_agent}
    return final, stream_hdrs


# AP
def normalize_stream_id(stream_id: str) -> str:
    if not stream_id:
        return ""
    m = re.match(r"^(SPORT\d+)([A-Z]+)?IL$", stream_id.upper())
    return m.group(1) + m.group(2) if m and m.group(2) else stream_id


def extract_m3u8_url(stream_id: str) -> Tuple[Optional[str], dict]:
    AP_URL = get_value("ap_url")
    hdrs = {"User-Agent": common.user_agent, "Referer": AP_URL}
    sid = normalize_stream_id(stream_id)

    r1_text = http_get(f"{AP_URL}/{stream_id.lower()}.php", headers=hdrs)
    if not r1_text:
        xbmc.log("[extract_m3u8_url] first page fetch failed", xbmc.LOGERROR)
        return None, hdrs
    first = BeautifulSoup(r1_text.text, "html.parser").find(
        "iframe", src=re.compile(f"stream={sid}", re.I)
    )
    if not first or not first.has_attr("src"):
        xbmc.log("[extract_m3u8_url] first iframe not found", xbmc.LOGERROR)
        return None, hdrs

    url2 = first["src"] or ""
    if url2.startswith("//"):
        url2 = "https:" + url2

    r2 = http_get(url2, headers=hdrs)
    if not r2:
        xbmc.log("[extract_m3u8_url] second page fetch failed", xbmc.LOGERROR)
        return None, hdrs
    second_iframe = BeautifulSoup(r2.text, "html.parser").find(
        "iframe", src=re.compile(f"{sid}/embed", re.I)
    )
    if not second_iframe or not second_iframe.has_attr("src"):
        xbmc.log("[extract_m3u8_url] second iframe not found", xbmc.LOGERROR)
        return None, hdrs

    second = second_iframe["src"]
    dom = urlparse(second)
    m = re.search(r"token=([A-Za-z0-9\-]+)", second)
    if not m:
        xbmc.log("[extract_m3u8_url] token not found", xbmc.LOGERROR)
        return None, hdrs
    token = m.group(1)
    final = f"{dom.scheme}://{dom.hostname}/{sid}/index.fmp4.m3u8?token={token}"
    return final, hdrs


def check_url_status(
    url: str, headers: Optional[Dict[str, str]] = None, timeout: int = 7, inline: bool = True
) -> Tuple[bool, Optional[int], Optional[str]]:
    hdrs: Dict[str, str] = headers or {}
    if inline and headers:
        inline_url  = f"{url}|{urlencode(headers)}"
        base, qs = inline_url.split("|", 1)
        url = base
        hdrs = dict(x.split("=", 1) for x in qs.split("&") if "=" in x)
    try:
        r = session.get(
            url,
            headers=hdrs,
            allow_redirects=True,
            timeout=timeout,
            stream=True,
        )
        return (200 <= r.status_code < 300), r.status_code, r.reason
    except Exception as ex:
        xbmc.log(f"[check_url_status] failed for {url}: {ex}", xbmc.LOGERROR)
        return False, None, None


def validated_return(
    m3u8: Optional[str], headers: Optional[Dict[str, str]], srv: Optional[str] = None,
) -> Tuple[Optional[str], Optional[Dict[str, str]]]:
    if not m3u8:
        return None, {}
    if srv == "ap":
        ok, code, reason = check_url_status(m3u8, headers, inline=True)
    else:
        ok, code, reason = check_url_status(m3u8, headers, inline=False)
    if not ok:
        xbmc.log(
            f"[url_origin] m3u8 HTTP status {code or 'NO_STATUS'} {reason or ''} for {m3u8}",
            xbmc.LOGERROR,
        )
        return None, {}
    return m3u8, (headers or {})


#  Common entry point
def url_origin(channel_nid) -> Tuple[Optional[str], Optional[dict]]:
    ch = next((x for x in channels_list if x["nid"] == channel_nid), None)
    if not ch:
        xbmc.log(f"url_origin: nid {channel_nid} not found", xbmc.LOGERROR)
        return None, None

    channel_id, srv = ch["id"], ch["srv"]
    xbmc.log(f"url_origin: id={channel_id}, srv={srv}", xbmc.LOGDEBUG)

    link: Optional[str] = None
    hdrs: Optional[Dict[str, str]] = None

    if srv in ("ddy", "ap2", "top"):
        link, hdrs = resolve_ddy_like(channel_id, srv)

    elif srv == "ddy2":
        link, hdrs = get_m3u8_ddy2(channel_id)

    elif srv == "ap":
        link, hdrs = extract_m3u8_url(channel_id)

    else:
        xbmc.log(f"url_origin: unsupported srv {srv}", xbmc.LOGERROR)
        link, hdrs = None, None

    return validated_return(link, hdrs, srv)
