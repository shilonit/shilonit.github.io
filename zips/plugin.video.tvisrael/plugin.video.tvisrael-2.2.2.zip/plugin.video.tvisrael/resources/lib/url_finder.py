import os, json, re, requests, base64
from typing import Optional, Tuple
from urllib.parse import urlparse
import resources.lib.common as common 
import resources.lib.channels as channels
import xbmc

channels_list = channels.Tvs

# Set up session for persistent connections
session = requests.Session()

# Global parameters.
links_file_path = os.path.join(common.profileDir, 'ddy_url.json')
BASE_URL = "https://daddylive.sx"

def get_base_url_from_links_file(links_file_path: str) -> str:
    global BASE_URL
    url = get_value_from_links_file(links_file_path, 'base_url')
    if url:
        BASE_URL = url
    return BASE_URL

# Initializes global variables by fetching the page content and extracting necessary parameters.
def initialize_globals(channel_id: str, links_file_path: str) -> dict:
    base_url = get_base_url_from_links_file(links_file_path)
    iframe_url = get_value_from_links_file(links_file_path, 'iframe_url') if links_file_path else None
    if not iframe_url:
        xbmc.log("Iframe URL not found in links file.", xbmc.LOGERROR)
        return None
    
    page_content = fetch_with_retries(iframe_url.format(channel_id=channel_id))
    if not page_content:
        xbmc.log("Failed to fetch iframe content.", xbmc.LOGERROR)
        return None

    try:
        auth_data = extract_auth_data(page_content)
        origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
        return {
            "page_content": page_content,
            "channel_key": auth_data["channel_key"],
            "auth_ts": auth_data["auth_ts"],
            "auth_rnd": auth_data["auth_rnd"],
            "auth_sig": auth_data["auth_sig"],
            "origin": origin,
            "base_url": base_url
        }
    except Exception as e:
        xbmc.log(f"Error extracting authentication parameters: {e}", xbmc.LOGERROR)
        return None

# Extracts m3u8 link from the script tags in the page's HTML.
def extract_m3u8_from_script(soup):
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    return None

# Fetch the content of the URL with retry mechanism in case of failure.
def fetch_with_retries(url: str, retries: int = 3, delay: int = 1000) -> Optional[str]:
    for attempt in range(1, retries + 1):
        try:
            response = session.get(url, timeout=5)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            xbmc.log(f"[fetch_with_retries] Attempt {attempt} failed for {url}: {e}", xbmc.LOGINFO)
            if attempt < retries:
                xbmc.sleep(delay)
            else:
                xbmc.log(f"[fetch_with_retries] Failed after {retries} attempts for: {url}", xbmc.LOGERROR)
    return None

def extract_auth_data(page_content: str) -> dict:
    def extract_var(name):
        pattern = rf'var\s+{name}\s*=\s*atob\("([^"]+)"\)'
        match = re.search(pattern, page_content)
        if match:
            return base64.b64decode(match.group(1)).decode('utf-8')
        return None

    match = re.search(r'var\s+channelKey\s*=\s*"([^"]+)"', page_content)
    channel_key = match.group(1) if match else None

    return {
        "channel_key": channel_key,
        "auth_ts": extract_var("__c"),
        "auth_rnd": extract_var("__d"),
        "auth_sig": extract_var("__e"),
    }

# Generate the authentication signature.
def authenticate(channel_key, links_file_path, auth_ts, auth_rnd, auth_sig):
    auth_url = get_value_from_links_file(links_file_path, 'auth_url') if links_file_path else None
    dynamic_domain = get_value_from_links_file(links_file_path, 'ddy_final') if links_file_path else None
    if not auth_url:
        xbmc.log("auth_url missing in JSON file.", xbmc.LOGERROR)
        return False
    full_auth_url = f"https://{auth_url}{dynamic_domain}/auth.php?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    try:
        auth_response = fetch_with_retries(full_auth_url)
        if auth_response:
            # Parse the authentication response
            try:
                response_data = json.loads(auth_response)
                if response_data.get("status") == "ok":
                    xbmc.log("Authentication successful!", xbmc.LOGDEBUG)
                    return True
            except json.JSONDecodeError:
                xbmc.log("Failed to parse authentication response JSON.", xbmc.LOGERROR)
        else:
            xbmc.log("Authentication response was empty.", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Authentication failed: {e}", xbmc.LOGERROR)
    return False

# Get the server_key by calling the server_lookup API.
def get_server_key(channel_key, origin):
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        response = session.get(url)
        response.raise_for_status()
        data = response.json()
        server_key = data.get("server_key")
        if server_key:
            return server_key
        else:
            raise ValueError("No server_key received from API")
    except requests.RequestException as e:
        xbmc.log(f"Error fetching server_key: {e}", xbmc.LOGERROR)
        return None

# Build the m3u8 URL based on the server key and dynamic domain.
def build_m3u8_url(channel_key, server_key, dynamic_domain):
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"

# Process the iframe URL to extract the m3u8 link.
def process_iframe_url(iframe_url: str, channel_id: str, links_file_path: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    page_content = fetch_with_retries(iframe_url)
    if not page_content:
        return None, None
    try:
        auth_data = extract_auth_data(page_content)
        channel_key = auth_data["channel_key"]
        origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
        server_key = get_server_key(channel_key, origin)
        if not server_key:
            return None, None
        dynamic_domain = get_value_from_links_file(links_file_path, 'ddy_final') if links_file_path else None
        if not dynamic_domain:
            xbmc.log("ddy_final missing in JSON file.", xbmc.LOGERROR)
            return None, None
        return build_m3u8_url(channel_key, server_key, dynamic_domain), origin
    except Exception as e:
        xbmc.log(f"[process_iframe_url] Error for channel {channel_id}: {e}", xbmc.LOGERROR)
        return None, None

# Fetches a specified value from the links config file.
def get_value_from_links_file(links_file_path: str, key: str) -> Optional[str]:
    try:
        with open(links_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get(key)
    except Exception as e:
        xbmc.log(f"[get_value_from_links_file] Error reading {key} from {links_file_path}: {e}", xbmc.LOGERROR)
        return None

def get_links_data(channel_id: str, links_file_path: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], Optional[str]]:
    auth_url = get_value_from_links_file(links_file_path, 'auth_url')
    dynamic_domain = get_value_from_links_file(links_file_path, 'ddy_final')
    iframe_url = get_value_from_links_file(links_file_path, 'iframe_url')
    
    # If iframe_url is not None, format it with the channel_id.
    if iframe_url:
        iframe_url = iframe_url.format(channel_id=channel_id)
        m3u8_link, origin = process_iframe_url(iframe_url, channel_id, links_file_path)
    else:
        m3u8_link, origin = None, None
    
    return auth_url, dynamic_domain, iframe_url, (m3u8_link, origin)

# Get the m3u8 URL based on the service type.
def get_m3u8_ddy(channel_id: str, links_file_path: Optional[str] = None) -> Tuple[Optional[str], dict]:
    if links_file_path:
        try:
            auth_url, dynamic_domain, iframe_url, (m3u8_link, origin) = get_links_data(channel_id, links_file_path)
            if m3u8_link:
                xbmc.log(f"[get_m3u8_ddy] Found m3u8 in file: {m3u8_link}", xbmc.LOGDEBUG)
                headers = {
                    'Accept': '*/*',
                    'Accept-Language': 'q=0.8,en-US;q=0.5,en;q=0.3',
                    'Connection': 'keep-alive',
                    'Origin': origin,
                    'Referer': origin + '/',
                    'User-Agent': common.userAgent
                }
                return m3u8_link, headers
            else:
                xbmc.log("[get_m3u8_ddy] m3u8 link not found in file.", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[get_m3u8_ddy] Error reading links file: {e}", xbmc.LOGERROR)
    else:
        xbmc.log("[get_m3u8_ddy] links_file_path not provided.", xbmc.LOGERROR)
    return None, {}

# Retrieves the channel_api from the ddy2 mapping.
def get_channel_api(channel_id: str, links_file_path: str) -> Optional[str]:
    ddy2_data = get_value_from_links_file(links_file_path, 'ddy2')
    if not ddy2_data:
        xbmc.log(f"[get_channel_api] ddy2 data not found in {links_file_path}.", xbmc.LOGERROR)
        return None
    return ddy2_data.get(channel_id)

# Fetch the streaming URL from DDY2.
def fetch_stream_url(channel_api: str, links_file_path: str) -> Tuple[Optional[str], dict]:
    DDY2_URL = get_value_from_links_file(links_file_path, 'ddy2_url')
    if not DDY2_URL:
        xbmc.log("[fetch_stream_url] ddy2_url not found in links file.", xbmc.LOGERROR)
        return None, {}
    api_url = f"{DDY2_URL}/api/source/{channel_api}?type=live"
    payload = {"r": BASE_URL, "d": DDY2_URL.split("://")[-1]}
    headers = {
        "Origin": DDY2_URL,
        "Referer": f"{DDY2_URL}/",
        "User-Agent": common.userAgent
    }

    try:
        post_response = session.post(api_url, data=json.dumps(payload), headers=headers, timeout=10)
        xbmc.log(f"Raw response text: {post_response.text}", xbmc.LOGDEBUG)
        post_response.raise_for_status()
        data = post_response.json()
        m3u8_link = data.get("player", {}).get("source_file")

        # If m3u8_link is None, try to fetch it from the channel_api page.
        headers = headers if isinstance(headers, dict) else {}

        return m3u8_link, headers
    except requests.RequestException as e:
        xbmc.log(f"[fetch_stream_url] Error fetching stream URL: {e}", xbmc.LOGERROR)
        return None, {}

# The main entry point to get the m3u8 URL based on the service type.
def url_origin(channel_nid, links_file_path: Optional[str] = None, headers: Optional[dict] = None) -> Tuple[Optional[str], Optional[str]]:
    if not links_file_path:
        xbmc.log("[url_origin] No links file provided.", xbmc.LOGERROR)
        return None, None

    # Find the channel id and srv in the channels list.
    channel = next((ch for ch in channels_list if ch['nid'] == channel_nid), None)
    if not channel:
        xbmc.log(f"[url_origin] Channel NID {channel_nid} not found.", xbmc.LOGERROR)
        return None, None

    channel_id = channel['id']
    srv = channel['srv']
    xbmc.log(f"[url_origin] Using channel_id={channel_id} (converted from nid={channel_nid}), srv={srv}", xbmc.LOGDEBUG)

    if srv == 'ddy':
        globals_data = initialize_globals(channel_id, links_file_path)
        if not globals_data:
            xbmc.log("[url_origin] Failed to initialize globals. Check links file or iframe URL.", xbmc.LOGERROR)
            return None, None
        authenticated = authenticate(
            globals_data["channel_key"],
            links_file_path,
            globals_data["auth_ts"],
            globals_data["auth_rnd"],
            globals_data["auth_sig"]
        )
        if not authenticated:
            xbmc.log("[url_origin] Authentication failed. Stopping process.", xbmc.LOGERROR)
            return None, None
        return get_m3u8_ddy(channel_id, links_file_path)

    elif srv == 'ddy2':
        channel_api = get_channel_api(channel_id, links_file_path)
        if not channel_api:
            xbmc.log(f"[url_origin] Channel API not found for channel_id {channel_id}.", xbmc.LOGERROR)
            return None, None
        stream_url = fetch_stream_url(channel_api, links_file_path)
        if not stream_url[0]:
            xbmc.log(f"[url_origin] Failed to retrieve stream URL for channel_id {channel_id}.", xbmc.LOGERROR)
        return stream_url
    else:
        xbmc.log(f"[url_origin] Unsupported srv type: {srv}", xbmc.LOGERROR)
        return None, None
