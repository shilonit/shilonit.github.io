﻿# -*- coding: utf-8 -*-
Tvs = [
    { 'nid': 'sport1', 'index': 1, 'name': 30602, 'thumb': 'sport_1.jpg', 'srv': 'ddy', 'id': '140', 'tvgid': 'sport1' },
    { 'nid': 'sport1_b', 'index': 1, 'name': 30622, 'thumb': 'sport_1.jpg', 'srv': 'ddy2', 'id': '140', 'tvgid': 'sport1' },
    { 'nid': 'sport2', 'index': 2, 'name': 30603, 'thumb': 'sport_2.jpg', 'srv': 'ddy', 'id': '141', 'tvgid': 'sport2' },
    { 'nid': 'sport2_b', 'index': 2, 'name': 30623, 'thumb': 'sport_2.jpg', 'srv': 'ddy2', 'id': '141', 'tvgid': 'sport2' },
    { 'nid': 'sport3', 'index': 3, 'name': 30604, 'thumb': 'sport_3.jpg', 'srv': 'ddy', 'id': '142', 'tvgid': 'sport3' },
    { 'nid': 'sport3_b', 'index': 3, 'name': 30624, 'thumb': 'sport_3.jpg', 'srv': 'ddy2', 'id': '142', 'tvgid': 'sport3' },
    { 'nid': 'sport4', 'index': 4, 'name': 30605, 'thumb': 'sport_4.jpg', 'srv': 'ddy', 'id': '143', 'tvgid': 'sport4' },
    { 'nid': 'sport4_b', 'index': 4, 'name': 30625, 'thumb': 'sport_4.jpg', 'srv': 'ddy2', 'id': '143', 'tvgid': 'sport4' },
    { 'nid': 'sport5', 'index': 5, 'name': 30606, 'thumb': 'sport_5.jpg', 'srv': 'ddy', 'id': '144', 'tvgid': 'sport5' },
    { 'nid': 'sport5_b', 'index': 5, 'name': 30626, 'thumb': 'sport_5.jpg', 'srv': 'ddy2', 'id': '144', 'tvgid': 'sport5' },
    { 'nid': '5plus', 'index': 6, 'name': 30607, 'thumb': '5_plus.jpg', 'srv': 'ddy', 'id': '145', 'tvgid': '5plus' },
    { 'nid': '5plus_b', 'index': 6, 'name': 30627, 'thumb': '5_plus.jpg', 'srv': 'ddy2', 'id': '145', 'tvgid': '5plus' },
    { 'nid': '5live', 'index': 7, 'name': 30608, 'thumb': '5_live.jpg', 'srv': 'ddy', 'id': '146', 'tvgid': '5live' },
    { 'nid': '5live_b', 'index': 7, 'name': 30628, 'thumb': '5_live.jpg', 'srv': 'ddy2', 'id': '146', 'tvgid': '5live' },
    { 'nid': '5star', 'index': 8, 'name': 30609, 'thumb': '5_stars.jpg', 'srv': 'ddy', 'id': '147', 'tvgid': '5stars' },
    { 'nid': '5star_b', 'index': 8, 'name': 30629, 'thumb': '5_stars.jpg', 'srv': 'ddy2', 'id': '147', 'tvgid': '5stars' },
    { 'nid': '5gold', 'index': 9, 'name': 30610, 'thumb': '5_gold.jpg', 'srv': 'ddy', 'id': '148', 'tvgid': '5gold' },
    { 'nid': '5gold_b', 'index': 9, 'name': 30630, 'thumb': '5_gold.jpg', 'srv': 'ddy2', 'id': '148', 'tvgid': '5gold' },
    { 'nid': 'one', 'index': 10, 'name': 30611, 'thumb': 'One.jpg', 'srv': 'ddy', 'id': '541', 'tvgid': 'ONE' },
    { 'nid': 'one2', 'index': 11, 'name': 30612, 'thumb': 'One_2.jpg', 'srv': 'ddy', 'id': '542', 'tvgid': 'ONE2' }
]
