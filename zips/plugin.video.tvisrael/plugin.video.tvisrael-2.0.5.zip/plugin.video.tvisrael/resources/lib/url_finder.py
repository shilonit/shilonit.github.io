import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import time
import random

github_url = 'https://raw.githubusercontent.com/shilonit/epgtools/refs/heads/main/sport/ddy_url.json'

# Extract m3u8 link from the script
def extract_m3u8_from_script(soup):
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    return None

# A unified function to handle retries with a random delay
def fetch_with_retries(url, retries=2, delay=2):
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(url, timeout=5)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            print(f"Attempt {attempt} failed for {url}: {e}")
            if attempt < retries:
                time.sleep(random.uniform(1, delay))  # Adding random delay before retrying
            else:
                print(f"Failed after {retries} attempts for: {url}")
                return None
    return None

# Extract m3u8 link for topembed.pw
def get_m3u8_top(channel_id):
    channel_number = ''.join(filter(str.isdigit, channel_id))
    url = f'https://topembed.pw/channel/YesSport{channel_number}[Israel]'

    page_content = fetch_with_retries(url)
    if page_content:
        soup = BeautifulSoup(page_content, 'html.parser')
        m3u8_link = extract_m3u8_from_script(soup)
        if m3u8_link:
            origin = 'https://topembed.pw'
            return m3u8_link, origin
    return None, None

# Extract m3u8 link for daddylive.sx and miztv.ru
def get_m3u8_ddy(channel_id, github_url=None):
    # First, try to fetch from GitHub
    if github_url:
        m3u8_link, origin = get_m3u8_from_github(channel_id, github_url)
        if m3u8_link:
            return m3u8_link, origin

    # Try the regular URLs (daddylive.sx and miztv.ru)
    urls = [
        f'https://daddylive.sx/embed/stream-{channel_id}.php',
        f'https://miztv.ru/tele/stream-{channel_id}.php'
    ]
    
    for url in urls:
        page_content = fetch_with_retries(url)
        if page_content:
            soup = BeautifulSoup(page_content, 'html.parser')
            iframe = soup.find('iframe')
            if iframe and iframe.has_attr('src'):
                iframe_src = iframe['src']
                page_content = fetch_with_retries(iframe_src)
                if page_content:
                    soup = BeautifulSoup(page_content, 'html.parser')
                    m3u8_link = extract_m3u8_from_script(soup)
                    if m3u8_link:
                        origin = urlparse(iframe_src).scheme + "://" + urlparse(iframe_src).netloc
                        return m3u8_link, origin
    return None, None

# Fetch iframe URL from GitHub
def get_iframe_url_from_github(github_url):
    try:
        response = requests.get(github_url)
        response.raise_for_status()
        config = response.json()
        iframe_url = config.get('iframe_url')
        if iframe_url:
            return iframe_url
        else:
            print("No iframe URL found in GitHub config.")
            return None
    except (requests.RequestException, ValueError) as e:
        print(f"Error fetching config from GitHub: {e}")
        return None

# Fetch m3u8 from iframe URL from GitHub
def get_m3u8_from_github(channel_id, github_url):
    iframe_url = get_iframe_url_from_github(github_url)
    if iframe_url:
        iframe_url = iframe_url.format(channel_id=channel_id)  # Insert channel_id
        page_content = fetch_with_retries(iframe_url)
        if page_content:
            soup = BeautifulSoup(page_content, 'html.parser')
            m3u8_link = extract_m3u8_from_script(soup)
            if m3u8_link:
                origin = urlparse(iframe_url).scheme + "://" + urlparse(iframe_url).netloc
                return m3u8_link, origin
    return None, None

# Function to check both methods
def url_origin(channel_id, srv, github_url=None):
    if srv == 'top':
        return get_m3u8_top(channel_id)
    elif srv == 'ddy':
        return get_m3u8_ddy(channel_id, github_url)
    else:
        raise ValueError('Unsupported service type.')