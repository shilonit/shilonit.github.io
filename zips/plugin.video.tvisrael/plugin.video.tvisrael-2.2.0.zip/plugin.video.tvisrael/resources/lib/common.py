# -*- coding: utf-8 -*-
import sys, os, io, json, re, collections, time, random
import requests
import xbmc, xbmcaddon, xbmcvfs
from resources.lib.UA import userAgents

AddonID = 'plugin.video.tvisrael'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
AddonVer = Addon.getAddonInfo('version')
AddonName = "TV Israel"

userAgent = random.choice(userAgents)

# Decode and encode functions
def decode(text, dec, force=False):
    if force:
        text = bytearray(text, 'utf-8').decode(dec)
    return text

def encode(text, dec):
    return text

# Translate path function
def translate_path(path):
    return xbmcvfs.translatePath(path)

# Global variables
addonPath = Addon.getAddonInfo('path')

# Profile directory creation
profileDir = decode(translate_path(Addon.getAddonInfo("profile")), "utf-8")
if not os.path.exists(profileDir):
    os.makedirs(profileDir)

imagesDir = decode(translate_path(os.path.join(addonPath, 'resources', 'images')), "utf-8")
epgFile = os.path.join(profileDir, 'epg.json')
epg_url = 'https://raw.githubusercontent.com/shilonit/epgtools/main/sport/epg.json'

# Utility function to safely get handle from arguments
def get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1

# Get icon full path
def get_icon_full_path(icon):
    return os.path.join(imagesDir, icon)

# Check if an addon is installed
def is_addon_installed(addonid):
    return xbmc.getCondVisibility(f'System.HasAddon({addonid})')

# Install addon
def install_addon(addonid):
    xbmc.executebuiltin(f'InstallAddon({addonid})')

# Check if addon is enabled
def is_addon_enabled(addonid):
    try:
        json_request = (
            f'{{"jsonrpc":"2.0",'
            f'"method":"Addons.GetAddonDetails",'
            f'"params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'
        )
        response = json.loads(xbmc.executeJSONRPC(json_request))

        return response['result']['addon']['enabled']
    except json.JSONDecodeError:
        return False

def restart_addon(addonid):
    xbmc.executebuiltin(f'UpdateAddon({addonid})')

# Get localized string
def get_locale_string(id):
    return encode(Addon.getLocalizedString(id), 'utf-8')

# Get label color
def get_label_color(text, key_color=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(key_color)
    if bold:
        text = f'[B]{text}[/B]'
    return text if color == 'none' else f'[COLOR {color}]{text}[/COLOR]'

# Read and return settings from addon
def get_addon_setting(key):
    return Addon.getSetting(key)

# Read a list from a file
def read_list(fileName):
    try:
        with io.open(fileName, 'r', encoding='utf-8') as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except Exception as ex:
        xbmc.log(str(ex), 3)
        return []

# Escape XML special characters
def escape_xml(text):
    if isinstance(text, bytes):
        text = text.decode('utf-8')
    return text.replace('&', '&amp;').replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")

# Check if file is older than a given threshold
def is_file_old(filename, deltaInSec=10800):
    last_update = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - last_update) > deltaInSec

# Get integer setting, defaulting if necessary
def get_int_setting(k, v=0):
    setting = Addon.getSetting(k)
    if not setting or not setting.isdigit():
        xbmc.log(f"[get_int_setting] Invalid setting detected for key '{k}', defaulting to {v}", xbmc.LOGWARNING)
        Addon.setSetting(k, str(v))
        return v
    return int(setting)

# Get text content from a file
def get_text_file(filename):
    if os.path.isfile(filename):
        with io.open(filename, 'r', encoding="utf-8") as f:
            return f.read()
    return ''

# Fetches the EPG data and saves it to a file.
def save_links_json():
    links_file = os.path.join(profileDir, 'ddy_url.json')
    links_url = 'https://raw.githubusercontent.com/shilonit/epgtools/refs/heads/main/sport/ddy_url.json'
    try:
        response = requests.get(links_url, timeout=10)
        response.raise_for_status()
        json_data = response.json()
        # Ensure json_data is valid before dumping to file
        if isinstance(json_data, (dict, list)):
            with open(links_file, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
        else:
            xbmc.log("Fetched data is not in JSON format", xbmc.LOGERROR)
    except requests.RequestException as e:
        xbmc.log(f"Error fetching links_File: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Unexpected error while fetching links_File: {e}", xbmc.LOGERROR)
