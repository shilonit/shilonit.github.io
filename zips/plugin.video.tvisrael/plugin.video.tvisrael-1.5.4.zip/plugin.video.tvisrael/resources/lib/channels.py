﻿# -*- coding: utf-8 -*-
Tvs = [
    { 'index': 1, 'name': 30602, 'thumb': 'sport_1.jpg', 'srv': 'ddy', 'id': '140', 'tvgid': 'sport1' },
    { 'index': 2, 'name': 30603, 'thumb': 'sport_2.jpg', 'srv': 'ddy', 'id': '141', 'tvgid': 'sport2' },
    { 'index': 3, 'name': 30604, 'thumb': 'sport_3.jpg', 'srv': 'ddy', 'id': '142', 'tvgid': 'sport3' },
    { 'index': 4, 'name': 30605, 'thumb': 'sport_4.jpg', 'srv': 'ddy', 'id': '143', 'tvgid': 'sport4' },
    { 'index': 5, 'name': 30606, 'thumb': 'sport_5.jpg', 'srv': 'top', 'id': 'sport5il', 'tvgid': 'sport5' },
    { 'index': 5, 'name': 30650, 'thumb': 'sport_5.jpg', 'srv': 'ddy', 'id': '144', 'tvgid': 'sport5' },
    { 'index': 6, 'name': 30607, 'thumb': '5_plus.jpg', 'srv': 'ddy', 'id': '145', 'tvgid': '5plus' },
    { 'index': 7, 'name': 30608, 'thumb': '5_live.jpg', 'srv': 'ddy', 'id': '146', 'tvgid': '5live' },
    { 'index': 8, 'name': 30609, 'thumb': '5_stars.jpg', 'srv': 'ddy', 'id': '147', 'tvgid': '5stars' },
    { 'index': 9, 'name': 30610, 'thumb': '5_gold.jpg', 'srv': 'ddy', 'id': '148', 'tvgid': '5gold'},
    { 'index': 10, 'name': 30611, 'thumb': 'One.jpg', 'srv': 'ddy', 'id': '541', 'tvgid': 'ONE' },
    { 'index': 11, 'name': 30612, 'thumb': 'One_2.jpg', 'srv': 'ddy', 'id': '542', 'tvgid': 'ONE2' },
    { 'index': 12, 'name': 30613, 'thumb': 'Yes_Action.png', 'srv': 'ddy', 'id': '543', 'tvgid': 'yes_action'},
    { 'index': 13, 'name': 30614, 'thumb': 'Yes_Kids.png', 'srv': 'ddy', 'id': '544', 'tvgid': 'yes_kids' },
    { 'index': 14, 'name': 30615, 'thumb': 'Yes_Comedy.png', 'srv': 'ddy', 'id': '545', 'tvgid': 'yes_comedy' },
    { 'index': 15, 'name': 30616, 'thumb': 'Hot_3.png', 'srv': 'ddy', 'id': '553', 'tvgid': 'HOT3' }
]
