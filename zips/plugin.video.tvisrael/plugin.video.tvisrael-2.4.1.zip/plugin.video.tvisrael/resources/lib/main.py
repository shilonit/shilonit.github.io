# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl
import requests, threading
from import_xbmc import xbmc, xbmcgui, xbmcplugin
import common, channels
import epglist as epg
from url_finder import url_origin

# Global variables
addon_handle = common.get_handle()
channels_list = channels.Tvs

# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f'{sys.argv[0]}?{urlencode(kwargs)}'
    except Exception as e:
        xbmc.log(f'Error creating URL: {e}', xbmc.LOGERROR)
        return ''

# Display the categories list with channels and settings
def categories_list():
    title = common.get_locale_string(30402)
    xbmcplugin.setPluginCategory(addon_handle, common.get_label_color(title, bold=True, color="purple"))
    xbmcplugin.setContent(addon_handle, 'videos')

    img_tv         = common.get_icon_full_path('tv.jpg')
    img_sports     = common.get_icon_full_path('sports.jpg')
    channels_label = common.get_locale_string(30504)
    settings_label = common.get_locale_string(30401)
    channels_name  = common.get_label_color(channels_label, bold=True, color="none")
    settings_name  = common.get_label_color(settings_label, bold=True, color="yellow")

    items = []

    # Channels section
    channels_url = get_url(mode=7)
    if channels_url:
        li = xbmcgui.ListItem(label=channels_name)
        li.setArt({'thumb': img_sports, 'icon': img_sports, 'fanart': img_sports})
        info = li.getVideoInfoTag()
        info.setTitle(str(channels_label))
        items.append((channels_url, li, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        li = xbmcgui.ListItem(label=settings_name)
        li.setArt({'thumb': img_tv, 'icon': img_tv, 'fanart': img_tv})
        info = li.getVideoInfoTag()
        info.setTitle(str(settings_label))
        items.append((settings_url, li, False))

    xbmcplugin.addDirectoryItems(addon_handle , items)
    xbmcplugin.endOfDirectory(addon_handle)

# Play video from the selected channel
def play_video(channel_nid):
    if not channel_nid:
        xbmc.log('Channel ID is missing.', xbmc.LOGERROR)
        return

    channel = next((ch for ch in channels_list if ch['nid'] == channel_nid), None)
    if not channel:
        xbmc.log(f'Channel with ID {channel_nid} not found.', xbmc.LOGERROR)
        return

    threading.Thread(target=common.update_files, daemon=True).start()

    try:
        m3u8_link, headers = url_origin(channel_nid, common.links_file_path)
        if not m3u8_link:
            xbmc.log(f"[play_video] No m3u8 link found for {channel_nid}", xbmc.LOGERROR)
            notify(30700, 30710)
            xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())
            return

        # For ddy, ap2 and top
        if 'mono.m3u8' in m3u8_link:
            if headers and isinstance(headers, dict):
                link = f'{m3u8_link}|{urlencode(headers)}'
            else:
                xbmc.log("[play_video] Headers are not a valid dictionary.", xbmc.LOGERROR)
                link = m3u8_link
            play_item = xbmcgui.ListItem(path=link)

        # With inputstream.adaptive
        else:
            play_item = xbmcgui.ListItem(path=m3u8_link)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('IsLive', 'true')
            play_item.setProperty('StartOffset', 'live')
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            if headers and isinstance(headers, dict):
                play_item.setProperty('inputstream.adaptive.stream_headers', urlencode(headers))

        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=True, listitem=play_item)

    except requests.RequestException as e:
        xbmc.log(f'Network error: {e}', xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f'An unexpected error occurred: {e}', xbmc.LOGERROR)

# Get all channels sorted by user preferences
def get_all_channels():
    for channel in channels_list:
        xbmc.log(f"Checking channel: nid={channel['nid']}, index={channel['index']}", xbmc.LOGDEBUG)
        if not isinstance(channel['index'], int):
            xbmc.log(f"Invalid index value detected: {channel['index']}", xbmc.LOGERROR)

    user_channels = [channel for channel in channels_list if common.get_int_setting(channel['nid'], channel['index']) > 0]
    sorted_channels = sorted(user_channels, key=lambda k: k['index'])
    return sorted_channels

# Create IPTV files and update EPG when needed or launch the addon
def make_iptv_files():
    epg.generate_iptv_list(get_all_channels())
    common.update_files()

# Perform actions during the first run of the addon
def first_run():
    make_iptv_files()
    epg.set_iptv_client_settings()
    notify(30500, 30412)

# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f'Addon.OpenSettings({common.AddonID})')

# Launch the EPG window
def launch_epg():
    xbmc.executebuiltin('ActivateWindow(TVGuide,pvr://channels/tv)')

# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin('ActivateWindow(pvrsettings)')

def notify(title_id: int, message_id: int, duration: int = 5000, icon: str = None) -> None:
    title = common.get_locale_string(title_id)
    message = common.get_locale_string(message_id)
    # Icon default
    if icon is None:
        icon = common.AppLogo
    xbmc.executebuiltin(f'Notification({title}, {message}, {duration}, "{icon}")')

# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode   = params.get('mode')
    url    = params.get('url')

    actions = {
        '-1': categories_list,
         '1': lambda: play_video(url),
         '2': open_settings,
         '3': lambda: (epg.open_iptv_client_settings(), sys.exit()),
         '4': lambda: (make_iptv_files(), None if params.get('source') == 'alarm' else notify(30805, 30413), sys.exit()),
         '5': lambda: (epg.set_iptv_client_settings(), notify(30414, 30415), sys.exit()),
         '6': lambda: (epg.fetch_and_save_epg(), notify(30407, 30408)),
         '7': launch_epg,
         '8': lambda: (open_pvrsettings(), sys.exit()),
         '9': lambda: (first_run(), sys.exit()),
        '10': lambda: (common.save_links_json(), notify(30409, 30410))
    }

    if mode in actions:
        actions[mode]()
    else:
        if params:
            xbmc.log(f'Invalid mode: {mode}', xbmc.LOGERROR)
            sys.exit()
        else:
            categories_list()

if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
