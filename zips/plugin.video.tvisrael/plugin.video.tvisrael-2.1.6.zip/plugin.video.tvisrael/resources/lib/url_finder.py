import os, json, time, re
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import resources.lib.common as common
import requests
import xbmc

# Set up session for persistent connections
session = requests.Session()

# Path to the JSON file where the ddy URL is saved
links_file_path = os.path.join(common.profileDir, 'ddy_url.json')

# Extracts m3u8 link from the script tags in the page's HTML.
def extract_m3u8_from_script(soup):
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    return None

# Fetch the content of the URL with retry mechanism in case of failure.
def fetch_with_retries(url, retries=3, delay=2):
    for attempt in range(1, retries + 1):
        try:
            response = session.get(url, timeout=5)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            xbmc.log(f"Attempt {attempt} failed for {url}: {e}", xbmc.LOGINFO)
            if attempt < retries:
                time.sleep(1)
            else:
                xbmc.log(f"Failed after {retries} attempts for: {url}", xbmc.LOGERROR)
                return None
    return None

# Extracts the channel key from the page content.
def extract_channel_key(page_content):
    match = re.search(r'var channelKey = "(.*?)";', page_content)
    if match:
        return match.group(1)
    else:
        raise ValueError("channelKey Not Found in HTML Page")

# Get the server_key by calling the server_lookup API.
def get_server_key(channel_key, origin):
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        response = session.get(url)
        response.raise_for_status()
        data = response.json()
        server_key = data.get("server_key")
        if server_key:
            return server_key
        else:
            raise ValueError("No server_key received from API")
    except requests.RequestException as e:
        xbmc.log(f"Error fetching server_key: {e}", xbmc.LOGERROR)
        return None

# Build the m3u8 URL based on the server key and dynamic domain.
def build_m3u8_url(channel_key, server_key, dynamic_domain):
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"

# Process the iframe URL to extract the m3u8 link.
def process_iframe_url(iframe_url, channel_id, links_file_path=None):
    page_content = fetch_with_retries(iframe_url)
    if page_content:
        try:
            channel_key = extract_channel_key(page_content)
            origin = urlparse(iframe_url).scheme + "://" + urlparse(iframe_url).netloc
            server_key = get_server_key(channel_key, origin)
            if server_key:
                # If links_file_path is provided, try fetching the dynamic domain from links file
                if links_file_path:
                    dynamic_domain = get_dynamic_domain_from_links_file(links_file_path)
                    # If not found in links file, use regex to find it from page content
                    if not dynamic_domain:
                        dynamic_domain = find_dynamic_domain(page_content)
                else:
                    # Otherwise, find dynamic domain using regex if not using links file
                    dynamic_domain = find_dynamic_domain(page_content)
                return build_m3u8_url(channel_key, server_key, dynamic_domain), origin
        except Exception as e:
            xbmc.log(f"Error processing iframe URL for channel {channel_id}: {e}", xbmc.LOGERROR)
    return None, None

# Use regex or some other method to find dynamic domain.
def find_dynamic_domain(page_content):
    pattern = r'"https:\/\/" \+ ([^top1][a-zA-Z0-9_-]+) \+ "([a-zA-Z0-9-]+\.[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+)\/" \+ \1 \+ "\/" \+ ([a-zA-Z0-9_-]+) \+ "\/mono\.m3u8"'
    match = re.search(pattern, page_content)
    if match:
        return match.group(2)
    return "new.koskoros.ru"  # Default domain if none found

# Fetch dynamic domain from the links config file
def get_dynamic_domain_from_links_file(links_file_path):
    try:
        with open(links_file_path, 'r') as file:
            config = json.load(file)
            dynamic_domain = config.get('ddy_final')
            if dynamic_domain:
                return dynamic_domain
            else:
                xbmc.log("No ddy_final found in links config.", xbmc.LOGERROR)
                return None
    except (FileNotFoundError, json.JSONDecodeError) as e:
        xbmc.log(f"Error reading links config: {e}", xbmc.LOGERROR)
        return None

# Fetch iframe URL from links config file
def get_iframe_url_from_links_file(links_file_path):
    try:
        with open(links_file_path, 'r') as file:
            config = json.load(file)
            iframe_url = config.get('iframe_url')
            if iframe_url:
                return iframe_url
            else:
                xbmc.log("No iframe URL found in links config.", xbmc.LOGERROR)
                return None
    except (FileNotFoundError, json.JSONDecodeError) as e:
        xbmc.log(f"Error reading links config: {e}", xbmc.LOGERROR)
        return None

# Get m3u8 link by processing iframe URL from links config.
def get_m3u8_from_links_file(channel_id, links_file_path):
    iframe_url = get_iframe_url_from_links_file(links_file_path)
    if iframe_url:
        iframe_url = iframe_url.format(channel_id=channel_id)
        return process_iframe_url(iframe_url, channel_id, links_file_path)
    return None, None

# Get the m3u8 URL based on the service type.
def get_m3u8_ddy(channel_id, links_file_path=None):
    # Try fetching dynamic domain from links file if path is provided
    if links_file_path:
        try:
            m3u8_link, origin = get_m3u8_from_links_file(channel_id, links_file_path)
            if m3u8_link:
                return m3u8_link, origin
        except Exception as e:
            xbmc.log(f"Error reading links file: {e}", xbmc.LOGERROR)
    
    # If no link file, fall back to chack URLs
    urls = [
    f'https://{domain}/tele/stream-{channel_id}.php' for domain in ['daddylive.sx', 'miztv.ru']
    ] + [
    f'https://{domain}/embed/stream-{channel_id}.php' for domain in ['daddylive.sx', 'miztv.ru']
    ]
    
    for url in urls:
        xbmc.log(f"Trying URL: {url}", xbmc.LOGINFO)
        page_content = fetch_with_retries(url)
        if page_content:
            soup = BeautifulSoup(page_content, 'html.parser')
            iframe = soup.find('iframe')
            if iframe and iframe.has_attr('src'):
                iframe_src = iframe['src']
                m3u8_link, origin = process_iframe_url(iframe_src, channel_id, links_file_path)
                if m3u8_link:
                    return m3u8_link, origin
    return None, None

# The main entry point to get the m3u8 URL based on the service type.
def url_origin(channel_id, srv, links_file_path=None):
    if srv == 'ddy':
        return get_m3u8_ddy(channel_id, links_file_path)
    else:
        raise ValueError('Unsupported service type.')