# -*- coding: utf-8 -*-
import time
import common
from import_xbmc import xbmc

monitor = xbmc.Monitor()

if common.Addon.getSettingBool("version_check_startup"):
    common.check_version(startup=True)

def run_scheduler():
    epg_interval   = common.Addon.getSettingInt("update_EPG_interval") * 3600
    links_interval = common.Addon.getSettingInt("update_links_interval") * 3600
    next_epg       = time.time()
    next_links     = time.time()

    xbmc.log("[run_scheduler] Service.py started", xbmc.LOGDEBUG)
    while not monitor.abortRequested():
        now = time.time()

        if now >= next_epg or now >= next_links:
            try:
                common.update_files()
                xbmc.log("[run_scheduler] update_files executed", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"[run_scheduler] Error in scheduler: {e}", xbmc.LOGERROR)

            if now >= next_epg:
                xbmc.log("[run_scheduler] EPG timer reset", xbmc.LOGDEBUG)
                next_epg = now + epg_interval

            if now >= next_links:
                xbmc.log("[run_scheduler] Links timer reset", xbmc.LOGDEBUG)
                next_links = now + links_interval

        xbmc.sleep(1000)

    xbmc.log("[run_scheduler] Service stopped gracefully", xbmc.LOGINFO)

run_scheduler()
