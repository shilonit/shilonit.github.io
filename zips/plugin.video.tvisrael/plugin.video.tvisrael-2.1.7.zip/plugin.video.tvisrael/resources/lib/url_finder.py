import os, json, time, re
from typing import Optional, Tuple
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import resources.lib.common as common
import requests
import xbmc

# Set up session for persistent connections
session = requests.Session()

# Global parameters.
links_file_path = os.path.join(common.profileDir, 'ddy_url.json')
page_content = None
channel_key = None
auth_ts = None
auth_rnd = None
auth_sig = None
origin = None
BASE_URL = "https://daddylive.sx"

def get_base_url_from_links_file(links_file_path: str) -> str:
    """Fetches BASE_URL from the links config file, or updates the global variable."""
    global BASE_URL
    url = get_value_from_links_file(links_file_path, 'base_url')
    if url:
        BASE_URL = url
    return BASE_URL

# Initializes global variables by fetching the page content and extracting necessary parameters.
def initialize_globals(channel_id: str, links_file_path: str) -> dict:
    """Initializes global variables by fetching the page content and extracting necessary parameters."""
    base_url = get_base_url_from_links_file(links_file_path)
    iframe_url = get_value_from_links_file(links_file_path, 'iframe_url') if links_file_path else None
    if not iframe_url:
        xbmc.log("Iframe URL not found in links file.", xbmc.LOGERROR)
        return None
    
    page_content = fetch_with_retries(iframe_url.format(channel_id=channel_id))
    if not page_content:
        xbmc.log("Failed to fetch iframe content.", xbmc.LOGERROR)
        return None

    try:
        auth_data = extract_auth_data(page_content)
        origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
        return {
            "page_content": page_content,
            "channel_key": auth_data["channel_key"],
            "auth_ts": auth_data["auth_ts"],
            "auth_rnd": auth_data["auth_rnd"],
            "auth_sig": auth_data["auth_sig"],
            "origin": origin,
            "base_url": base_url
        }
    except Exception as e:
        xbmc.log(f"Error extracting authentication parameters: {e}", xbmc.LOGERROR)
        return None

# Extracts m3u8 link from the script tags in the page's HTML.
def extract_m3u8_from_script(soup):
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    return None

# Fetch the content of the URL with retry mechanism in case of failure.
def fetch_with_retries(url: str, retries: int = 3, delay: int = 1) -> Optional[str]:
    """Fetches the content of a URL with retries."""
    for attempt in range(1, retries + 1):
        try:
            response = session.get(url, timeout=5)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            xbmc.log(f"[fetch_with_retries] Attempt {attempt} failed for {url}: {e}", xbmc.LOGINFO)
            if attempt < retries:
                time.sleep(delay)
            else:
                xbmc.log(f"[fetch_with_retries] Failed after {retries} attempts for: {url}", xbmc.LOGERROR)
    return None

def extract_auth_data(page_content: str) -> dict:
    """Extracts authentication parameters from the page content."""
    patterns = {
        "channel_key": r'var channelKey = "(.*?)";',
        "auth_ts": r'var authTs\s*=\s*"(.*?)";',
        "auth_rnd": r'var authRnd\s*=\s*"(.*?)";',
        "auth_sig": r'var authSig\s*=\s*"(.*?)";'
    }
    auth_data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, page_content)
        if not match:
            raise ValueError(f"{key} Not Found in HTML Page")
        auth_data[key] = match.group(1)
    return auth_data

# Generate the authentication signature.
def authenticate(channel_key, links_file_path, auth_ts, auth_rnd, auth_sig):
    auth_url = get_value_from_links_file(links_file_path, 'auth_url') if links_file_path else None
    dynamic_domain = get_value_from_links_file(links_file_path, 'ddy_final') if links_file_path else None
    if not auth_url:
        xbmc.log("auth_url missing in JSON file.", xbmc.LOGERROR)
        return False
    full_auth_url = f"https://{auth_url}{dynamic_domain}/auth.php?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    try:
        auth_response = fetch_with_retries(full_auth_url)
        if auth_response:
            # Parse the authentication response
            try:
                response_data = json.loads(auth_response)
                if response_data.get("status") == "ok":
                    xbmc.log("Authentication successful!", xbmc.LOGDEBUG)
                    return True
            except json.JSONDecodeError:
                xbmc.log("Failed to parse authentication response JSON.", xbmc.LOGERROR)
        else:
            xbmc.log("Authentication response was empty.", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Authentication failed: {e}", xbmc.LOGERROR)
    return False

# Get the server_key by calling the server_lookup API.
def get_server_key(channel_key, origin):
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        response = session.get(url)
        response.raise_for_status()
        data = response.json()
        server_key = data.get("server_key")
        if server_key:
            return server_key
        else:
            raise ValueError("No server_key received from API")
    except requests.RequestException as e:
        xbmc.log(f"Error fetching server_key: {e}", xbmc.LOGERROR)
        return None

# Build the m3u8 URL based on the server key and dynamic domain.
def build_m3u8_url(channel_key, server_key, dynamic_domain):
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"

# Process the iframe URL to extract the m3u8 link.
def process_iframe_url(iframe_url: str, channel_id: str, links_file_path: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """Processes the iframe URL to extract the m3u8 link."""
    page_content = fetch_with_retries(iframe_url)
    if not page_content:
        return None, None
    try:
        auth_data = extract_auth_data(page_content)
        channel_key = auth_data["channel_key"]
        origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
        server_key = get_server_key(channel_key, origin)
        if not server_key:
            return None, None
        dynamic_domain = get_value_from_links_file(links_file_path, 'ddy_final') if links_file_path else None
        if not dynamic_domain:
            xbmc.log("ddy_final missing in JSON file.", xbmc.LOGERROR)
            return None, None
        return build_m3u8_url(channel_key, server_key, dynamic_domain), origin
    except Exception as e:
        xbmc.log(f"[process_iframe_url] Error for channel {channel_id}: {e}", xbmc.LOGERROR)
        return None, None

# Fetches a specified value from the links config file.
def get_value_from_links_file(links_file_path: str, key: str) -> Optional[str]:
    """Fetches a specified value from the links config file."""
    try:
        with open(links_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get(key)
    except Exception as e:
        xbmc.log(f"[get_value_from_links_file] Error reading {key} from {links_file_path}: {e}", xbmc.LOGERROR)
        return None

def get_links_data(channel_id: str, links_file_path: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """Fetches multiple values from the links config file in a single call."""
    auth_url = get_value_from_links_file(links_file_path, 'auth_url')
    dynamic_domain = get_value_from_links_file(links_file_path, 'ddy_final')
    iframe_url = get_value_from_links_file(links_file_path, 'iframe_url')
    
    # If iframe_url is not None, format it with the channel_id.
    if iframe_url:
        iframe_url = iframe_url.format(channel_id=channel_id)
        m3u8_link, origin = process_iframe_url(iframe_url, channel_id, links_file_path)
    else:
        m3u8_link, origin = None, None
    
    return auth_url, dynamic_domain, iframe_url, (m3u8_link, origin)

# Get the m3u8 URL based on the service type.
def get_m3u8_ddy(channel_id: str, links_file_path: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """Gets the m3u8 URL only from the config file, without trying the website."""
    if links_file_path:
        try:
            auth_url, dynamic_domain, iframe_url, (m3u8_link, origin) = get_links_data(channel_id, links_file_path)
            if m3u8_link:
                xbmc.log(f"[get_m3u8_ddy] Found m3u8 in file: {m3u8_link}", xbmc.LOGDEBUG)
                return m3u8_link, origin
            else:
                xbmc.log("[get_m3u8_ddy] m3u8 link not found in file.", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[get_m3u8_ddy] Error reading links file: {e}", xbmc.LOGERROR)
    else:
        xbmc.log("[get_m3u8_ddy] links_file_path not provided.", xbmc.LOGERROR)
    return None, None

# The main entry point to get the m3u8 URL based on the service type.
def url_origin(channel_id: str, srv: str, links_file_path: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """Returns the m3u8 URL and origin based on the service type."""
    if not links_file_path:
        xbmc.log("[url_origin] No links file provided.", xbmc.LOGERROR)
        return None, None
    if srv == 'ddy':
        globals_data = initialize_globals(channel_id, links_file_path)
        if not globals_data:
            xbmc.log("[url_origin] Failed to initialize globals. Check links file or iframe URL.", xbmc.LOGERROR)
            return None, None
        authenticated = authenticate(
            globals_data["channel_key"],
            links_file_path,
            globals_data["auth_ts"],
            globals_data["auth_rnd"],
            globals_data["auth_sig"]
        )
        if not authenticated:
            xbmc.log("[url_origin] Authentication failed. Stopping process.", xbmc.LOGERROR)
            return None, None
        return get_m3u8_ddy(channel_id, links_file_path)
    else:
        raise ValueError(f'Unsupported service type: {srv}')
