import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse

def extract_m3u8_from_script(soup):
    script_tags = soup.find_all('script')
    
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    
    return None

def get_m3u8_top(channel_id):
    channel_number = ''.join(filter(str.isdigit, channel_id))
    url = f'https://topembed.pw/channel/YesSport{channel_number}[Israel]'

    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        m3u8_link = extract_m3u8_from_script(soup)

        if m3u8_link:
            # origin = urlparse(url).scheme + "://" + urlparse(url).netloc
            origin = 'https://topembed.pw'
            return m3u8_link, origin

    except requests.RequestException as e:
        print(f"Error accessing {url}: {e}")

    return None, None

def get_m3u8_ddy(channel_id):
    urls = [
        f'https://daddylive.sx/embed/stream-{channel_id}.php',
        f'https://miztv.shop/tele/stream-{channel_id}.php'
    ]
    
    for url in urls:
        try:
            response = requests.get(url, timeout=5)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            iframe = soup.find('iframe')

            if iframe and iframe.has_attr('src'):
                iframe_src = iframe['src']
                response = requests.get(iframe_src, timeout=5)
                response.raise_for_status()

                soup = BeautifulSoup(response.text, 'html.parser')
                m3u8_link = extract_m3u8_from_script(soup)

                if m3u8_link:
                    origin = urlparse(iframe_src).scheme + "://" + urlparse(iframe_src).netloc
                    return m3u8_link, origin

        except requests.RequestException as e:
            print(f"Error accessing {url}: {e}")

    return None, None

def url_origin(channel_id, srv):
    if srv == 'top':
        return get_m3u8_top(channel_id)
    elif srv == 'ddy':
        return get_m3u8_ddy(channel_id)
    else:
        raise ValueError('Unsupported service type.')