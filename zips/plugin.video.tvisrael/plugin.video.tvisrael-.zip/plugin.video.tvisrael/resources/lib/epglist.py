# -*- coding: utf-8 -*-
import os, io, time, datetime, json, re, glob, requests
import common
from import_xbmc import xbmc, xbmcaddon, xbmcvfs

# Fetches the EPG data and saves it to a file.
def fetch_and_save_epg():
    epg_file = common.epg_file
    epg_url = common.epg_url
    try:
        response = requests.get(epg_url)
        response.raise_for_status()
        json_data = response.json()
        # Ensure json_data is valid before dumping to file
        if isinstance(json_data, (dict, list)):
            with open(epg_file, "w", encoding="utf-8") as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
            generate_channels_guide()
        else:
            xbmc.log("Fetched data is not in JSON format", xbmc.LOGERROR)
    except requests.RequestException as e:
        xbmc.log(f"Error fetching EPG: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Unexpected error while fetching EPG: {e}", xbmc.LOGERROR)

# Generates the IPTV list in M3U format.
def generate_iptv_list(videos):
    iptv_list = "#EXTM3U\n"
    timeshift = ""
    if common.get_addon_setting("iptv_shift") == "true":
        timeshift = (
            "\n#KODIPROP:inputstream=inputstream.ffmpegdirect\n"
            "#KODIPROP:inputstream.ffmpegdirect.stream_mode=timeshift\n"
            "#KODIPROP:inputstream.ffmpegdirect.is_realtime_stream=true\n"
            "#KODIPROP:mimetype=video/mp2t"
        )

    for video in videos:
        try:
            tvg_id = video.get("tvgid", "")
            view_name = common.get_locale_string(video.get("name", ""))
            tvg_logo = f'special://home/addons/{common.Addon_ID}/resources/images/{video.get("thumb", "")}'
            group = ' group-title="TVIsrael"'
            url = f'plugin://{common.Addon_ID}/?mode=1&url={video.get("nid", "")}'
            iptv_list += f'{timeshift}\n#EXTINF:-1 tvg-id="{tvg_id}"{group} tvg-logo="{tvg_logo}",{view_name}\n{url}\n'
        except Exception as ex:
            xbmc.log(
                f'Error processing video {video.get("name", "Unknown")}: {ex}',
                xbmc.LOGERROR,
            )

    # Compare and write the new IPTV list to file if changed
    if not is_list_equal(common.m3u_file, iptv_list):
        with io.open(common.m3u_file, "w", encoding="utf-8") as f:
            f.write(str(iptv_list))

# Checks if the new IPTV list is different from the old one.
def is_list_equal(file_path, new_list):
    if os.path.isfile(file_path):
        with io.open(file_path, "r", encoding="utf-8") as f:
            old_list = f.read()
        return old_list == new_list
    return False

# Converts a timestamp to the specified timezone.
def convert_timestamp_to_timezone(timestamp, timezone_offset=None):
    try:
        if timezone_offset is None or timezone_offset == "":
            tz = datetime.datetime.fromtimestamp(
                timestamp
            ) - datetime.datetime.utcfromtimestamp(timestamp)
        else:
            tz = float(timezone_offset)
            tz = (
                datetime.timedelta(hours=tz)
                if tz >= 0
                else datetime.timedelta(hours=-tz)
            )
        formatted_time = time.strftime("%Y%m%d%H%M%S", time.localtime(timestamp))
        formatted_offset = (
            f"{int(tz.seconds // 3600):+03d}{int((tz.seconds // 60) % 60):02d}"
        )
        return f"{formatted_time} {formatted_offset}"
    except ValueError as e:
        xbmc.log(f"Error converting timestamp: {e}", xbmc.LOGERROR)
        return None

# Generates the channels guide in XML format.
def generate_channels_guide():
    time_zone = common.get_addon_setting("time_zone")
    if common.get_addon_setting("use_IPTV") != "true":
        return

    channels_list = ""
    programme_list = ""
    epg_data = common.read_list(common.epg_file)

    if not epg_data:
        return

    for channel_id, programmes in epg_data.items():
        channels_list += f'\t<channel id="{common.escape_xml(channel_id)}">\n\t\t<display-name>{channel_id}</display-name>\n\t</channel>\n'

        for programme in programmes:
            start = convert_timestamp_to_timezone(programme["start"], time_zone)
            end = convert_timestamp_to_timezone(programme["end"], time_zone)

            if start and end:
                name = common.escape_xml(programme.get("name", ""))
                description = common.escape_xml(programme.get("description", ""))
                programme_list += f'\t<programme start="{start}" stop="{end}" channel="{common.escape_xml(channel_id)}">\n\t\t<title>{name}</title>\n\t\t<desc>{description}</desc>\n\t</programme>\n'

    xml_data = f'<?xml version="1.0" encoding="UTF-8"?>\n<tv>\n{channels_list}{programme_list}</tv>'
    with io.open(common.xml_file, "w", encoding="utf-8") as f:
        f.write(xml_data)

# Enables the IPTV client if not already enabled.
def enable_iptv_client():
    try:
        if not common.is_addon_installed("pvr.iptvsimple"):
            common.install_addon("pvr.iptvsimple")
        if not common.is_addon_enabled("pvr.iptvsimple"):
            xbmc.executebuiltin("EnableAddon(pvr.iptvsimple)")
        return True
    except Exception as ex:
        xbmc.log(f"Error enabling IPTV client: {ex}", xbmc.LOGERROR)
    return False

# Opens the IPTV client settings.
def open_iptv_client_settings():
    if enable_iptv_client():
        xbmc.executebuiltin("Addon.OpenSettings(pvr.iptvsimple)")

# Sets the IPTV client settings.
def set_iptv_client_settings():
    if enable_iptv_client():
        settings = {
            "kodi_addon_instance_name": common.Addon_Name,
            "kodi_addon_instance_enabled": "true",
            "m3uPathType": "0",
            "m3uPath": common.m3u_file,
            "epgPathType": "0",
            "epgPath": common.xml_file,
            "startNum": "1",
            "m3uRefreshMode": "1",
            "m3uRefreshIntervalMins": "5",
        }

        iptvAddon = xbmcaddon.Addon("pvr.iptvsimple")
        try:
            # the settings are saved in a file
            iptv_addon_profile_dir = xbmcvfs.translatePath(
                iptvAddon.getAddonInfo("profile")
            )
            settings_files = sorted(
                glob.glob(
                    os.path.join(iptv_addon_profile_dir, "instance-settings-*.xml")
                ),
                reverse=True,
            )

            target_file = None
            for s_file in settings_files:
                content = common.get_text_file(s_file)
                if common.Addon_Name in content:
                    target_file = s_file
                    break

            # If no target file found, use the first settings file or log an error
            if not target_file:
                if settings_files:
                    last_file = settings_files[-1]
                    last_index = int(
                        re.search(r"instance-settings-(\d+)\.xml", last_file).group(1)
                    )
                    new_index = last_index + 1

                else:
                    new_index = 0

                target_file = os.path.join(
                    iptv_addon_profile_dir, f"instance-settings-{new_index}.xml"
                )
                content = '<settings version="2">\n</settings>'
                xbmc.log(f"Creating new settings file: {target_file}", xbmc.LOGINFO)
            else:
                content = common.get_text_file(target_file)

            if not re.search(r'<settings\b[^>]*\bversion\s*=\s*"', content):
                content = re.sub(
                    r"<settings\b", '<settings version="2"', content, count=1
                )

            is_change = False

            for key, val in settings.items():
                pattern = f'<setting id="{key}".*?>(.*?)</setting>'
                match = re.search(pattern, content)
                if match:
                    current_val = match.group(1)
                else:
                    pattern = f'<setting id="{key}".*?/>'
                    current_val = ""
                if current_val != val:
                    if re.search(f'<setting id="{key}".*?>', content):
                        safe_val = val.replace("\\", "/")
                        content = re.sub(
                            f'<setting id="{key}".*?>(.*?)</setting>',
                            f'<setting id="{key}" default="true">{safe_val}</setting>',
                            content,
                        )
                    else:
                        content = content.replace(
                            "</settings>",
                            f'    <setting id="{key}" default="true">{val}</setting>\n</settings>',
                        )
                    is_change = True
            if is_change:
                with io.open(target_file, "w", encoding="utf-8") as f:
                    f.write(content)
                xbmc.log(f"Updated IPTV settings in {target_file}", xbmc.LOGINFO)
                common.clean_user_settings()
                xbmc.executebuiltin("RestartAddon(pvr.iptvsimple)")
            else:
                xbmc.log("No changes needed in IPTV settings", xbmc.LOGDEBUG)

        except Exception as ex:
            xbmc.log(f"IPTV setup error: {ex}", xbmc.LOGERROR)
