import random

# Default safari and applewebkit version
DSAV = "537.36"
MOZILLA = "Mozilla/5.0"
KHTML = "(KHTML, like Gecko)"

# iOS versions and build numbers
ios_versions = ["17_2", "17_3", "18_1", "18_3_2"]
ios_builds = {
    "17_2": ["17B102", "17B103", "17B104"],
    "17_3": ["17E5233e", "17E5234f", "17E5235g"],
    "18_1": ["18A2301", "18A2302"],
    "18_3_2": ["18D101", "18D102", "18D103"]
}

# Define browser version ranges (min, max)
browser_version_ranges = {
    "Chrome": (100, 134),
    "Firefox": (115, 140),
    "Edge": (100, 138),
    "Opera": (80, 106),
    "Safari": (11, 18)
}

# Random platform generation
def generate_platform():
    platforms_mobile = [
        f"Linux; Android {random.randint(13, 16)}",
        f"iPhone; CPU iPhone OS {random.choice(ios_versions)} like Mac OS X"
    ]
    platforms_desktop = [
        "Windows NT 10.0; Win64; x64",
        "Macintosh; Intel Mac OS X 13_5",
        "X11; Linux x86_64"
    ]
    return random.choice(platforms_mobile + platforms_desktop)

# Random iOS build number based on version
def random_ios_build_number(version):
    return random.choice(ios_builds.get(version, [])) if version else "Unknown"

# Random browser version generator within the specified range
def generate_browser_version(browser, platform):
    min_version, max_version = browser_version_ranges.get(browser, (100, 100))
    major = random.randint(min_version, max_version)
    minor = random.randint(0, 9999)
    patch = random.randint(0, 150)
    version = f"{major}.0.{minor}.{patch}"

    # Build the user agent string
    return f"{MOZILLA} ({platform}) AppleWebKit/{DSAV} {KHTML} {browser}/{version} Safari/{DSAV}"

# Firefox version string (special case)
def generate_firefox_version(platform):
    min_version, max_version = browser_version_ranges.get("Firefox", (70, 110))
    version = f"{random.randint(min_version, max_version)}.0"
    return f"{MOZILLA} ({platform}; rv:{version}) Gecko/20100101 Firefox/{version}"

# Generate user agent string
def generate_user_agent():
    browser_map = {
        "Chrome": lambda platform: generate_browser_version("Chrome", platform),
        "Firefox": lambda platform: generate_firefox_version(platform),
        "Edge": lambda platform: generate_browser_version("Edge", platform),
        "Opera": lambda platform: generate_browser_version("Opera", platform),
        "Safari": lambda platform: f"{MOZILLA} ({platform}) AppleWebKit/{DSAV} {KHTML} Safari/{DSAV}",
    }

    browser = random.choice(list(browser_map.keys()))
    platform = generate_platform()

    # Handle Safari on iPhone
    if browser == "Safari" and "iPhone" in platform:
        ios_version = platform.split("OS ")[1].split(" ")[0]
        build_number = random_ios_build_number(ios_version)
        safari_version = "605.1.15"
        return f"{MOZILLA} ({platform}) AppleWebKit/{safari_version} {KHTML} Version/{ios_version.replace('_', '.')} Mobile/{build_number} Safari/{safari_version}"

    # Call the relevant function from the browser_map
    return browser_map[browser](platform)
