# -*- coding: utf-8 -*-
import time
import common
from import_xbmc import xbmc


class MyMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        xbmc.log(
            "[service] Check if settings changed to applying changes", xbmc.LOGDEBUG
        )
        try:
            common.make_iptv_files(show_progress=True)
        except Exception as e:
            xbmc.log(f"[service] Error applying changes: {e}", xbmc.LOGERROR)


monitor = MyMonitor()

if common.Addon.getSettingBool("version_check_startup"):
    common.check_version(startup=True)


def run_scheduler():
    xbmc.log("[run_scheduler] Service.py started", xbmc.LOGDEBUG)
    common.channel_list_features()
    epg_interval = common.Addon.getSettingInt("update_EPG_interval") * 3600
    next_epg = time.time() + epg_interval

    while not monitor.abortRequested():
        now = time.time()

        if now >= next_epg:
            try:
                common.update_epg_files()
                xbmc.log("[run_scheduler] update_epg_files executed", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"[run_scheduler] Error in scheduler: {e}", xbmc.LOGERROR)

            next_epg = now + epg_interval

        if monitor.waitForAbort(5):
            break

    xbmc.log("[run_scheduler] Service stopped gracefully", xbmc.LOGINFO)


run_scheduler()
