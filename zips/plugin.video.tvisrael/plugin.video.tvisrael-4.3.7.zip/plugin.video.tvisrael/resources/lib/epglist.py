# -*- coding: utf-8 -*-
import glob
import io
import os
import re
import time
import requests
import gzip
import json

import common
from import_xbmc import xbmc, xbmcaddon, xbmcvfs, xbmcgui


def get_af_base():
    server_choice = common.Addon.getSettingInt("server")
    servers = {
        0: "bethoven",
        1: "chopin",
        2: "tchaikovsky",
    }
    return f"http://{servers[server_choice]}.af-stream.com:8080"


# Fetches the EPG data and saves it to a file.
def fetch_and_build_epg(force=False):
    if common.get_addon_setting("use_IPTV") != "true":
        return

    if not force and not common.is_file_old(common.epg_file, 7200):  # 2 hours
        xbmc.log("[EPG] EPG file is still fresh, skipping download", xbmc.LOGDEBUG)
        return

    channels = common.load_channels()
    if not channels:
        return

    # nid -> tvgid
    channel_map = {
        ch["nid"]: ch["tvgid"] for ch in channels if ch.get("nid") and ch.get("tvgid")
    }
    if not channel_map:
        return
    try:
        epg_url = f"{common.github_epg}"
        headers = {"User-Agent": common.user_agent}
        r = requests.get(epg_url, headers=headers, timeout=60)
        r.raise_for_status()
        raw = r.content
        xbmc.log(f"[EPG] Downloaded EPG bytes={len(raw)}", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[EPG] Failed downloading EPG: {e}", xbmc.LOGERROR)
        return

    try:
        if raw[:2] == b"\x1f\x8b":  # gzip magic
            raw = gzip.decompress(raw)
            xbmc.log(f"[EPG] Decompressed gzip, xml bytes={len(raw)}", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[EPG] Failed decompressing gzip: {e}", xbmc.LOGERROR)
        return

    if not raw.lstrip().startswith(b"<"):
        xbmc.log(f"[EPG] Invalid XML, first bytes={raw[:100]!r}", xbmc.LOGERROR)
        return

    try:
        with io.open(common.epg_file, "wb") as f:
            f.write(raw)
        xbmc.log("[EPG] EPG XML saved successfully", xbmc.LOGINFO)
        restart_pvr_client()
    except Exception as e:
        xbmc.log(f"[EPG] Failed writing EPG XML: {e}", xbmc.LOGERROR)


# Global flag to prevent multiple simultaneous IPTV refreshes
pvr_refreshing = False


# Restarts the IPTV Simple Client.
def restart_pvr_client(show_progress=False):
    global pvr_refreshing
    IPTV_NAME = "IPTV Simple Client"
    addon_id = "pvr.iptvsimple"
    xbmc.log(
        f"[restart_pvr_client] {IPTV_NAME} Starting (show_progress={show_progress})",
        xbmc.LOGDEBUG,
    )

    if pvr_refreshing:
        xbmc.log(
            "[restart_pvr_client] Refresh already in progress - skipping", xbmc.LOGDEBUG
        )
        return False

    pvr_refreshing = True
    progress = None
    try:
        is_playing = xbmc.Player().isPlaying()
        if is_playing:
            show_progress = False
            show_toast = False
            xbmc.log(
                "[restart_pvr_client] Media playing → silent refresh", xbmc.LOGINFO
            )
        else:
            show_toast = True
            xbmc.log(
                f"[restart_pvr_client] Refresh mode: {'Progress' if show_progress else 'Toast only'}",
                xbmc.LOGINFO,
            )
        if show_progress:
            progress = xbmcgui.DialogProgress()
            progress.create(
                common.get_locale_string(30403), common.get_locale_string(30423)
            )
            progress.update(
                33, common.get_locale_string(30424).format(step="1", IPTV=IPTV_NAME)
            )

        try:
            xbmc.executebuiltin(f"RestartAddon({addon_id})")
            xbmc.sleep(1200)
            if show_progress:
                progress.update(
                    66, common.get_locale_string(30425).format(step="2", IPTV=IPTV_NAME)
                )
            if wait_for_channels(timeout=12000):
                if show_toast:
                    common.notify(30702, 30421)
            else:
                if show_toast:
                    common.notify(30702, 30422)

        except Exception as e:
            xbmc.log(f"[restart_pvr_client] RestartAddon failed: {e}", xbmc.LOGERROR)
            # Fallback: try to disable and re-enable the addon if RestartAddon fails
            try:
                xbmc.log("[restart_pvr_client] Trying fallback...", xbmc.LOGWARNING)
                xbmc.executeJSONRPC(
                    json.dumps(
                        {
                            "jsonrpc": "2.0",
                            "method": "Addons.SetAddonEnabled",
                            "params": {"addonid": addon_id, "enabled": False},
                            "id": 1,
                        }
                    )
                )
                xbmc.sleep(1000)
                xbmc.executeJSONRPC(
                    json.dumps(
                        {
                            "jsonrpc": "2.0",
                            "method": "Addons.SetAddonEnabled",
                            "params": {"addonid": addon_id, "enabled": True},
                            "id": 1,
                        }
                    )
                )
                xbmc.sleep(1500)
                if show_progress:
                    progress.update(
                        66,
                        common.get_locale_string(30425).format(
                            step="2", IPTV=IPTV_NAME
                        ),
                    )
                if wait_for_channels(timeout=12000) and show_toast:
                    common.notify(30702, 30421)
            except Exception as e2:
                xbmc.log(
                    f"[restart_pvr_client] Failed to restart {IPTV_NAME}: {e2}",
                    xbmc.LOGERROR,
                )
                if show_toast:
                    common.notify(30702, 30422)
    finally:
        if progress:
            progress.close()
        pvr_refreshing = False


# Wait for channels
def wait_for_channels(timeout=12000, check_interval=500):
    start_time = time.time()
    xbmc.log("[wait_for_channels] Waiting for channels to load...", xbmc.LOGDEBUG)

    while (time.time() - start_time) * 1000 < timeout:
        try:
            result = xbmc.executeJSONRPC(
                json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "method": "PVR.GetChannels",
                        "params": {"channelgroupid": "alltv"},
                        "id": 1,
                    }
                )
            )

            data = json.loads(result)
            channel_count = len(data.get("result", {}).get("channels", []))
            if channel_count > 0:
                xbmc.log(
                    f"[wait_for_channels] Success - {channel_count} channels loaded",
                    xbmc.LOGDEBUG,
                )
                return True

        except Exception:
            pass
        xbmc.sleep(check_interval)
    xbmc.log("[wait_for_channels] Timeout - no channels detected", xbmc.LOGWARNING)
    return False


# Generates the IPTV list in M3U format.
def generate_iptv_list(videos, show_progress=False):
    iptv_list = '#EXTM3U catchup-type="shift"\n'

    for video in videos:
        try:
            tvg_id = video.get("tvgid", "")
            if tvg_id:
                logo_filename = f"{tvg_id}.png"
                tvg_logo = f"special://userdata/addon_data/{common.Addon_ID}/logos/{logo_filename}"
            else:
                tvg_logo = ""
            view_name = common.get_local_lang_name(video)
            group = f' group-title="{common.get_locale_string(30300)}"'
            url = f'{get_af_base()}/s/{common.get_addon_setting("user_token")}/{video.get("nid", "")}/video.m3u8'
            iptv_list += f'\n#EXTINF:-1 tvg-id="{tvg_id}"{group} tvg-logo="{tvg_logo}" catchup-days="7",{view_name}\n{url}\n'
        except Exception as ex:
            xbmc.log(
                f'Error processing video {video.get("name", "Unknown")}: {ex}',
                xbmc.LOGERROR,
            )

    # Compare and write the new IPTV list to file if changed
    if not is_list_equal(common.m3u_file, iptv_list):
        xbmc.log(
            "[generate_iptv_list] Channels list changed – applying changes",
            xbmc.LOGDEBUG,
        )
        with io.open(common.m3u_file, "w", encoding="utf-8") as f:
            f.write(str(iptv_list))
        restart_pvr_client(show_progress=show_progress)


# Checks if the new IPTV list is different from the old one.
def is_list_equal(file_path, new_list):
    if os.path.isfile(file_path):
        with io.open(file_path, "r", encoding="utf-8") as f:
            old_list = f.read()
        return old_list == new_list
    return False


# Enables the IPTV client if not already enabled.
def enable_iptv_client():
    try:
        if not common.is_addon_installed("pvr.iptvsimple"):
            common.install_addon("pvr.iptvsimple")
        if not common.is_addon_enabled("pvr.iptvsimple"):
            xbmc.executebuiltin("EnableAddon(pvr.iptvsimple)")
        return True
    except Exception as ex:
        xbmc.log(f"Error enabling IPTV client: {ex}", xbmc.LOGERROR)
    return False


# Opens the IPTV client settings.
def open_iptv_client_settings():
    if enable_iptv_client():
        xbmc.executebuiltin("Addon.OpenSettings(pvr.iptvsimple)")


# Sets the IPTV client settings.
def set_iptv_client_settings():
    if enable_iptv_client():
        settings = {
            "kodi_addon_instance_name": common.Addon_Name,
            "kodi_addon_instance_enabled": "true",
            "m3uPathType": "0",
            "m3uPath": common.m3u_file,
            "epgPathType": "0",
            "epgPath": common.epg_file,
            "startNum": "1",
            "m3uRefreshMode": "1",
            "m3uRefreshIntervalMins": "5",
            "timeshiftEnabled": "true",
            "catchupEnabled": "true",
            "catchupDays": "7",
        }

        iptvAddon = xbmcaddon.Addon("pvr.iptvsimple")
        try:
            # the settings are saved in a file
            iptv_addon_profile_dir = xbmcvfs.translatePath(
                iptvAddon.getAddonInfo("profile")
            )
            settings_files = sorted(
                glob.glob(
                    os.path.join(iptv_addon_profile_dir, "instance-settings-*.xml")
                ),
                reverse=True,
            )

            target_file = None
            for s_file in settings_files:
                content = common.get_text_file(s_file)
                if common.Addon_Name in content:
                    target_file = s_file
                    break

            # If no target file found, use the first settings file or log an error
            if not target_file:
                if settings_files:
                    last_file = settings_files[-1]
                    last_index = int(
                        re.search(r"instance-settings-(\d+)\.xml", last_file).group(1)
                    )
                    new_index = last_index + 1

                else:
                    new_index = 0

                target_file = os.path.join(
                    iptv_addon_profile_dir, f"instance-settings-{new_index}.xml"
                )
                content = '<settings version="2">\n</settings>'
                xbmc.log(f"Creating new settings file: {target_file}", xbmc.LOGINFO)
            else:
                content = common.get_text_file(target_file)

            if not re.search(r'<settings\b[^>]*\bversion\s*=\s*"', content):
                content = re.sub(
                    r"<settings\b", '<settings version="2"', content, count=1
                )

            is_change = False

            for key, val in settings.items():
                pattern = f'<setting id="{key}".*?>(.*?)</setting>'
                match = re.search(pattern, content)
                if match:
                    current_val = match.group(1)
                else:
                    pattern = f'<setting id="{key}".*?/>'
                    current_val = ""
                if current_val != val:
                    if re.search(f'<setting id="{key}".*?>', content):
                        safe_val = val.replace("\\", "/")
                        content = re.sub(
                            f'<setting id="{key}".*?>(.*?)</setting>',
                            f'<setting id="{key}" default="true">{safe_val}</setting>',
                            content,
                        )
                    else:
                        content = content.replace(
                            "</settings>",
                            f'    <setting id="{key}" default="true">{val}</setting>\n</settings>',
                        )
                    is_change = True
            if is_change:
                with io.open(target_file, "w", encoding="utf-8") as f:
                    f.write(content)
                xbmc.log(f"Updated IPTV settings in {target_file}", xbmc.LOGINFO)
                restart_pvr_client()
            else:
                xbmc.log("No changes needed in IPTV settings", xbmc.LOGDEBUG)

        except Exception as ex:
            xbmc.log(f"IPTV setup error: {ex}", xbmc.LOGERROR)
