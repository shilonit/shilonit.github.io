# -*- coding: utf-8 -*-
import sys
import os, requests
from urllib.parse import parse_qsl, urlencode

import common
import epglist as epg
from import_xbmc import xbmc, xbmcgui, xbmcplugin, xbmcaddon

# Global variables
addon_handle = common.get_handle()
channels_list = common.load_channels()


# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f"{sys.argv[0]}?{urlencode(kwargs)}"
    except Exception as e:
        xbmc.log(f"Error creating URL: {e}", xbmc.LOGERROR)
        return ""


# Display the categories list with channels and settings
def categories_list():
    title = common.get_locale_string(30402)

    xbmcplugin.setPluginCategory(addon_handle, common.get_label_color(title, bold=True, color="purple"))
    xbmcplugin.setContent(addon_handle, "videos")

    img_tv         = common.get_addon_icon("tv.jpg")
    img_sports     = common.get_addon_icon("sports.jpg")
    channels_label = common.get_locale_string(30504)
    settings_label = common.get_locale_string(30401)
    channels_name  = common.get_label_color(channels_label, bold=True, color="none")
    settings_name  = common.get_label_color(settings_label, bold=True, color="yellow")
    items          = []

    # Channels section
    channels_url = get_url(mode=7)
    if not channels_url:
        xbmc.log("Failed to create channels URL", xbmc.LOGERROR)
        return

    li = xbmcgui.ListItem(label=channels_name)
    li.setArt({"thumb": img_sports, "icon": img_sports, "fanart": img_sports})
    info = li.getVideoInfoTag()
    info.setTitle(str(channels_label))
    items.append((channels_url, li, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        li = xbmcgui.ListItem(label=settings_name)
        li.setArt({"thumb": img_tv, "icon": img_tv, "fanart": img_tv})
        info = li.getVideoInfoTag()
        info.setTitle(str(settings_label))
        items.append((settings_url, li, False))

    xbmcplugin.addDirectoryItems(addon_handle, items)
    xbmcplugin.endOfDirectory(addon_handle)


def fetch_token_from_access_key():
    addon = xbmcaddon.Addon(common.Addon_ID)
    access_key = addon.getSetting("access_key").strip()
    # reset old user_token
    addon.setSetting("user_token", "")
    if not access_key:
        common.notify(30700, 30714)
        return False
    url = f"http://af-play.com/playlist/{access_key}.m3u8"
    headers = {"User-Agent": common.user_agent}
    try:
        r = requests.get(url, headers=headers, timeout=10)
        r.raise_for_status()
        text = r.text
    except Exception as e:
        xbmc.log(f"[TOKEN] Failed fetching playlist: {e}", xbmc.LOGERROR)
        # common.notify(30700, 30715)
        return False
    user_token = None
    for line in text.splitlines():
        line = line.strip()
        if "/s/" in line and "/video.m3u8" in line:
            # http://bethoven.af-stream.com:8080/s/{user_token}/{nid}/video.m3u8
            parts = line.split("/s/", 1)[1].split("/")
            if len(parts) >= 2:
                user_token = parts[0]
                break
    if not user_token and access_key:
        xbmc.log("[TOKEN] Token not found in playlist", xbmc.LOGERROR)
        common.notify(30700, 30716)
        return False
    addon.setSetting("user_token", user_token)
    xbmc.log(f"[TOKEN] Token stored: {user_token}", xbmc.LOGINFO)
    common.notify(30702, 30717)
    return True


# Get all channels sorted by user preferences
def get_all_channels():
    for channel in channels_list:

        xbmc.log(f"Checking channel: nid={channel['nid']}, tvgid={channel['tvgid']}, index={channel['index']}", xbmc.LOGDEBUG)
        if not isinstance(channel["index"], int):
            xbmc.log(f"Invalid index value detected: {channel['index']}", xbmc.LOGERROR)

    user_channels = [
        channel
        for channel in channels_list
        if common.get_int_setting(channel["tvgid"], channel["index"]) > 0
    ]
    sorted_channels = sorted(user_channels, key=lambda k: k["index"])
    return sorted_channels


# Create IPTV files and launch the addon
def make_iptv_files():
    token = common.get_addon_setting("user_token")
    if not token:
        xbmc.log("[IPTV] No user token – skipping IPTV build", xbmc.LOGWARNING)
        return
    epg.generate_iptv_list(get_all_channels())


# Perform actions during the first run of the addon
def clean_profile_dir():
    keep_files = {
        common.M3U_Name,
        common.Xml_Name,
        os.path.basename(common.user_settings),
    }
    try:
        for item in os.listdir(common.profile_dir):
            item_path = os.path.join(common.profile_dir, item)
            if item not in keep_files:
                try:
                    os.remove(item_path)
                    xbmc.log(
                        f"[first_run] Removed leftover file: {item}", xbmc.LOGDEBUG
                    )
                except Exception as e:
                    xbmc.log(f"[first_run] Failed removing {item}: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"[first_run] Failed cleaning profile dir: {e}", xbmc.LOGERROR)


def first_run():
    clean_profile_dir()
    if not fetch_token_from_access_key():
        xbmc.log(
            "[first_run] Token validation failed – aborting setup", xbmc.LOGWARNING
        )
        common.notify(30700, 30716)
        return
    make_iptv_files()
    epg.set_iptv_client_settings()
    common.notify(30500, 30412)


# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f"Addon.OpenSettings({common.Addon_ID})")


# Launch the EPG window
def launch_epg():
    if epg.pvr_refreshing:
        common.notify(30420, 30407)
        return
    xbmc.executebuiltin("ActivateWindow(TVGuide,pvr://channels/tv)")


# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin("ActivateWindow(pvrsettings)")


# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get("mode")

    actions = {
        "-1": categories_list,
        "1": lambda: (first_run(), sys.exit()),
        "2": open_settings,
        "3": lambda: (epg.open_iptv_client_settings(), sys.exit()),
        "4": lambda: (make_iptv_files(), common.notify(30805, 30413), sys.exit()),

        "5": lambda: (epg.set_iptv_client_settings(), common.notify(30414, 30415), sys.exit()),

        "6": lambda: (epg.fetch_and_build_epg(), common.notify(30407, 30408)),
        "7": launch_epg,
        "8": lambda: (open_pvrsettings(), sys.exit()),
        "9": lambda: (common.check_version(), sys.exit()),
        "10": lambda: common.open_window("guide-qr.xml"),
        "11": lambda: common.open_window("register-qr.xml"),
    }

    if mode in actions:
        actions[mode]()
    else:
        if params:
            xbmc.log(f"Invalid mode: {mode}", xbmc.LOGERROR)
            sys.exit()
        else:
            categories_list()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
