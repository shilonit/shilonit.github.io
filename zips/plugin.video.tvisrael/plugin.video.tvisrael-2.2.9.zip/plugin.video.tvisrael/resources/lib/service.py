import xbmc

xbmc.executebuiltin('AlarmClock(tvisrael,RunPlugin(plugin://plugin.video.tvisrael/?mode=4&source=alarm),10:00:00,silent,loop)')
