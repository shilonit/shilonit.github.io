# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcvfs
import sys, os, io, json, re, collections, time, random, requests
from resources.lib.UA import userAgents

AddonID = 'plugin.video.tvisrael'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
AddonVer = Addon.getAddonInfo('version')
AddonName = "TV Israel"

userAgent = random.choice(userAgents)

# Decode and encode functions
def decode(text, dec, force=False):
    if force:
        text = bytearray(text, 'utf-8').decode(dec)
    return text

def encode(text, dec):
    return text

# Translate path function
def translatePath(path):
    return xbmcvfs.translatePath(path)

# Global variables
addonPath = Addon.getAddonInfo('path')

# Profile directory creation
profileDir = decode(translatePath(Addon.getAddonInfo("profile")), "utf-8")
if not os.path.exists(profileDir):
    os.makedirs(profileDir)

imagesDir = decode(translatePath(os.path.join(addonPath, 'resources', 'images')), "utf-8")
epgFile = os.path.join(profileDir, 'epg.json')
epgURL = 'https://raw.githubusercontent.com/shilonit/epgtools/main/sport/epg.json'

# Utility function to safely get handle from arguments
def GetHandle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1

# Get icon full path
def GetIconFullPath(icon):
    return os.path.join(imagesDir, icon)

# Check if an addon is installed
def IsAddonInstalled(addonid):
    return xbmc.getCondVisibility(f'System.HasAddon({addonid})')

# Install addon
def InstallAddon(addonid):
    xbmc.executebuiltin(f'InstallAddon({addonid})')

# Check if addon is enabled
def IsAddonEnabled(addonid):
    try:
        response = json.loads(xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'))
        return response['result']['addon']['enabled']
    except json.JSONDecodeError:
        return False

# Enable addon
def EnableAddon(addonid):
    method = 'EnableAddon' if GetKodiVer() >= 19 else 'Addons.SetAddonEnabled'
    xbmc.executebuiltin(f'{method}({addonid})')

# Disable addon
def DisableAddon(addonid):
    xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{addonid}","enabled":false}},"id":1}}')

# Get Kodi version
def GetKodiVer():
    return float(re.split(' |\-', xbmc.getInfoLabel('System.BuildVersion'))[0])

# Get localized string
def GetLocaleString(id):
    return encode(Addon.getLocalizedString(id), 'utf-8')

# Get label color
def GetLabelColor(text, keyColor=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(keyColor)
    if bold:
        text = f'[B]{text}[/B]'
    return text if color == 'none' else f'[COLOR {color}]{text}[/COLOR]'

# Read and return settings from addon
def GetAddonSetting(key):
    return Addon.getSetting(key)

# Read a list from a file
def ReadList(fileName):
    try:
        with io.open(fileName, 'r', encoding='utf-8') as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except Exception as ex:
        xbmc.log(str(ex), 3)
        return []

# Escape XML special characters
def EscapeXML(text):
    if isinstance(text, bytes):
        text = text.decode('utf-8')
    return text.replace('&', '&amp;').replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")

# Check if file is older than a given threshold
def isFileOld(filename, deltaInSec=10800):
    lastUpdate = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - lastUpdate) > deltaInSec

# Get integer setting, defaulting if necessary
def GetIntSetting(k, v=0):
    setting = Addon.getSetting(k)
    if not setting.isdigit():
        Addon.setSetting(k, str(v))
    return int(setting)

# Delete a file safely
def DelFile(aFile):
    try:
        if os.path.isfile(aFile):
            os.unlink(aFile)
    except Exception as ex:
        xbmc.log(str(ex), 3)

# Open URL and handle requests
def OpenURL(url, headers=None, retries=1, verify=True):
    link = ""
    headers = headers or {}
    if 'Accept-encoding' not in headers:
        headers['Accept-encoding'] = 'gzip'
    if 'User-agent' not in headers:
        headers['User-agent'] = userAgent
    for attempt in range(1, retries+1):
        try:
            response = requests.get(url, headers=headers, verify=verify)
            xbmc.log(f'{url}  -  attempt {attempt} response {response.status_code}.', 3)
            if response.status_code == 200:
                link = response.json()
                break
            else:
                xbmc.log(f"Error {response.status_code}: {response.text}", 3)
        except requests.exceptions.RequestException as ex:
            xbmc.log(f"Error during request: {str(ex)}", 3)
    return link if link else None

# Get updated list from a URL and handle file extraction if necessary
def GetUpdatedList(listFile, listUrl, headers=None, deltaInSec=10800, isZip=False, sort=False, decode_text=None):
    if isFileOld(listFile, deltaInSec=deltaInSec):
        try:
            aFile = f'{listFile}.zip' if isZip else listFile
            DelFile(aFile)
            data = OpenURL(listUrl, headers=headers, retries=3)
            if not data:
                return []
            with io.open(aFile, 'wb') as f:
                if decode_text:
                    data = data.decode(decode_text).encode('utf-8')
                f.write(data)
            if isZip:
                xbmc.executebuiltin(f"Extract({aFile}, {profileDir})", True)
                DelFile(aFile)
        except Exception as ex:
            xbmc.log(str(ex), 3)
    items = ReadList(listFile)
    return sorted(items, key=lambda x: x.get('name')) if sort else items

# Get text content from a file
def GetTextFile(filename):
    if os.path.isfile(filename):
        with io.open(filename, 'r', encoding="utf-8") as f:
            return f.read()
    return ''
