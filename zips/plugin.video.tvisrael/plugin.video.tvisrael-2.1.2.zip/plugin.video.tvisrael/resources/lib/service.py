import xbmc

refreshCommand = 'RunPlugin(plugin://plugin.video.tvisrael/?mode=4)'
xbmc.executebuiltin(refreshCommand)
xbmc.executebuiltin(f'AlarmClock(tvisrael,{refreshCommand},10:00:00,silent,loop)')