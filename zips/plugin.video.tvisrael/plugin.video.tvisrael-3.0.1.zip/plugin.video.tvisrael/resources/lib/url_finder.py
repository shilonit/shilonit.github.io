# -*- coding: utf-8 -*-
import base64, json, re, requests
from typing import Optional, Tuple, Dict
from urllib.parse import urlparse, parse_qsl
from bs4 import BeautifulSoup

import common
from import_xbmc import xbmc

# Globals

BASE_URL = "https://daddylive.sx"
TOP_URL  = "https://topembed.pw/"
DDY2_URL = "https://lovecdn.ru"

### For main.py settings
SUPPORTED_SRVS_ORDER = ["ddy", "ap", "top"]
SRV_INLINE_HEADERS   = {"ddy", "top"}
SRV_LABEL_IDS        = {"ddy": 30951, "top": 30952, "ap": 30953}

session = requests.Session()
session.headers.update({"User-Agent": common.user_agent})


# Config helpers
def get_value(key: str) -> Optional[str]:
    try:
        with open(common.links_path, "r", encoding="utf-8") as f:
            return json.load(f).get(key)
    except Exception as e:
        xbmc.log(f"[get_value] Error reading {key}: {e}", xbmc.LOGERROR)
        return None


def get_url(key: str) -> str:
    global BASE_URL, TOP_URL, DDY2_URL
    m = {"base_url": "BASE_URL", "top_url": "TOP_URL", "ddy2_url": "DDY2_URL"}
    if key in m:
        val = get_value(key)
        if val:
            globals()[m[key]] = val
        return globals()[m[key]]
    return ""


# HTTP helpers
def http_get(
    url: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    allow_redirects: bool = False,
    timeout: int = 15,
    retries: int = 3,
    delay_ms: int = 1000,
) -> Optional[requests.Response]:
    for attempt in range(1, retries + 1):
        try:
            r = session.get(
                url,
                headers=headers or {},
                timeout=timeout,
                allow_redirects=allow_redirects,
            )
            if 400 <= r.status_code:
                r.raise_for_status()
            return r
        except Exception as e:

            xbmc.log(f"[http_get] {attempt}/{retries} failed for {url} hdrs={headers}: {e}", xbmc.LOGERROR)
            xbmc.sleep(delay_ms)
    xbmc.log(f"[http_get] all {retries} attempts failed for {url}", xbmc.LOGERROR)
    return None


def make_same_origin_headers(origin: str) -> Dict[str, str]:
    o = origin.rstrip("/")
    return {"Origin": o, "Referer": o + "/", "User-Agent": common.user_agent}


# Shared helpers used by DDY/AP/TOP
def extract_first(p: re.Pattern, text: str, name: str) -> str:
    m = p.search(text)
    if not m:
        raise RuntimeError(f"Missing '{name}' in the HTML/JS (pattern not found).")
    return m.groupdict().get("val") or m.group(1)


# DDY/TOP
def build_iframe_url(base_iframe_url: str, srv: str, channel_id: str) -> Optional[str]:
    if not base_iframe_url:
        return None
    base_iframe_url = base_iframe_url.rstrip("/")

    if srv in ("ddy"):
        path = "premiumtv/daddyhd.php"
        return f"{base_iframe_url}/{path}?id={channel_id}"
    elif srv == "top":
        return f"{get_url('top_url')}/channel/YesSport{channel_id}[Israel]"
    elif srv == "ap":
        return f"{get_url('ddy2_url')}/daddy.php?stream={channel_id}"
    return None


def extract_auth_data(page_content: str) -> dict:

    encoded_vars = dict(re.findall(r'const\s+([A-Za-z0-9_]+)\s*=\s*"([^"]+)"', page_content))

    parse_matches = re.findall(r'JSON\.parse\(\s*atob\(\s*([A-Za-z0-9_]+)\s*\)\s*\)', page_content)
    encoded_value = None
    for var in parse_matches:
        if var in encoded_vars:
            encoded_value = encoded_vars[var]
            break
    if not encoded_value:
        return {}
    try:
        decoded_json = base64.b64decode(encoded_value).decode()
        parts = json.loads(decoded_json)
    except Exception:
        return {}
    for k, v in list(parts.items()):
        try:
            val = base64.b64decode(v).decode()
            if k == "b_script" and val == "a.php":
                val = "auth.php"
            parts[k] = val
        except Exception:
            pass

    def find_key(prefix):
        return next((v for k, v in parts.items() if k.startswith(prefix)), None)

    channel_match = re.search(r'const\s+CHANNEL_KEY\s*=\s*"([^"]+)"', page_content)
    channel_key = channel_match.group(1) if channel_match else None
    xbmc.log(f"[extract_auth_data] parts: {parts}", xbmc.LOGDEBUG)
    return {
        "channel_key": channel_key,
        "auth_ts": find_key("b_ts"),
        "auth_rnd": find_key("b_rnd"),
        "auth_sig": find_key("b_sig"),
        "auth_url": (find_key("b_host") or "") + (find_key("b_script") or ""),
    }



def authenticate(channel_key, auth_ts, auth_rnd, auth_sig, auth_url, ddy_final, headers: Optional[dict] = None) -> bool:
    if not auth_url:
        xbmc.log("[authenticate] missing auth_url", xbmc.LOGERROR)
        return False
    url = f"{auth_url}?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    hdrs = dict(headers or {})
    hdrs["Host"] = ddy_final or ""
    resp = http_get(url, headers=hdrs)
    if not resp:
        return False
    try:
        return resp.json().get("status") == "ok"
    except Exception:
        xbmc.log("authenticate: invalid JSON", xbmc.LOGERROR)
        return False


def get_server_key(channel_key, origin) -> Optional[str]:
    try:
        url = f"{origin}/server_lookup.php?channel_id={channel_key}"
        r = session.get(url, timeout=5)
        if not r.ok:
            xbmc.log(f"get_server_key: HTTP {r.status_code} for {url}", xbmc.LOGERROR)
            return None
        return r.json().get("server_key")
    except Exception as e:
        xbmc.log(f"get_server_key: {e}", xbmc.LOGERROR)
        return None


def build_m3u8_url(channel_key, server_key, dynamic_domain) -> str:
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"


def resolve_ddy_like(channel_id: str, srv: str) -> Tuple[Optional[str], Optional[dict]]:
    base_iframe_url = get_value("iframe_url")
    iframe_url = build_iframe_url(base_iframe_url, srv, channel_id)
    ddy_final = get_value("ddy_final")
    if not iframe_url:
        xbmc.log("[resolve_ddy_like] failed to build iframe_url", xbmc.LOGERROR)
        return None, {}

    # Fetch iframe page ONCE
    resp = http_get(iframe_url)
    if not resp:
        xbmc.log("[resolve_ddy_like] failed to fetch iframe content", xbmc.LOGERROR)
        return None, {}
    page = resp.text or ""
    auth = extract_auth_data(page)
    channel_key = auth.get("channel_key") or (
        "premium" + str(channel_id) if srv == "ddy" else None
    )
    if not channel_key:
        xbmc.log("[resolve_ddy_like] missing channel_key", xbmc.LOGERROR)
        return None, {}
    origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
    if all(auth.get(k) for k in ("auth_ts", "auth_rnd", "auth_sig", "auth_url")):
        hdrs = make_same_origin_headers(origin)

        if not authenticate(channel_key, auth["auth_ts"],auth["auth_rnd"], auth["auth_sig"], auth["auth_url"], ddy_final, headers=hdrs):
            xbmc.log("[resolve_ddy_like] auth failed", xbmc.LOGERROR)
            return None, {}
    server_key = get_server_key(channel_key, origin)
    if not server_key:
        xbmc.log("[resolve_ddy_like] server_key not found", xbmc.LOGERROR)
        return None, {}
    m3u8 = build_m3u8_url(channel_key, server_key, ddy_final)
    return m3u8, make_same_origin_headers(origin)


#  AP
EMBED_IFRAME_RE = re.compile(
    r"""src=['"](?P<u>https?://[^"']+/(?P<cid>[^/"']+)/embed\.html\?[^"'#]*?token=(?P<tok>[A-Za-z0-9\-]+)[^"'#]*?)['"]""",
    re.IGNORECASE,
)


def find_embed_token_src(html: str) -> Optional[Tuple[str, str, str]]:
    m = EMBED_IFRAME_RE.search(html or "")
    if m:
        return m.group("u"), m.group("cid"), m.group("tok")
    try:
        soup = BeautifulSoup(html or "", "html.parser")
        for fr in soup.find_all("iframe"):
            src = fr.get("src") or ""
            if "embed.html" in src and "token=" in src:
                m2 = re.search(r"/([^/]+)/embed\.html", src)
                m3 = re.search(r"[?&]token=([A-Za-z0-9\-]+)", src)
                if m2 and m3:
                    return src, m2.group(1), m3.group(1)
    except Exception:
        pass
    return None


def get_m3u8_ap(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    base_iframe_url = get_value("iframe_url")
    iframe_url = build_iframe_url(base_iframe_url, "ap", channel_id)
    if not iframe_url:
        xbmc.log("[get_m3u8_ap] failed to build iframe_url", xbmc.LOGERROR)
        return None, {}
    referer_origin = get_url("base_url")
    first_hdrs = make_same_origin_headers(referer_origin)
    resp = http_get(iframe_url, headers=first_hdrs, allow_redirects=True)
    if not resp or not (resp.text or "").strip():
        xbmc.log("[get_m3u8_ap] failed to fetch iframe page", xbmc.LOGERROR)
        return None, first_hdrs
    found = find_embed_token_src(resp.text)
    if not found:
        xbmc.log("[get_m3u8_ap] embed iframe with token not found", xbmc.LOGERROR)
        return None, first_hdrs
    full_embed_url, cid_from_iframe, token = found
    cid = cid_from_iframe or str(channel_id)
    p = urlparse(full_embed_url)
    embed_origin = get_url("ddy2_url")
    pre_hdrs = make_same_origin_headers(embed_origin)
    pre = http_get(full_embed_url, headers=pre_hdrs, allow_redirects=True)
    if not pre:
        xbmc.log("[get_m3u8_ap] prefetch embed.html failed", xbmc.LOGERROR)
        return None, pre_hdrs
    final = f"{p.scheme}://{p.netloc}/{cid}/index.fmp4.m3u8?token={token}"
    stream_hdrs = {"Referer": full_embed_url, "User-Agent": common.user_agent}
    return final, stream_hdrs



def check_url_status(url: str, headers: Optional[Dict[str, str]] = None, timeout: int = 7, inline: bool = True) -> Tuple[bool, Optional[int], Optional[str]]:
    hdrs: Dict[str, str] = headers or {}
    if inline:
        if isinstance(headers, dict):
            hdrs: Dict[str, str] = headers
        elif isinstance(headers, str):
            hdrs = dict(parse_qsl(headers, keep_blank_values=True))
        else:
            hdrs = {}
    else:
        hdrs = headers or {}
    try:
        r = session.get(
            url,
            headers=hdrs,
            allow_redirects=True,
            timeout=timeout,
            stream=True,
        )
        return (200 <= r.status_code < 300), r.status_code, r.reason
    except Exception as ex:
        xbmc.log(f"[check_url_status] failed for {url}: {ex}", xbmc.LOGERROR)
        return False, None, None


def validated_return(m3u8: Optional[str], headers: Optional[Dict[str, str]], srv: Optional[str] = None) -> Tuple[Optional[str], Optional[Dict[str, str]]]:
    if not m3u8 or m3u8 in ("None", ""):
        xbmc.log(f"[validated_return] no URL returned for srv={srv}", xbmc.LOGWARNING)
        return None, {}
    inline = (srv or "").lower() in SRV_INLINE_HEADERS
    ok, code, reason = check_url_status(m3u8, headers, inline=inline)
    if not ok:

        xbmc.log(f"[url_origin] m3u8 HTTP status {code or 'NO_STATUS'} {reason or ''} for {m3u8}", xbmc.LOGERROR)
        return None, {}
    return m3u8, (headers or {})


#  Common entry point

def url_origin(srv: str, idval: str, channel_nid: str) -> Tuple[Optional[str], Optional[dict]]:
    try:
        s = (srv or "").strip().lower()
        link: Optional[str] = None
        hdrs: Optional[Dict[str, str]] = None

        if s in ("ddy", "top"):
            link, hdrs = resolve_ddy_like(idval, s)

        elif s == "ap":
            link, hdrs = get_m3u8_ap(idval)

        else:

            xbmc.log(f"[url_origin] unsupported srv '{srv}' for nid={channel_nid}", xbmc.LOGERROR)
            return None, {}
        if not link:

            xbmc.log(f"[url_origin] no link returned for nid={channel_nid}, srv={srv}", xbmc.LOGWARNING)
            return None, {}
        return validated_return(link, hdrs, s)
    except Exception as e:
        xbmc.log(f"[url_origin] error nid={channel_nid} srv={srv}: {e}", xbmc.LOGERROR)
        return None, {}
