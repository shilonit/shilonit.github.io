import os, io, time, datetime, json, requests, re, glob
import xbmc, xbmcaddon
import resources.lib.common as common

m3uFile = os.path.join(common.profileDir, 'tvisrael.m3u')
xmlFile = os.path.join(common.profileDir, 'epg.xml')

# Fetches the EPG data and saves it to a file.
def fetch_and_save_epg():
    epgFile = common.epgFile
    epgURL = common.epgURL
    try:
        response = requests.get(epgURL)
        response.raise_for_status()
        json_data = response.json()
        # Ensure json_data is valid before dumping to file
        if isinstance(json_data, (dict, list)):
            with open(epgFile, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
            generate_channels_guide()
        else:
            xbmc.log("Fetched data is not in JSON format", xbmc.LOGERROR)
    except requests.RequestException as e:
        xbmc.log(f"Error fetching EPG: {e}", xbmc.LOGERROR)
    except Exception as e:  # Handle unexpected errors
        xbmc.log(f"Unexpected error while fetching EPG: {e}", xbmc.LOGERROR)
    

# Generates the IPTV list in M3U format.
def generate_iptv_list(videos):
    iptvList = '#EXTM3U\n'
    timeshift = ''
    if common.GetAddonSetting('useIPTVtimeshift') == 'true':
        timeshift = (
            '\n#KODIPROP:inputstream=inputstream.ffmpegdirect\n'
            '#KODIPROP:inputstream.ffmpegdirect.stream_mode=timeshift\n'
            '#KODIPROP:inputstream.ffmpegdirect.is_realtime_stream=true\n'
            '#KODIPROP:mimetype=video/mp2t'
        )

    for video in videos:
        try:
            tvg_id = video.get('tvgid', '')
            view_name = common.GetLocaleString(video.get('name', ''))
            tvg_logo = f'special://home/addons/{common.AddonID}/resources/images/{video.get("thumb", "")}'
            group = ' group-title="TVIsrael"'
            url = f'plugin://{common.AddonID}/?mode=1&url={video.get("id", "")}'
            iptvList += f'{timeshift}\n#EXTINF:-1 tvg-id="{tvg_id}"{group} tvg-logo="{tvg_logo}",{view_name}\n{url}\n'
        except Exception as ex:
            xbmc.log(f'Error processing video {video.get("name", "Unknown")}: {ex}', xbmc.LOGERROR)

    # Compare and write the new IPTV list to file if changed
    if not is_list_equal(m3uFile, iptvList):
        with io.open(m3uFile, 'w', encoding="utf-8") as f:
            f.write(str(iptvList))

# Checks if the new IPTV list is different from the old one.
def is_list_equal(file_path, new_list):
    if os.path.isfile(file_path):
        with io.open(file_path, 'r', encoding="utf-8") as f:
            old_list = f.read()
        return old_list == new_list
    return False

# Converts a timestamp to the specified timezone.
def convert_timestamp_to_timezone(timestamp, timezone_offset=None):
    try:
        if timezone_offset is None or timezone_offset == '':
            tz = datetime.datetime.fromtimestamp(timestamp) - datetime.datetime.utcfromtimestamp(timestamp)
        else:
            tz = float(timezone_offset)
            tz = datetime.timedelta(hours=tz) if tz >= 0 else datetime.timedelta(hours=-tz)
        formatted_time = time.strftime('%Y%m%d%H%M%S', time.localtime(timestamp))
        formatted_offset = f'{int(tz.seconds // 3600):+03d}{int((tz.seconds // 60) % 60):02d}'
        return f'{formatted_time} {formatted_offset}'
    except ValueError as e:
        xbmc.log(f"Error converting timestamp: {e}", xbmc.LOGERROR)
        return None

# Generates the channels guide in XML format.
def generate_channels_guide():
    global timeZone
    timeZone = common.GetAddonSetting('timeZone')
    if common.GetAddonSetting('useIPTV') != 'true':
        return

    channels_list = ""
    programme_list = ""
    epg_data = common.ReadList(common.epgFile)

    if not epg_data:
        return

    for channel_id, programmes in epg_data.items():
        channel_name = common.encode(channel_id, "utf-8")
        channels_list += f"\t<channel id=\"{common.EscapeXML(channel_name)}\">\n\t\t<display-name>{channel_name}</display-name>\n\t</channel>\n"
        
        for programme in programmes:
            start = convert_timestamp_to_timezone(programme["start"], timeZone)
            end = convert_timestamp_to_timezone(programme["end"], timeZone)

            if start and end:
                name = common.EscapeXML(common.encode(programme.get("name", ""), "utf-8"))
                description = common.EscapeXML(common.encode(programme.get("description", ""), "utf-8"))
                programme_list += f"\t<programme start=\"{start}\" stop=\"{end}\" channel=\"{common.EscapeXML(channel_name)}\">\n\t\t<title>{name}</title>\n\t\t<desc>{description}</desc>\n\t</programme>\n"

    xml_data = f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<tv>\n{channels_list}{programme_list}</tv>"
    with io.open(xmlFile, 'w', encoding="utf-8") as f:
        f.write(xml_data)

# Enables the IPTV client if not already enabled.
def enable_iptv_client():
    try:
        if not common.IsAddonInstalled('pvr.iptvsimple'):
            common.InstallAddon('pvr.iptvsimple')
        if not common.IsAddonEnabled('pvr.iptvsimple'):
            common.EnableAddon('pvr.iptvsimple')
        return True
    except Exception as ex:
        xbmc.log(f"Error enabling IPTV client: {ex}", xbmc.LOGERROR)
    return False

# Opens the IPTV client settings.
def open_iptv_client_settings():
    if enable_iptv_client():
        xbmc.executebuiltin('Addon.OpenSettings(pvr.iptvsimple)')

# Sets the IPTV client settings.
def set_iptv_client_settings():
    if enable_iptv_client():  # Check if the IPTV client is enabled
        settings = {
            "m3uPathType": "0",
            "m3uPath": os.path.join(common.Addon.getAddonInfo("profile"), 'tvisrael.m3u'),
            "epgPathType": "0",
            "epgPath": os.path.join(common.Addon.getAddonInfo("profile"), 'epg.xml'),
            "startNum": "1",
        }

        iptvAddon = xbmcaddon.Addon('pvr.iptvsimple')
        
        try:
            kodiVer = common.GetKodiVer()
            
            if kodiVer >= 20:
                # On Kodi 20 and above, the settings are saved in a file
                iptvAddonProfileDir = common.decode(common.translatePath(iptvAddon.getAddonInfo("profile")), "utf-8")
                settingsFiles = sorted(glob.glob(os.path.join(iptvAddonProfileDir, 'instance-settings-*.xml')), reverse=True)
                
                if settingsFiles:
                    settingsFile = settingsFiles[0]
                    j = settingsFile.rfind('.')
                    i = settingsFile[:j].rfind('-')
                    index = int(settingsFile[i + 1:j])
                    settingsNewFile = f'{settingsFile[:i + 1]}{index + 1}{settingsFile[j:]}'

                    content = common.GetTextFile(settingsFile)

                    for sFile in settingsFiles:
                        theFile = True
                        for key, val in settings.items():
                            pattern = f'<setting id="{key}".*?>(.*?)</setting>'
                            oldVal = re.findall(pattern, content)
                            if not oldVal:
                                pattern = f'<setting id="{key}".*?/>'
                                oldVal = re.findall(pattern, content)
                            else:
                                oldVal = oldVal[0]
                            if oldVal != val:
                                theFile = False
                                break
                        if theFile:
                            settingsNewFile = sFile
                            settingsFile = sFile
                            content = common.GetTextFile(settingsFile)
                            break

                    # Add the instance name and enable settings
                    settings["kodi_addon_instance_name"] = "TV Israel"
                    settings["kodi_addon_instance_enabled"] = "true"

                    isChange = False
                    for key, val in settings.items():
                        pattern = f'<setting id="{key}".*?>(.*?)</setting>'
                        a = re.findall(pattern, content)
                        if not a:
                            pattern = f'<setting id="{key}".*?/>'
                            a = re.findall(pattern, content)
                        else:
                            a = a[0]
                        l = re.search(pattern, content)
                        if a != val:
                            content = content.replace(content[l.start():l.end()], f'<setting id="{key}" default="true">{val}</setting>')
                            isChange = True

                    if isChange:
                        with io.open(settingsNewFile, 'w', encoding="utf-8") as f:
                            f.write(content)
            else:
                # On Kodi 18 and below, the settings are saved in the addon settings
                for key, val in settings.items():
                    if iptvAddon.getSetting(key) != val:
                        iptvAddon.setSetting(key, val)

            #   Disable and enable the IPTV client to apply the settings
            if kodiVer >= 18:
                common.DisableAddon('pvr.iptvsimple')
                common.EnableAddon('pvr.iptvsimple')

        except Exception as ex:
            xbmc.log(f"IPTV setup error: {ex}", xbmc.LOGERROR)
