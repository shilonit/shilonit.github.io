# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcvfs
import sys, os, io, json, re, collections, time, random, requests
from resources.lib.UA import userAgents

AddonID = 'plugin.video.tvisrael'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
AddonVer = Addon.getAddonInfo('version')
AddonName = "TV Israel"

userAgent = random.choice(userAgents)

# Decode and encode functions
def decode(text, dec, force=False):
    if force:
        text = bytearray(text, 'utf-8').decode(dec)
    return text

def encode(text, dec):
    return text

# Translate path function
def translatePath(path):
    return xbmcvfs.translatePath(path)

# Global variables
addonPath = Addon.getAddonInfo('path')

# Profile directory creation
profileDir = decode(translatePath(Addon.getAddonInfo("profile")), "utf-8")
if not os.path.exists(profileDir):
    os.makedirs(profileDir)

imagesDir = decode(translatePath(os.path.join(addonPath, 'resources', 'images')), "utf-8")
epgFile = os.path.join(profileDir, 'epg.json')
epgURL = 'https://raw.githubusercontent.com/shilonit/epgtools/main/sport/epg.json'

# Utility function to safely get handle from arguments
def GetHandle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1

# Get icon full path
def GetIconFullPath(icon):
    return os.path.join(imagesDir, icon)

# Check if an addon is installed
def IsAddonInstalled(addonid):
    return xbmc.getCondVisibility(f'System.HasAddon({addonid})')

# Install addon
def InstallAddon(addonid):
    xbmc.executebuiltin(f'InstallAddon({addonid})')

# Check if addon is enabled
def IsAddonEnabled(addonid):
    try:
        response = json.loads(xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'))
        return response['result']['addon']['enabled']
    except json.JSONDecodeError:
        return False

# Enable addon
def EnableAddon(addonid):
    method = 'EnableAddon' if GetKodiVer() >= 19 else 'Addons.SetAddonEnabled'
    xbmc.executebuiltin(f'{method}({addonid})')

# Disable addon
def DisableAddon(addonid):
    xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{addonid}","enabled":false}},"id":1}}')

# Get Kodi version
def GetKodiVer():
    return float(re.split(' |\-', xbmc.getInfoLabel('System.BuildVersion'))[0])

# Get localized string
def GetLocaleString(id):
    return encode(Addon.getLocalizedString(id), 'utf-8')

# Get label color
def GetLabelColor(text, keyColor=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(keyColor)
    if bold:
        text = f'[B]{text}[/B]'
    return text if color == 'none' else f'[COLOR {color}]{text}[/COLOR]'

# Read and return settings from addon
def GetAddonSetting(key):
    return Addon.getSetting(key)

# Read a list from a file
def ReadList(fileName):
    try:
        with io.open(fileName, 'r', encoding='utf-8') as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except Exception as ex:
        xbmc.log(str(ex), 3)
        return []

# Escape XML special characters
def EscapeXML(text):
    if isinstance(text, bytes):
        text = text.decode('utf-8')
    return text.replace('&', '&amp;').replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")

# Check if file is older than a given threshold
def isFileOld(filename, deltaInSec=10800):
    lastUpdate = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - lastUpdate) > deltaInSec

# Get integer setting, defaulting if necessary
def GetIntSetting(k, v=0):
    setting = Addon.getSetting(k)
    if not setting.isdigit():
        Addon.setSetting(k, str(v))
    return int(setting)

# Get text content from a file
def GetTextFile(filename):
    if os.path.isfile(filename):
        with io.open(filename, 'r', encoding="utf-8") as f:
            return f.read()
    return ''

# Fetches the EPG data and saves it to a file.
def save_links_json():
    linksFile = os.path.join(profileDir, 'ddy_url.json')
    linksURL = 'https://raw.githubusercontent.com/shilonit/epgtools/refs/heads/main/sport/ddy_url.json'
    try:
        response = requests.get(linksURL)
        response.raise_for_status()
        json_data = response.json()
        # Ensure json_data is valid before dumping to file
        if isinstance(json_data, (dict, list)):
            with open(linksFile, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
        else:
            xbmc.log("Fetched data is not in JSON format", xbmc.LOGERROR)
    except requests.RequestException as e:
        xbmc.log(f"Error fetching linksFile: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Unexpected error while fetching linksFile: {e}", xbmc.LOGERROR)