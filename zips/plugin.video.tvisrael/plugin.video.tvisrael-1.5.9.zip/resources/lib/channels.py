﻿# -*- coding: utf-8 -*-
Tvs = [
    { 'nid': 'sport1', 'index': 30, 'name': 30602, 'thumb': 'sport_1.jpg', 'srv': 'ddy', 'id': '140', 'tvgid': 'sport1' },
    { 'nid': 'sport1b', 'index': 30, 'name': 30652, 'thumb': 'sport_1.jpg', 'srv': 'top', 'id': 'sport1il', 'tvgid': 'sport1' },
    { 'nid': 'sport2', 'index': 31, 'name': 30603, 'thumb': 'sport_2.jpg', 'srv': 'ddy', 'id': '141', 'tvgid': 'sport2' },
    { 'nid': 'sport2b', 'index': 31, 'name': 30653, 'thumb': 'sport_2.jpg', 'srv': 'top', 'id': 'sport2il', 'tvgid': 'sport2' },
    { 'nid': 'sport3', 'index': 32, 'name': 30604, 'thumb': 'sport_3.jpg', 'srv': 'ddy', 'id': '142', 'tvgid': 'sport3' },
    { 'nid': 'sport3b', 'index': 32, 'name': 30654, 'thumb': 'sport_3.jpg', 'srv': 'top', 'id': 'sport3il', 'tvgid': 'sport3' },
    { 'nid': 'sport4', 'index': 33, 'name': 30605, 'thumb': 'sport_4.jpg', 'srv': 'ddy', 'id': '143', 'tvgid': 'sport4' },
    { 'nid': 'sport4b', 'index': 33, 'name': 30655, 'thumb': 'sport_4.jpg', 'srv': 'top', 'id': 'sport4il', 'tvgid': 'sport4' },
    { 'nid': 'sport5', 'index': 34, 'name': 30606, 'thumb': 'sport_5.jpg', 'srv': 'ddy', 'id': '144', 'tvgid': 'sport5' },
    { 'nid': 'sport5b', 'index': 34, 'name': 30656, 'thumb': 'sport_5.jpg', 'srv': 'top', 'id': 'sport5il', 'tvgid': 'sport5' },
    { 'nid': '5plus', 'index': 35, 'name': 30607, 'thumb': '5_plus.jpg', 'srv': 'ddy', 'id': '145', 'tvgid': '5plus' },
    { 'nid': '5live', 'index': 36, 'name': 30608, 'thumb': '5_live.jpg', 'srv': 'ddy', 'id': '146', 'tvgid': '5live' },
    { 'nid': '5star', 'index': 37, 'name': 30609, 'thumb': '5_stars.jpg', 'srv': 'ddy', 'id': '147', 'tvgid': '5stars' },
    { 'nid': '5gold', 'index': 38, 'name': 30610, 'thumb': '5_gold.jpg', 'srv': 'ddy', 'id': '148', 'tvgid': '5gold'},
    { 'nid': 'one', 'index': 39, 'name': 30611, 'thumb': 'One.jpg', 'srv': 'ddy', 'id': '541', 'tvgid': 'ONE' },
    { 'nid': 'one2', 'index': 40, 'name': 30612, 'thumb': 'One_2.jpg', 'srv': 'ddy', 'id': '542', 'tvgid': 'ONE2' },
    { 'nid': 'yes_action', 'index': 41, 'name': 30613, 'thumb': 'Yes_Action.png', 'srv': 'ddy', 'id': '543', 'tvgid': 'yes_action'},
    { 'nid': 'yes_kids', 'index': 42, 'name': 30614, 'thumb': 'Yes_Kids.png', 'srv': 'ddy', 'id': '544', 'tvgid': 'yes_kids' },
    { 'nid': 'yes_comedy', 'index': 43, 'name': 30615, 'thumb': 'Yes_Comedy.png', 'srv': 'ddy', 'id': '545', 'tvgid': 'yes_comedy' },
    { 'nid': 'hot_3', 'index': 44, 'name': 30616, 'thumb': 'Hot_3.png', 'srv': 'ddy', 'id': '553', 'tvgid': 'HOT3' }
]
