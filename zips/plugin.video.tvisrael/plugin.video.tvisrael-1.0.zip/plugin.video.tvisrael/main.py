# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui, xbmcplugin
import resources.lib.common as common

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
handle = common.GetHandle()

VIDEOS = {'ספורט': [{'name': 'ספורט 1', 'thumb': common.GetIconFullPath('sport1.jpg'), 'id': '140', 'genre': 'ספורט'},
                        {'name': 'ספורט 2', 'thumb': common.GetIconFullPath('sport2.jpg'), 'id': '141', 'genre': 'ספורט'},
                        {'name': 'ספורט 3', 'thumb': common.GetIconFullPath('sport3.jpg'), 'id': '142', 'genre': 'ספורט'},
                        {'name': 'ספורט 4', 'thumb': common.GetIconFullPath('sport4.jpg'), 'id': '143', 'genre': 'ספורט'},
                        {'name': 'ספורט 5', 'thumb': common.GetIconFullPath('sport5.jpg'), 'id': '144', 'genre': 'ספורט'},
                        {'name': 'ספורט 5 פלוס', 'thumb': common.GetIconFullPath('sport5_plus.jpg'), 'id': '145', 'genre': 'ספורט'},
                        {'name': 'ספורט 5 לייב', 'thumb': common.GetIconFullPath('sport5_live.jpg'), 'id': '146', 'genre': 'ספורט'},
                        {'name': 'ספורט 5 סטאר', 'thumb': common.GetIconFullPath('sport5_star.jpg'), 'id': '147', 'genre': 'ספורט'},
                        {'name': 'ספורט 5 גולד', 'thumb': common.GetIconFullPath('sport5_gold.jpg'), 'id': '148', 'genre': 'ספורט'},
                        {'name': 'ספורט ONE', 'thumb': common.GetIconFullPath('SportOne-1.png'), 'id': '541', 'genre': 'ספורט'},
                        {'name': 'ספורט ONE 2', 'thumb': common.GetIconFullPath('SportOne-2.png'), 'id': '542', 'genre': 'ספורט'}
                    ],
            'שונות': [{'name': 'יס אקשן', 'thumb': common.GetIconFullPath('YesAction.png'), 'id': '543', 'genre': 'טלוויזיה'},
                        {'name': 'יס קידס', 'thumb': common.GetIconFullPath('YesKids.png'), 'id': '544', 'genre': 'טלוויזיה'},
                        {'name': 'יס סרטים', 'thumb': common.GetIconFullPath('YesComedy.png'), 'id': '545', 'genre': 'טלוויזיה'},
                        {'name': 'הוט 3', 'thumb': common.GetIconFullPath('Hot3.png'), 'id': '553', 'genre': 'טלוויזיה'}
                       ]
        }

def get_url(**kwargs):
    return f'{_url}?{urlencode(kwargs)}'

def list_categories():
    xbmcplugin.setPluginCategory(handle, 'הערוצים שלי')
    xbmcplugin.setContent(handle, 'videos')
    categories = sorted(VIDEOS.keys())
    list_items = []
    for category in categories:
        first_video = VIDEOS[category][0]
        if first_video['genre'] == 'ספורט':
            img_screen = common.GetIconFullPath('sports.jpg')
        else:
            img_screen = common.GetIconFullPath('tv.jpg')
        list_item = xbmcgui.ListItem(label=category)
#        list_item.setArt({'thumb': first_video['thumb'], 'icon': first_video['thumb'], 'fanart': first_video['thumb']})
        list_item.setArt({'thumb': img_screen, 'icon': img_screen, 'fanart': img_screen})
        list_item.setInfo('video', {'title': category, 'genre': category, 'mediatype': 'video'})
        url = get_url(action='listing', category=category)
        is_folder = True
        list_items.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(handle, list_items)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)

def list_videos(category):
    xbmcplugin.setPluginCategory(handle, category)
    xbmcplugin.setContent(handle, 'videos')
    videos = VIDEOS.get(category, [])
    list_items = []
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['name'])
        list_item.setInfo('video', {'title': video['name'], 'genre': video['genre'], 'mediatype': 'video'})
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        list_item.setProperty('IsPlayable', 'true')
        referer ='https://lewblivehdplay.ru/'
        origin = 'https://lewblivehdplay.ru'
        userAgent = common.UserAgent
        channel_id = video['id']
        base_url = f'https://webhdrunns.mizhls.ru/lb/premium{channel_id}/index.m3u8'
#       base_url = 'https://eu-fls2.mizhls.ru/eu-fls2/premium{channel_id}/tracks-v1a1/mono.m3u8' 
        link = f'{base_url}|Referer={referer}&Origin={origin}&User-Agent={userAgent}'
        is_folder = False
        list_items.append((link, list_item, is_folder))
    xbmcplugin.addDirectoryItems(handle, list_items)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)

def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=play_item)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        action = params.get('action')
        category = params.get('category')
        video = params.get('video')
        if action == 'listing' and category:
            list_videos(category)
        elif action == 'play' and video:
            play_video(video)
        else:
            raise ValueError(f'Invalid paramstring: {paramstring}!')
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
