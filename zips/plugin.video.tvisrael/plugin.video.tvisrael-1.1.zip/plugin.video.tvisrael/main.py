# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui, xbmcplugin
import resources.lib.common as common
import resources.lib.channels as channels

# Global variables
_url = sys.argv[0]
_handle = common.GetHandle()
_channels_list = channels.tvs
_img_tv = common.GetIconFullPath('tv.jpg')

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def list_categories():
    xbmcplugin.setPluginCategory(_handle, 'הערוצים שלי')
    xbmcplugin.setContent(_handle, 'videos')
    categories = sorted(_channels_list.keys())
    list_items = []
    
    for category in categories:
        first_video = _channels_list[category][0]
        img_screen = common.GetIconFullPath('sports.jpg') if first_video['genre'] == 'ספורט' else _img_tv
        
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({'thumb': img_screen, 'icon': img_screen, 'fanart': img_screen})
        list_item.setInfo('video', {'title': category, 'genre': category, 'mediatype': 'video'})
        
        url = get_url(mode=-1, category=category)
        is_folder = True
        
        list_items.append((url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(_handle, list_items)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def list_videos(category):
    xbmcplugin.setPluginCategory(_handle, category)
    xbmcplugin.setContent(_handle, 'videos')
    
    videos = _channels_list.get(category, [])
    list_items = []
    
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['name'])
        list_item.setInfo('video', {'title': video['name'], 'genre': video['genre'], 'mediatype': 'video'})
        
        channel_img = common.GetIconFullPath(video['thumb'])
        list_item.setArt({'thumb': channel_img, 'icon': channel_img, 'fanart': channel_img})
        list_item.setProperty('IsPlayable', 'true')
        
        channel_id = video['id']
        list_items.append((get_url(mode=1, url=channel_id), list_item, False))

    xbmcplugin.addDirectoryItems(_handle, list_items)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def play_video(channel_id):
    if channel_id:
        base_url = f'https://webhdrunns.mizhls.ru/lb/premium{channel_id}/index.m3u8'
        headers = {
             'Accept': '*/*',
             'Host': 'webhdrunns.mizhls.ru',
             'Accept-Language': 'en-US,en;q=0.9',
             'Accept-Encoding': 'gzip, deflate, br, zstd',
             'Sec-Fetch-Mode': 'cors',
             'Sec-Fetch-Site': 'same-site',
             'TE': 'trailers',
             'DNT': '1',
             'Connection': 'keep-alive',
             'Referer': 'https://lewblivehdplay.ru/',
             'Origin': 'https://lewblivehdplay.ru',
             'User-Agent': common.UserAgent
    }
   
        link = f'{base_url}|{urlencode(headers)}'
        
        play_item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(handle=_handle, succeeded=True, listitem=play_item)
    else:
        xbmcgui.Dialog().ok('Playback Error', 'לא מצליח לנגן את הקובץ.')

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    
    if params:
        mode = params.get('mode')
        category = params.get('category')
        url = params.get('url')
        
        if mode == '-1' and category:
            list_videos(category)
        elif mode == '1' and url:
            play_video(url)
        else:
            raise ValueError(f'Invalid mode value: {mode}')
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
