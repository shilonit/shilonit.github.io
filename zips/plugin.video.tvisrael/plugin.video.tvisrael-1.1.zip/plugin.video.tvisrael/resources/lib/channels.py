tvs = {
    'ספורט': [
        {'name': 'ספורט 1', 'thumb': 'sport_1.jpg', 'id': '140', 'tvgid': 'sport1', 'genre': 'ספורט'},
        {'name': 'ספורט 2', 'thumb': 'sport_2.jpg', 'id': '141', 'tvgid': 'sport2', 'genre': 'ספורט'},
        {'name': 'ספורט 3', 'thumb': 'sport_3.jpg', 'id': '142', 'tvgid': 'sport3', 'genre': 'ספורט'},
        {'name': 'ספורט 4', 'thumb': 'sport_4.jpg', 'id': '143', 'tvgid': 'sport4', 'genre': 'ספורט'},
        {'name': 'ספורט 5', 'thumb': 'sport_5.jpg', 'id': '144', 'tvgid': 'sport5', 'genre': 'ספורט'},
        {'name': 'ספורט 5 פלוס', 'thumb': 'sport_5_plus.jpg', 'id': '145', 'tvgid': 'sport5plus', 'genre': 'ספורט'},
        {'name': 'ספורט 5 לייב', 'thumb': 'sport_5_live.jpg', 'id': '146', 'tvgid': 'sport5live', 'genre': 'ספורט'},
        {'name': 'ספורט 5 סטאר', 'thumb': 'sport_5_star.jpg', 'id': '147', 'tvgid': 'sport5star', 'genre': 'ספורט'},
        {'name': 'ספורט 5 גולד', 'thumb': 'sport_5_gold.jpg', 'id': '148', 'tvgid': 'sport5gold', 'genre': 'ספורט'},
        {'name': 'ספורט ONE', 'thumb': 'Sport_One.jpg', 'id': '541', 'tvgid': 'ONE', 'genre': 'ספורט'},
        {'name': 'ספורט ONE 2', 'thumb': 'Sport_One_2.jpg', 'id': '542', 'tvgid': 'ONE2', 'genre': 'ספורט'}
    ],
    'שונות': [
        {'name': 'יס אקשן', 'thumb': 'Yes_Action.png', 'id': '543', 'tvgid': 'yes_action', 'genre': 'טלוויזיה'},
        {'name': 'יס קידס', 'thumb': 'Yes_Kids.png', 'id': '544', 'tvgid': 'yes_kids', 'genre': 'טלוויזיה'},
        {'name': 'יס סרטים', 'thumb': 'Yes_Comedy.png', 'id': '545', 'tvgid': 'yes_drama', 'genre': 'טלוויזיה'},
        {'name': 'הוט 3', 'thumb': 'Hot_3.png', 'id': '553', 'tvgid': 'HOT3', 'genre': 'טלוויזיה'}
    ]
}