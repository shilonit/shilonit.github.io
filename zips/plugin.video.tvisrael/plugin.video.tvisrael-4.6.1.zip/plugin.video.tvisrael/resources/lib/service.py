import os
import time

import common
import constants as const
import epglist as epg
from import_xbmc import xbmc

EPG_RETRY_DELAY = 600  # seconds
EPG_STARTUP_MAX_AGE = 3600  # on Kodi start the guide is refreshed if older than this
OLD_DEFAULT_EPG_INTERVAL = 2  # hours - before 4.5.7
CHANNELS_INTERVAL = 6 * 3600  # check GitHub for a new channel list
TOKEN_INTERVAL = 24 * 3600  # re-read the stream token from af-play
VERSION_INTERVAL = 24 * 3600  # look for a new add-on version
SETUP_RETRY_DELAY = 15 * 60  # a failed automatic setup is retried after this


class MyMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.epg_interval = read_epg_interval()
        self.settings_changed = False

    # Only marks the change; the loop below does the work, so a slow network
    # never blocks Kodi's callback
    def onSettingsChanged(self):
        xbmc.log("[service] Settings changed", xbmc.LOGDEBUG)
        self.epg_interval = read_epg_interval()
        self.settings_changed = True


# EPG refresh interval from the settings, in seconds.
def read_epg_interval():
    return const.Addon.getSettingInt("update_EPG_interval") * 3600


# When the EPG file is due: its last change + the interval
def next_epg_update(interval):
    try:
        return os.path.getmtime(const.epg_file) + interval
    except OSError:
        return 0  # no file - now


# Runs one task; an unexpected error is logged and never stops the service
def run_task(name, func, *args, **kwargs):
    try:
        return func(*args, **kwargs)
    except Exception as e:  # noqa: BLE001 - the service must keep running
        xbmc.log(f"[service] {name} failed: {type(e).__name__}: {e}", xbmc.LOGERROR)
        return None


# A new access key was entered: get its token, build the channel list, set up
# IPTV Simple - what "initial setup" did, without the user pressing it.
def auto_setup(silent):
    xbmc.log("[service] New access key - running setup automatically", xbmc.LOGINFO)
    if not common.fetch_token_from_access_key(silent=silent):
        return False
    iptv_changed = epg.set_iptv_client_settings(restart=False)
    common.channel_list_features(restart=False)
    if iptv_changed:
        epg.set_pending_restart(force=True)
    if not silent:
        common.notify(30500, 30412)
    return True


# Re-reads the token; when af-play changed it, the M3U is rebuilt
def refresh_token():
    old = common.get_addon_setting("user_token")
    if common.fetch_token_from_access_key(silent=True):
        if common.get_addon_setting("user_token") != old:
            xbmc.log("[service] Stream token changed - rebuilding M3U", xbmc.LOGINFO)
            if common.make_iptv_files(restart=False):
                epg.set_pending_restart()


monitor = MyMonitor()


def run_scheduler():
    xbmc.log("[run_scheduler] Service.py started", xbmc.LOGDEBUG)
    now = time.time()
    setup_attempt = {"fp": None, "at": 0}

    def try_setup(silent):
        fp = common.key_fingerprint()
        # same key failed lately - wait (a corrected key is tried at once)
        if fp == setup_attempt["fp"] and time.time() - setup_attempt["at"] < SETUP_RETRY_DELAY:
            return
        setup_attempt.update(fp=fp, at=time.time())
        run_task("Automatic setup", auto_setup, silent)

    # 4.5.7: refresh every 6 hours instead of 2 - move users still on the old default
    if not common.get_addon_setting("epg_interval_v2"):
        if const.Addon.getSettingInt("update_EPG_interval") == OLD_DEFAULT_EPG_INTERVAL:
            const.Addon.setSettingInt("update_EPG_interval", 6)
        const.Addon.setSetting("epg_interval_v2", "true")
        monitor.epg_interval = read_epg_interval()

    if const.Addon.getSettingBool("version_check_startup"):
        run_task("Version check", common.check_version, startup=True)
    next_version = now + VERSION_INTERVAL

    # IPTV Simple settings of an existing install are brought up to date
    # (e.g. the streams' User-Agent added in 4.5.5)
    if common.get_addon_setting("user_token") and not common.needs_setup():
        if run_task("IPTV settings", epg.set_iptv_client_settings, restart=False):
            epg.set_pending_restart(force=True)

    if common.needs_setup():
        try_setup(silent=True)
        next_token = time.time() + TOKEN_INTERVAL
    else:
        changed = run_task("Channel list", common.channel_list_features, restart=False)
        if not changed and not monitor.abortRequested():
            run_task(
                "Logos",
                common.download_channel_logos,
                silent=True,
                max_age=const.LOGOS_MAX_AGE,
            )
        next_token = now + 60  # soon after start, once the network has settled
    next_channels = time.time() + CHANNELS_INTERVAL
    retry_after = 0

    # Every Kodi start: a guide older than an hour is refreshed now
    run_task("EPG update", common.update_epg_files, max_age=EPG_STARTUP_MAX_AGE)

    while not monitor.abortRequested():
        now = time.time()

        if monitor.settings_changed:
            monitor.settings_changed = False
            if common.needs_setup():
                try_setup(silent=False)  # the user is in the settings - show progress
            else:
                run_task("Apply settings", common.make_iptv_files, show_progress=True)

        if now >= next_epg_update(monitor.epg_interval) and now >= retry_after:
            run_task("EPG update", common.update_epg_files)
            retry_after = now + EPG_RETRY_DELAY

        if now >= next_channels:
            next_channels = now + CHANNELS_INTERVAL
            changed = run_task("Channel list", common.channel_list_features, restart=False)
            if not changed:
                run_task(
                    "Logos",
                    common.download_channel_logos,
                    silent=True,
                    max_age=const.LOGOS_MAX_AGE,
                )

        if now >= next_token:
            next_token = now + TOKEN_INTERVAL
            if common.get_addon_setting("access_key").strip():
                run_task("Token refresh", refresh_token)

        if now >= next_version:
            next_version = now + VERSION_INTERVAL
            if const.Addon.getSettingBool("version_check_startup"):
                run_task("Version check", common.check_version, startup=True)

        # A restart requested during the startup grace period runs once allowed
        run_task("Pending restart", epg.run_pending_restart)

        if monitor.waitForAbort(5):
            break

    xbmc.log("[run_scheduler] Service stopped gracefully", xbmc.LOGINFO)


run_scheduler()
