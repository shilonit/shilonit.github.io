# One fixed, well-formed browser User-Agent for every request of the add-on:
# the af-play playlist, the AF EPG, logos and - through IPTV Simple's
# defaultUserAgent - the streams themselves. Same value every run, so the
# server always sees one consistent client.
# Keep it in the "reduced" Chrome format and bump the major version now and
# then (Chrome stable was 157 in November 2026).
CHROME_MAJOR = 157

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    f"(KHTML, like Gecko) Chrome/{CHROME_MAJOR}.0.0.0 Safari/537.36"
)

# Headers a browser sends with a plain request (requests' defaults otherwise)
HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "*/*",
    "Accept-Language": "he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7",
}
