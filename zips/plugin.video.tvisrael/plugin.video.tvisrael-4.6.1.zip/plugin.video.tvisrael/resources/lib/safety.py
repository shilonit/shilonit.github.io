# Input validation and safe downloads.
# Everything that arrives from the network (GitHub channel list, af-play playlist,
# EPG files, logos) passes through here before it touches the disk, the add-on
# settings file or the M3U list.
import re
import unicodedata
from urllib.parse import quote, urlparse

import requests
from import_xbmc import xbmc

# Size limits (bytes). Generous for real data, small enough to stop a flood.
MAX_JSON_BYTES = 2 * 1024 * 1024  # channel_list.json
MAX_PLAYLIST_BYTES = 5 * 1024 * 1024  # af-play playlist
MAX_LOGO_BYTES = 2 * 1024 * 1024  # one logo
MAX_EPG_DOWNLOAD_BYTES = 200 * 1024 * 1024  # an EPG as downloaded (the AF one covers all its channels)
MAX_EPG_XML_BYTES = 1536 * 1024 * 1024  # an EPG after decompression
MAX_XML_ELEMENT_BYTES = 2 * 1024 * 1024  # one <channel>/<programme>
MAX_VERSION_XML_BYTES = 2 * 1024 * 1024  # repository addons.xml
MAX_LABEL_LEN = 80

# Channel ids (tvgid / nid): used as setting ids, file names and inside the M3U
SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
# The stream token is part of a URL path
SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9_~-][A-Za-z0-9._~-]{0,127}$")
SOURCE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
LOGO_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
IMAGE_MAGIC = (
    b"\x89PNG\r\n\x1a\n",
    b"\xff\xd8\xff",  # JPEG
    b"GIF87a",
    b"GIF89a",
    b"BM",
)


class DownloadTooLarge(requests.RequestException):
    """The server sent more data than the limit for this kind of file."""


def is_safe_id(value):
    return isinstance(value, str) and bool(SAFE_ID_RE.match(value))


def is_safe_token(value):
    return isinstance(value, str) and bool(SAFE_TOKEN_RE.match(value))


# Channel name safe for a settings label and for the M3U line: no control
# characters (a new line would add lines of our own to the M3U), limited length.
def clean_label(value):
    if not isinstance(value, str):
        return ""
    text = "".join(
        " " if unicodedata.category(c)[0] == "C" and c not in "‎‏" else c
        for c in value
    )
    text = " ".join(text.split())
    return text[:MAX_LABEL_LEN]


# Shows only the start of a secret in the log (Kodi logs are often shared)
def mask(secret):
    if not secret:
        return "<empty>"
    secret = str(secret)
    return f"{secret[:3]}…({len(secret)} chars)" if len(secret) > 6 else "***"


# Hides af-play keys / stream tokens inside a URL before it is logged
def mask_url(url):
    return re.sub(
        r"(/(?:playlist|s)/)([^/?#\s]+)",
        lambda m: m.group(1) + mask(m.group(2).replace(".m3u8", "")),
        str(url),
    )


# Access key as a single URL path segment (no "/", "?", "#", "..")
def quote_key(key):
    return quote(key.strip(), safe="")


def is_http_url(url):
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


# GET with a size limit. Returns the body (bytes), or writes it to dest when given.
# Raises requests.RequestException (DownloadTooLarge included) or OSError.
def capped_get(url, max_bytes, timeout=15, headers=None, dest=None):
    with requests.get(url, headers=headers, timeout=timeout, stream=True) as r:
        r.raise_for_status()
        length = r.headers.get("Content-Length")
        if length and length.isdigit() and int(length) > max_bytes:
            raise DownloadTooLarge(f"{int(length)} bytes > limit {max_bytes}")
        total = 0
        chunks = []
        out = open(dest, "wb") if dest else None
        try:
            for chunk in r.iter_content(chunk_size=64 * 1024):
                total += len(chunk)
                if total > max_bytes:
                    raise DownloadTooLarge(f"more than {max_bytes} bytes")
                if out:
                    out.write(chunk)
                else:
                    chunks.append(chunk)
        finally:
            if out:
                out.close()
        return None if dest else b"".join(chunks)


def capped_get_text(url, max_bytes, timeout=15, headers=None):
    return capped_get(url, max_bytes, timeout, headers).decode("utf-8", "replace")


# af-play playlist: HTTPS first, so the access key isn't sent in clear
# text. Falls back to HTTP only if HTTPS can't connect at all, and remembers it
# for this run so later calls don't wait for HTTPS again.
https_state = {"af-play.com": None}  # None = unknown, True/False = works or not


def af_play_get(path, max_bytes, timeout=15, headers=None):
    host = "af-play.com"
    if https_state[host] is not False:
        try:
            result = capped_get(f"https://{host}{path}", max_bytes, timeout, headers)
            https_state[host] = True
            return result
        except (requests.exceptions.SSLError, requests.exceptions.ConnectionError) as e:
            if https_state[host]:
                raise  # HTTPS worked before - don't downgrade
            https_state[host] = False
            xbmc.log(
                f"[safety] {host} has no working HTTPS ({type(e).__name__}) - using HTTP",
                xbmc.LOGWARNING,
            )
    return capped_get(f"http://{host}{path}", max_bytes, timeout, headers)


def looks_like_image(head):
    if head.startswith(IMAGE_MAGIC):
        return True
    return head[:4] == b"RIFF" and head[8:12] == b"WEBP"


# Validates the channel list from GitHub: [ {"version": ...}, channel, ... ].
# Returns (version, channels) with only well-formed channels, or raises ValueError.
def validate_channel_list(data):
    if not isinstance(data, list) or not data or not isinstance(data[0], dict):
        raise ValueError("channel list must be a list starting with a version object")
    version = str(data[0].get("version", "0"))
    if not re.match(r"^[\w.-]{1,32}$", version):
        raise ValueError(f"bad channel list version {version!r}")
    channels, seen = [], set()
    for ch in data[1:]:
        if not isinstance(ch, dict):
            continue
        tvgid, nid = ch.get("tvgid"), ch.get("nid")
        if not is_safe_id(tvgid) or tvgid in seen:
            xbmc.log(f"[safety] Skipping channel with bad tvgid {tvgid!r}", xbmc.LOGWARNING)
            continue
        if nid is not None and not is_safe_id(str(nid)):
            xbmc.log(f"[safety] Skipping channel {tvgid}: bad nid {nid!r}", xbmc.LOGWARNING)
            continue
        clean = {"tvgid": tvgid}
        if nid is not None:
            clean["nid"] = str(nid)
        # ids of the channel at yes / HOT, for the direct guide (epg_sources)
        for key in ("yes_id", "hot_id"):
            sid = ch.get(key)
            if sid is not None and SOURCE_ID_RE.match(str(sid)):
                clean[key] = str(sid)
        for key, val in ch.items():
            if isinstance(key, str) and key.startswith("name") and re.match(r"^name(_[a-z]{2})?$", key):
                label = clean_label(val)
                if label:
                    clean[key] = label
        seen.add(tvgid)
        channels.append(clean)
    return version, channels
