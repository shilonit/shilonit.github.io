import filecmp
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET
from urllib.parse import unquote, urlparse
from xml.sax.saxutils import quoteattr

import epglist as epg
import requests
import safety
import user_agent as ua
from constants import (
    Addon,
    Addon_ID,
    Addon_Ver,
    Channels_list,
    app_logo,
    channels_path,
    epg_file,
    github_base,
    github_chlist,
    logos_dir,
    main_settings,
    profile_dir,
    user_settings,
)
from import_xbmc import xbmc, xbmcgui


channels_cache = None
monitor = xbmc.Monitor()


# True when Kodi asks this script to stop (Kodi exit, add-on update or disable)
def abort_requested():
    return monitor.abortRequested()


# Unique suffix for temp files, so two running copies never write the same file
def temp_suffix():
    return f".{uuid.uuid4().hex[:8]}.tmp"


# Writes a text file through a temp file, so a crash never leaves half a file
def write_atomic(path, text):
    tmp_path = path + temp_suffix()
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def load_channels():
    global channels_cache
    if channels_cache is not None:
        return channels_cache
    try:
        with open(channels_path, "r", encoding="utf-8") as f:
            version, channels = safety.validate_channel_list(json.load(f))
        channels_cache = [{"version": version}] + channels
        return channels_cache
    except FileNotFoundError:
        channels_cache = []
        return channels_cache
    except (OSError, ValueError, TypeError, UnicodeError) as e:
        xbmc.log(f"[main] Failed loading channel_list.json: {e}", xbmc.LOGERROR)
        channels_cache = []
        return channels_cache


channels_loaded = load_channels()


# Reloads the channel list after channel_list.json was rewritten
def reload_channels():
    global channels_cache, channels_loaded
    channels_cache = None
    channels_loaded = load_channels()


# Check if an addon is installed
def is_addon_installed(addonid):
    return xbmc.getCondVisibility(f"System.HasAddon({addonid})")


# Install addon
def install_addon(addonid):
    xbmc.executebuiltin(f"InstallAddon({addonid})")


# Get localized string
def get_locale_string(id):
    return Addon.getLocalizedString(id)


# Read and return settings from addon
def get_addon_setting(key):
    return Addon.getSetting(key)


# Check if file is older than a given threshold
def is_file_old(filename, deltaInSec=10800):
    last_update = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - last_update) > deltaInSec


def clean_user_settings():
    active_keys = set()
    try:
        tree = ET.parse(main_settings)
        root = tree.getroot()
        for category in root.findall("category"):
            for setting in category.findall("setting"):
                sid = setting.get("id")
                if sid:
                    active_keys.add(sid)
    except (FileNotFoundError, OSError, ET.ParseError) as e:
        xbmc.log(f"Error reading resource settings file: {e}", xbmc.LOGERROR)
        return
    try:
        with open(user_settings, "r", encoding="utf-8") as f:
            content = f.read()
        pattern = r'<setting id="([^"]+)"[^>]*?(?:>(.*?)</setting>|/>)'
        content = re.sub(
            pattern, lambda m: m.group(0) if m.group(1) in active_keys else "", content
        )
        # Remove empty lines
        cleaned_lines = [line for line in content.splitlines() if line.strip()]
        final_content = "\n".join(cleaned_lines) + "\n"
        write_atomic(user_settings, final_content)
        xbmc.log("Unused settings cleaned successfully", xbmc.LOGINFO)
    except (OSError, UnicodeError, ValueError) as e:
        xbmc.log(f"Error cleaning user settings: {e}", xbmc.LOGERROR)


# Check if the links file is old and needs to be updated
# max_age: seconds; default = the refresh interval from the settings
def update_epg_files(max_age=None):
    epg_delta_sec = max_age or Addon.getSettingInt("update_EPG_interval") * 3600
    if is_file_old(epg_file, epg_delta_sec):
        xbmc.log("[update_epg_files] Updating EPG file", xbmc.LOGDEBUG)
        try:
            epg.fetch_and_build_epg()
        except (AttributeError, OSError, ValueError, TypeError) as e:
            xbmc.log(f"Failed to update EPG file: {e}", xbmc.LOGERROR)


# Get channel name based on current language
def get_local_lang_name(item):
    lang = xbmc.getLanguage(xbmc.ISO_639_1)
    key = f"name_{lang}"
    if key in item:
        return item[key]
    # Fallback to English
    return item.get("name_en", "")


# Get visible channels - exclude channels set to false
def get_visible_channels():
    visible = []
    for channel in channels_loaded:
        tvgid = channel.get("tvgid")
        if tvgid and get_addon_setting(tvgid) != "false":
            visible.append(channel)
    return visible


# Create IPTV files and launch the addon
def make_iptv_files(show_progress=False, restart=True):
    token = get_addon_setting("user_token")
    if not token:
        xbmc.log("[IPTV] No user token – skipping IPTV build", xbmc.LOGWARNING)
        return False
    return epg.generate_iptv_list(
        get_visible_channels(), show_progress=show_progress, restart=restart
    )


# Playlist path of the access key, or None (and a notification) if there's no key
def get_playlist_path():
    access_key = Addon.getSetting("access_key").strip()
    if not access_key:
        notify(30700, 30714)
        return None
    return f"/playlist/{safety.quote_key(access_key)}.m3u8"


# Downloads the af-play playlist of the access key (HTTPS first, size-limited).
# Returns the text, None if there's no key. Raises requests.RequestException.
def fetch_playlist(timeout=15):
    path = get_playlist_path()
    if not path:
        return None
    xbmc.log(f"[Playlist] Fetching {safety.mask_url(path)}", xbmc.LOGDEBUG)
    body = safety.af_play_get(
        path,
        safety.MAX_PLAYLIST_BYTES,
        timeout=timeout,
        headers=ua.HEADERS,
    )
    return body.decode("utf-8", "replace")


EXTINF_ATTR_RE = re.compile(r'([\w-]+)="([^"]*)"')


# Token in a stream URL: http://<server>:8080/s/{user_token}/{nid}/video.m3u8
TOKEN_RE = re.compile(r"/s/([^/\s]+)/[^/\s]+/video\.m3u8")


# Fetch user token from the playlist using the access key.
# silent=True (service): no notifications, only the log.
def fetch_token_from_access_key(silent=False):
    def tell(title_id, message_id):
        if not silent:
            notify(title_id, message_id)

    try:
        text = fetch_playlist(timeout=10)
    except requests.HTTPError as e:
        status = e.response.status_code if e.response is not None else 0
        if status in (401, 403, 404):
            xbmc.log(f"[TOKEN] Access key rejected (HTTP {status})", xbmc.LOGERROR)
            tell(30700, 30716)
        else:
            xbmc.log(f"[TOKEN] Server error (HTTP {status})", xbmc.LOGERROR)
            tell(30700, 30718)
        return False
    except requests.RequestException as e:
        xbmc.log(
            f"[TOKEN] Failed fetching playlist: {safety.mask_url(e)}", xbmc.LOGERROR
        )
        tell(30700, 30718)
        return False
    if text is None:
        return False  # no access key - fetch_playlist already told the user

    match = TOKEN_RE.search(text)
    user_token = match.group(1) if match else ""
    if not safety.is_safe_token(user_token):
        xbmc.log("[TOKEN] Valid token not found in playlist", xbmc.LOGERROR)
        tell(30700, 30716)
        return False

    if get_addon_setting("user_token") != user_token:
        Addon.setSetting("user_token", user_token)
        xbmc.log(f"[TOKEN] New token stored: {safety.mask(user_token)}", xbmc.LOGINFO)
    else:
        xbmc.log("[TOKEN] Token unchanged", xbmc.LOGDEBUG)
    # Remember which key produced the token (the service sets up a new key by itself)
    Addon.setSetting("token_key", key_fingerprint())
    tell(30702, 30717)
    return True


# Short fingerprint of the access key - tells if the token belongs to the current key
def key_fingerprint():
    key = Addon.getSetting("access_key").strip()
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16] if key else ""


# True when there is an access key whose token was not fetched yet
def needs_setup():
    fp = key_fingerprint()
    return bool(fp) and (
        fp != get_addon_setting("token_key") or not get_addon_setting("user_token")
    )


# Download channel logos based on the playlist
def download_channel_logos(silent=False, max_age=None):
    if max_age and os.path.isdir(logos_dir):
        age = time.time() - os.path.getmtime(logos_dir)
        if age < max_age:
            xbmc.log(
                f"[Logos] Refreshed {age / 3600:.1f}h ago - skipping download",
                xbmc.LOGDEBUG,
            )
            return False
    if silent and not Addon.getSetting("access_key").strip():
        return False
    if not silent:
        notify(30702, 30611)
    headers = ua.HEADERS
    try:
        text = fetch_playlist()
    except requests.RequestException as e:
        xbmc.log(
            f"[Logos] Failed to fetch playlist: {safety.mask_url(e)}", xbmc.LOGERROR
        )
        return False
    if text is None:
        xbmc.log("[Logos] No access_key – cannot download logos", xbmc.LOGWARNING)
        return False

    # Download into a temp folder of our own
    remove_stale_logo_dirs()
    tmp_dir = tempfile.mkdtemp(prefix="logos_tmp_", dir=profile_dir)

    playlist_to_internal_tvgid = {}
    for ch in channels_loaded:
        nid = ch.get("nid")
        internal_tvgid = ch.get("tvgid")
        if nid and internal_tvgid:
            playlist_to_internal_tvgid[nid] = internal_tvgid

    downloaded = 0
    failed = 0

    for line in text.splitlines():
        if abort_requested():
            shutil.rmtree(tmp_dir, ignore_errors=True)
            xbmc.log("[Logos] Stopped - Kodi asked the add-on to stop", xbmc.LOGINFO)
            return False
        line = line.strip()
        if line.startswith("#EXTINF") and 'tvg-logo="' in line:
            attrs = dict(EXTINF_ATTR_RE.findall(line))
            logo_url = attrs.get("tvg-logo", "").strip()
            playlist_tvgid = attrs.get("tvg-id", "").strip()

            if not playlist_tvgid or not safety.is_http_url(logo_url):
                continue

            internal_tvgid = playlist_to_internal_tvgid.get(playlist_tvgid)
            if not internal_tvgid:
                xbmc.log(
                    f"[Logos] No internal tvgid found for playlist tvg-id: {playlist_tvgid}",
                    xbmc.LOGWARNING,
                )
                continue

            ext = os.path.splitext(urlparse(logo_url).path)[1].lower()
            if ext not in safety.LOGO_EXTENSIONS:
                ext = ".png"

            # internal_tvgid passed safety.is_safe_id - no path separators
            filename = f"{internal_tvgid}{ext}"
            local_path = os.path.join(tmp_dir, filename)
            try:
                data = safety.capped_get(
                    logo_url, safety.MAX_LOGO_BYTES, timeout=(3, 7), headers=headers
                )
                if not safety.looks_like_image(data[:16]):
                    raise ValueError("not an image")
                with open(local_path, "wb") as f:
                    f.write(data)
                xbmc.log(
                    f"[Logos] Saved as internal tvgid: {filename} (from {playlist_tvgid})",
                    xbmc.LOGDEBUG,
                )
                downloaded += 1
            except (requests.RequestException, OSError, ValueError) as e:
                xbmc.log(
                    f"[Logos] Failed {internal_tvgid} ({playlist_tvgid}): {e}",
                    xbmc.LOGWARNING,
                )
                failed += 1
    xbmc.log(f"[Logos] Finished: {downloaded} saved, {failed} failed", xbmc.LOGINFO)

    if downloaded == 0:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        xbmc.log(
            "[Logos] Nothing downloaded - keeping the existing logos", xbmc.LOGWARNING
        )
        return False

    try:
        # Logos whose content changed
        changed = set()
        for name in os.listdir(tmp_dir):
            old_path = os.path.join(logos_dir, name)
            if not os.path.isfile(old_path) or not filecmp.cmp(
                old_path, os.path.join(tmp_dir, name), shallow=False
            ):
                changed.add(name)

        # Keep old logos that failed
        if os.path.isdir(logos_dir):
            for name in os.listdir(logos_dir):
                if not os.path.exists(os.path.join(tmp_dir, name)):
                    shutil.copy2(os.path.join(logos_dir, name), tmp_dir)
        old_dir = tmp_dir + "_old"
        if os.path.isdir(logos_dir):
            os.rename(logos_dir, old_dir)
        os.rename(tmp_dir, logos_dir)
        os.utime(logos_dir)
        shutil.rmtree(old_dir, ignore_errors=True)
    except OSError as e:
        xbmc.log(f"[Logos] Failed replacing the logos folder: {e}", xbmc.LOGERROR)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        if not os.path.isdir(logos_dir) and os.path.isdir(tmp_dir + "_old"):
            os.rename(tmp_dir + "_old", logos_dir)
        return False

    if changed:
        clear_logo_textures(changed)

    if not silent:
        notify(30702, 30612)
    return True


# Removes temp logo folders left by a copy that was killed mid-download
def remove_stale_logo_dirs(max_age=600):
    try:
        names = os.listdir(profile_dir)
    except OSError:
        return
    for name in names:
        path = os.path.join(profile_dir, name)
        if name.startswith("logos_tmp") and os.path.isdir(path):
            try:
                if time.time() - os.path.getmtime(path) > max_age:
                    shutil.rmtree(path, ignore_errors=True)
            except OSError:
                pass


# Removes cached textures
def clear_logo_textures(file_names):
    names = {n.lower() for n in file_names}
    result = epg.json_rpc(
        "Textures.GetTextures",
        {
            "properties": ["url"],
            # Matches plain, Windows and URL-encoded (image://) paths alike
            "filter": {"field": "url", "operator": "contains", "value": Addon_ID},
        },
    )
    if result is None:
        xbmc.log("[Logos] Failed reading texture cache", xbmc.LOGERROR)
        return
    removed = 0
    for texture in result.get("textures", []):
        url = unquote(texture.get("url", "")).replace("\\", "/").lower()
        if "/logos/" not in url or url.rstrip("/").rsplit("/", 1)[-1] not in names:
            continue
        epg.json_rpc("Textures.RemoveTexture", {"textureid": texture["textureid"]})
        removed += 1
    xbmc.log(
        f"[Logos] {len(names)} logos changed, {removed} cached textures cleared",
        xbmc.LOGINFO,
    )


# Updates the EPG if it is old and rebuilds the M3U.
def update_epg(restart=True):
    update_epg_files()
    if make_iptv_files(restart=restart) and not restart:
        epg.set_pending_restart()


# Download channel logos and save with internal tvgid as filename
def update_channels(restart=True):
    # A logo failure must not stop the channel update
    try:
        download_channel_logos()
    except (OSError, ValueError, requests.RequestException) as e:
        xbmc.log(f"[Logos] Download failed: {e}", xbmc.LOGERROR)
    if abort_requested():
        return
    settings_changed = epg.set_iptv_client_settings(restart=False)
    clean_user_settings()
    update_epg_files()
    if abort_requested():
        return
    m3u_changed = make_iptv_files(restart=False)
    if settings_changed or m3u_changed:
        if restart:
            epg.restart_pvr_client()
        else:
            xbmc.log(
                "[update_channels] Changes saved - restart pending until the PVR has started",
                xbmc.LOGINFO,
            )
            epg.set_pending_restart(force=settings_changed)


# Check if the channel list has changed and update the settings accordingly
def channel_list_features(restart=True):
    local_path = os.path.join(profile_dir, Channels_list)
    try:
        raw = safety.capped_get(github_chlist, safety.MAX_JSON_BYTES, timeout=10)
        remote_version, channels = safety.validate_channel_list(json.loads(raw))
        if not channels:
            raise ValueError("remote channel list has no valid channels")
        remote_data = [{"version": remote_version}] + channels
        local_version = "0"
        # If local file exists, read its version
        if os.path.isfile(local_path):
            try:
                with open(local_path, "r", encoding="utf-8") as f:
                    local_data = json.load(f)
                    local_version = (
                        str(local_data[0].get("version", "0"))
                        if isinstance(local_data, list)
                        and local_data
                        and isinstance(local_data[0], dict)
                        else "0"
                    )
            except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
                xbmc.log(
                    f"[Settings] Failed reading local channel_list.json: {exc}",
                    xbmc.LOGWARNING,
                )

        # Check if category is empty (no channels) - run after add-on update.
        def is_category_empty():
            try:
                with open(main_settings, "r", encoding="utf-8") as f:
                    content = f.read()
                start = content.find('<category label="30504">')
                end = content.find("</category>", start)
                if start == -1 or end == -1:
                    return True
                inner = content[start:end]
                return 'id="' not in inner
            except (OSError, ValueError, TypeError) as exc:
                xbmc.log(
                    f"[Settings] Failed checking channel category state: {exc}",
                    xbmc.LOGWARNING,
                )
                return True

        # If versions match but category is empty, regenerate channels.
        if remote_version == local_version and local_version != "0":
            if not is_category_empty():
                xbmc.log(
                    f"[Settings] channel_list version {remote_version} - no change",
                    xbmc.LOGINFO,
                )
                update_epg(restart=restart)
                return False
            else:
                xbmc.log(
                    "[Settings] category empty - regenerating despite same version",
                    xbmc.LOGINFO,
                )
        if abort_requested():
            return False
        # If remote version is newer or category is empty, update local file and settings
        write_atomic(local_path, json.dumps(remote_data, ensure_ascii=False, indent=2))
        reload_channels()
        new_category = (
            '<category label="30504">\n		<setting type="lsep" label="30505" />\n'
        )
        for ch in channels:
            tvgid = ch["tvgid"]  # validated: letters, digits, . _ -
            name = get_local_lang_name(ch)
            if name:
                # quoteattr escapes & < > " - the remote list can't add settings
                # (e.g. an "action" setting that runs a command) to settings.xml
                new_category += (
                    f"		<setting id={quoteattr(tvgid)} type=\"bool\" "
                    f"label={quoteattr(name)} default=\"true\" />\n"
                )
        new_category += "	</category>"
        with open(main_settings, "r", encoding="utf-8") as f:
            content = f.read()
        start = content.find('<category label="30504">')
        end = content.find("</category>", start) if start != -1 else -1
        if end == -1:
            xbmc.log("[Settings] Could not find category 30504", xbmc.LOGERROR)
            return False
        end += len("</category>")
        new_content = content[:start] + new_category + content[end:]
        ET.fromstring(new_content)  # never write a settings file Kodi can't read
        write_atomic(main_settings, new_content)
        xbmc.log(
            f"[Settings] Generated {len(channels)} dynamic channels (version {remote_version})",
            xbmc.LOGINFO,
        )
        update_channels(restart=restart)
        return True
    except (
        OSError,
        ValueError,
        TypeError,
        KeyError,
        IndexError,
        AttributeError,
        ET.ParseError,
        requests.RequestException,
    ) as e:
        xbmc.log(f"[Settings] Failed to generate channel settings: {e}", xbmc.LOGERROR)
        return None


# (no "str | None" annotations - they break Kodi builds with Python < 3.10)
def notify(title_id, message_id, duration=2500, icon=None):
    # No notifications while anything is playing
    if xbmc.Player().isPlaying():
        xbmc.log(
            f"[notify] Playback active - message {message_id} not shown", xbmc.LOGDEBUG
        )
        return
    title = get_locale_string(title_id)
    message = get_locale_string(message_id)
    xbmcgui.Dialog().notification(
        title, message, icon or app_logo, duration, sound=False
    )


# Compare two version strings
def compare_versions(v1, v2):
    try:
        parts1 = [int(p) for p in v1.strip(".").split(".")]
        parts2 = [int(p) for p in v2.strip(".").split(".")]
    except ValueError:
        xbmc.log(f"[check_version] Bad version: {v1!r} / {v2!r}", xbmc.LOGWARNING)
        return False
    return parts1 > parts2


# Check for updates and notify if available
def check_version(startup=False):
    url = f"{github_base}/shilonit.github.io/master/addons.xml"
    try:
        text = safety.capped_get_text(url, safety.MAX_VERSION_XML_BYTES, timeout=10)
    except requests.RequestException as e:
        xbmc.log(
            f"[check_version] Error fetching addons.xml: {e} (URL: {url})",
            xbmc.LOGERROR,
        )
        return

    pattern = rf'<addon id="{re.escape(Addon_ID)}"[^>]*?version="([\d\.]+)"'
    match = re.search(pattern, text)
    if not match:
        xbmc.log("[check_version] Failed to find version in addons.xml", xbmc.LOGERROR)
        return

    remote_version = match.group(1)
    if compare_versions(remote_version, Addon_Ver):
        notify(30703, 30712)
        xbmc.executebuiltin("UpdateAddonRepos()")
        return

    xbmc.log(f"[check_version] No update available. startup={startup}", xbmc.LOGDEBUG)

    # If the version is up-to-date and NOT in startup mode, notify the user
    if not startup:
        notify(30702, 30713)
