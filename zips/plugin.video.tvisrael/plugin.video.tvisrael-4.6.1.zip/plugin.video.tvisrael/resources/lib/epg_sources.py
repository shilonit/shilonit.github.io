# TV guide straight from yes and HOT, combined into one XMLTV file.
#
# Shared by the Kodi add-on (each user's Kodi builds its own guide) and the
# server bot (epg-bot/app/grab_epg.py), so this file must not import any Kodi
# module - only requests (curl_cffi when installed) and the standard library
# (Python 3.8+).
#
# Channel mapping comes from channel_list.json: every channel may carry
#   "yes_id": "PT53"   - yes channel id   (svc.yes.co.il)
#   "hot_id": "160"    - HOT channel id   (www.hot.net.il)
# A channel with both gets yes first; HOT fills what yes doesn't have, and a
# real programme always beats a placeholder ("ללא כותרת", "השידורים יתחדשו...")
# from the other source.
#
# Downloads are incremental: what was fetched is kept in a cache (per source),
# and only days that are missing or incomplete are asked again - from 7 days
# back to 7 days ahead. Anything older than 7 days is deleted.
import bisect
import gzip
import json
import os
import re
import unicodedata
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone

import requests

try:  # browser TLS fingerprint (server image); Kodi has no curl_cffi
    from curl_cffi import requests as cffi_requests
except ImportError:  # pragma: no cover - depends on the install
    cffi_requests = None

CHROME_MAJOR = 157
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    f"(KHTML, like Gecko) Chrome/{CHROME_MAJOR}.0.0.0 Safari/537.36"
)
ACCEPT_LANGUAGE = "he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7"

YES_SCHEDULE_URL = (
    "https://svc.yes.co.il/api/content/broadcast-schedule/channels/{channel_id}?date={date}"
)
YES_CHANNELS_URL = (
    "https://svc.yes.co.il/api/content/broadcast-schedule/channels?page=0&pageSize={size}"
)
HOT_SCHEDULE_URL = (
    "https://www.hot.net.il/HotCmsApiFront/api/ProgramsSchedual/GetProgramsSchedual"
)
HOT_CHANNELS_URL = (
    "https://www.hot.net.il/HotCmsApiFront/api/ProgramsSchedual/GetChannelsSchedual"
)
HOT_TIME_FORMAT = "%Y/%m/%d %H:%M:%S"
YES_HEADERS = {"Referer": "https://www.yes.co.il/", "Origin": "https://www.yes.co.il"}
HOT_HEADERS = {"Referer": "https://www.hot.net.il/", "Origin": "https://www.hot.net.il"}

SOURCES = ("yes", "hot")  # priority order
SOURCE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
TVGID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")

PAST_DAYS = 7  # kept and filled back
FUTURE_DAYS = 7  # today + 6
HOT_MAX_DAYS_PER_REQUEST = 7
COMPLETE_RATIO = 0.95  # a day with less coverage than this is asked again
MAX_RESPONSE_BYTES = 64 * 1024 * 1024  # one API answer (HOT returns all channels)
MAX_CACHE_BYTES = 64 * 1024 * 1024
MAX_TITLE_LEN = 200
MAX_DESC_LEN = 4000
MAX_PROGRAMME_SECONDS = 24 * 3600
CREDIT = " (C) שילונית"
NO_TITLE = "ללא כותרת"
# Titles that only fill air time - any real programme from another source wins
PLACEHOLDER_TITLES = {"", NO_TITLE, "השידורים יתחדשו בקרוב"}
# A day with one of these isn't final yet - it is asked again
INCOMPLETE_TITLES = {"", NO_TITLE}


class GrabFailed(Exception):
    """No source answered and there is nothing cached - keep the old guide."""


def default_log(msg, level="info"):
    print(f"[{level}] {msg}", flush=True)


# ---------------------------------------------------------------- Israel time
# zoneinfo needs a time zone database, which some Kodi builds (Windows,
# Android) don't have - then Israel's DST rule is used directly.
try:
    from zoneinfo import ZoneInfo

    IL_TZ = ZoneInfo("Asia/Jerusalem")
except Exception:  # noqa: BLE001 - ImportError or ZoneInfoNotFoundError
    IL_TZ = None


def last_sunday(year, month):
    d = date(year, month + 1, 1) - timedelta(days=1)
    return d - timedelta(days=(d.weekday() + 1) % 7)


# Israel (since 2013): DST from the Friday before the last Sunday of March,
# 02:00 local, until the last Sunday of October, 02:00 local.
def il_offset_manual(ts):
    year = datetime.fromtimestamp(ts, timezone.utc).year
    start_day = last_sunday(year, 3) - timedelta(days=2)
    start = datetime(start_day.year, start_day.month, start_day.day, tzinfo=timezone.utc)
    end_day = last_sunday(year, 10)
    end = datetime(end_day.year, end_day.month, end_day.day, tzinfo=timezone.utc) - timedelta(hours=1)
    return 3 * 3600 if start.timestamp() <= ts < end.timestamp() else 2 * 3600


def il_offset(ts):
    if IL_TZ is not None:
        return int(datetime.fromtimestamp(ts, IL_TZ).utcoffset().total_seconds())
    return il_offset_manual(ts)


# Naive Israel local time -> Unix timestamp
def il_local_to_unix(dt):
    if IL_TZ is not None:
        return dt.replace(tzinfo=IL_TZ).timestamp()
    guess = dt.replace(tzinfo=timezone.utc).timestamp() - 2 * 3600
    return dt.replace(tzinfo=timezone.utc).timestamp() - il_offset(guess)


def il_today(now_ts):
    return datetime.fromtimestamp(now_ts + il_offset(now_ts), timezone.utc).date()


# [start, end) of an Israel calendar day as Unix timestamps
def day_window(d):
    start = il_local_to_unix(datetime(d.year, d.month, d.day))
    nxt = d + timedelta(days=1)
    return start, il_local_to_unix(datetime(nxt.year, nxt.month, nxt.day))


def xmltv_time(ts):
    offset = il_offset(ts)
    local = datetime.fromtimestamp(ts + offset, timezone.utc)
    sign = "+" if offset >= 0 else "-"
    hours, minutes = divmod(abs(offset) // 60, 60)
    return local.strftime("%Y%m%d%H%M%S") + f" {sign}{hours:02d}{minutes:02d}"


def parse_iso(value):
    value = str(value).strip().replace("Z", "+00:00")
    # Python < 3.11 accepts only 3 or 6 fraction digits
    value = re.sub(r"\.(\d+)", lambda m: "." + (m.group(1) + "000000")[:6], value)
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        return il_local_to_unix(dt)
    return dt.timestamp()


# ---------------------------------------------------------------- text
def clean_text(value, max_len, keep_newlines=False):
    if not isinstance(value, str):
        return ""
    out = []
    for c in value:
        if c == "\n" and keep_newlines:
            out.append(c)
        elif unicodedata.category(c)[0] == "C" and c not in "‎‏":
            out.append(" ")
        else:
            out.append(c)
    text = "".join(out)
    if keep_newlines:
        text = "\n".join(" ".join(line.split()) for line in text.split("\n")).strip()
    else:
        text = " ".join(text.split())
    return text[:max_len]


def programme(start, stop, title, desc):
    return {
        "start": int(start),
        "stop": int(stop),
        "title": clean_text(title, MAX_TITLE_LEN),
        "desc": clean_text(desc, MAX_DESC_LEN, keep_newlines=True),
    }


def valid_programme(p):
    return (
        isinstance(p, dict)
        and isinstance(p.get("start"), int)
        and isinstance(p.get("stop"), int)
        and isinstance(p.get("title"), str)
        and isinstance(p.get("desc"), str)
    )


def is_placeholder(prog):
    return prog["title"] in PLACEHOLDER_TITLES


# ---------------------------------------------------------------- HTTP
# One session for a whole run. With curl_cffi (installed in the server image)
# the TLS/HTTP2 fingerprint is a real Chrome's, matching the User-Agent the
# impersonation sends. proxy: optional "http://host:port" for yes/HOT only.
REQUEST_ERRORS = (requests.RequestException,)
if cffi_requests is not None:
    REQUEST_ERRORS += (cffi_requests.exceptions.RequestException,)


def new_session(proxy=None, impersonate=True):
    proxies = {"http": proxy, "https": proxy} if proxy else None
    if impersonate and cffi_requests is not None:
        session = cffi_requests.Session(impersonate="chrome", proxies=proxies)
        session.headers.update({"Accept-Language": ACCEPT_LANGUAGE})
        session.epg_backend = "curl_cffi"
        return session
    session = requests.Session()
    if proxies:
        session.proxies.update(proxies)
    session.headers.update(
        {
            "User-Agent": USER_AGENT,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": ACCEPT_LANGUAGE,
        }
    )
    session.epg_backend = "requests"
    return session


def request_json(session, method, url, timeout=60, **kwargs):
    if getattr(session, "epg_backend", "") == "curl_cffi":
        r = session.request(method, url, timeout=timeout, **kwargs)
        r.raise_for_status()
        body = r.content
        if len(body) > MAX_RESPONSE_BYTES:
            raise ValueError(f"answer from {url} is larger than {MAX_RESPONSE_BYTES} bytes")
        return json.loads(body.decode("utf-8"))
    with session.request(method, url, timeout=(10, timeout), stream=True, **kwargs) as r:
        r.raise_for_status()
        chunks, total = [], 0
        for chunk in r.iter_content(64 * 1024):
            total += len(chunk)
            if total > MAX_RESPONSE_BYTES:
                raise ValueError(f"answer from {url} is larger than {MAX_RESPONSE_BYTES} bytes")
            chunks.append(chunk)
    return json.loads(b"".join(chunks).decode("utf-8"))


# ---------------------------------------------------------------- yes
def fetch_yes_day(session, yes_id, day):
    url = YES_SCHEDULE_URL.format(channel_id=yes_id, date=day.isoformat())
    data = request_json(session, "GET", url, headers=YES_HEADERS)
    items = data.get("items") if isinstance(data, dict) else data
    progs = []
    for item in items if isinstance(items, list) else []:
        try:
            progs.append(
                programme(
                    parse_iso(item["starts"]),
                    parse_iso(item["ends"]),
                    item.get("title"),
                    item.get("description"),
                )
            )
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
    return progs


def list_yes_channels(session):
    """[(channel id, channel name)] of all yes channels."""
    size = 200
    while True:
        data = request_json(session, "GET", YES_CHANNELS_URL.format(size=size), headers=YES_HEADERS)
        items = data.get("items", []) if isinstance(data, dict) else []
        if len(items) < size or size >= 3200:
            break
        size *= 2  # the API pages - ask for everything in one page
    channels = {}
    for ch in items:
        if isinstance(ch, dict) and ch.get("channelId") and ch.get("channelName"):
            channels[str(ch["channelId"])] = clean_text(ch["channelName"], 100)
    return sorted(channels.items())


# ---------------------------------------------------------------- HOT
def hot_request(session, first_day, last_day):
    start = datetime(first_day.year, first_day.month, first_day.day)
    end = datetime(last_day.year, last_day.month, last_day.day) + timedelta(days=1, seconds=-1)
    payload = {
        "ProgramsStartDateTime": start.strftime(HOT_TIME_FORMAT),
        "ProgramsEndDateTime": end.strftime(HOT_TIME_FORMAT),
    }
    data = request_json(session, "POST", HOT_SCHEDULE_URL, json=payload, headers=HOT_HEADERS)
    details = (data.get("data") or {}).get("programsDetails") if isinstance(data, dict) else None
    return details if isinstance(details, list) else []


def fetch_hot_range(session, hot_ids, first_day, last_day):
    """{hot_id: [programme, ...]} for every wanted id (empty list = no data)."""
    result = {h: [] for h in hot_ids}
    # HOT writes some ids with leading zeros ("038") - compare without them
    by_number = {h.lstrip("0") or "0": h for h in hot_ids}
    for item in hot_request(session, first_day, last_day):
        if not isinstance(item, dict):
            continue
        cid = by_number.get(str(item.get("channelID", "")).strip().lstrip("0") or "0")
        if cid is None:
            continue
        try:
            start = il_local_to_unix(datetime.strptime(item["programStartTime"], HOT_TIME_FORMAT))
            stop = il_local_to_unix(datetime.strptime(item["programEndTime"], HOT_TIME_FORMAT))
        except (KeyError, TypeError, ValueError, OverflowError):
            continue
        result[cid].append(programme(start, stop, item.get("programTitle"), item.get("synopsis")))
    return result


def list_hot_channels(session, now_ts=None):
    """[(channel id, channel name)] of all HOT channels (ids without leading zeros)."""
    data = request_json(session, "POST", HOT_CHANNELS_URL, json={}, headers=HOT_HEADERS)
    details = (data.get("data") or {}).get("channelDetails") if isinstance(data, dict) else None
    channels = {}
    for ch in details if isinstance(details, list) else []:
        if isinstance(ch, dict) and ch.get("channelID") is not None:
            cid = str(ch["channelID"]).strip().lstrip("0") or "0"
            channels[cid] = clean_text(str(ch.get("channelTitleHe") or ""), 100)
    return sorted(channels.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0)


# ---------------------------------------------------------------- cleaning / combining
# One source, one channel: sorted, without broken or duplicate programmes;
# an overlap shortens the earlier programme (what Kodi does too).
def normalize(progs):
    progs = sorted(
        (p for p in progs if 0 < p["stop"] - p["start"] <= MAX_PROGRAMME_SECONDS),
        key=lambda p: (p["start"], -p["stop"]),
    )
    out = []
    for p in progs:
        if out and out[-1]["start"] == p["start"]:
            continue  # same programme returned for two dates
        if out and out[-1]["stop"] > p["start"]:
            out[-1] = dict(out[-1], stop=p["start"])
        out.append(dict(p))
    return [p for p in out if p["stop"] > p["start"]]


def overlaps_accepted(starts, accepted, prog):
    i = bisect.bisect_left(starts, prog["stop"])  # accepted[:i] start before our end
    return i > 0 and accepted[i - 1]["stop"] > prog["start"]


# layers: [ [programme, ...] from the best source, ..., from the worst ]
def combine(layers):
    accepted, starts = [], []
    ordered = [p for layer in layers for p in layer if not is_placeholder(p)]
    ordered += [p for layer in layers for p in layer if is_placeholder(p)]
    for p in ordered:
        if overlaps_accepted(starts, accepted, p):
            continue
        i = bisect.bisect_left(starts, p["start"])
        starts.insert(i, p["start"])
        accepted.insert(i, p)
    return accepted


# True when a channel's guide covers the Israel day well enough and has no
# "no title" holes - such a day isn't downloaded again
def day_complete(progs, d):
    start, end = day_window(d)
    covered = 0
    for p in progs:
        if p["stop"] <= start or p["start"] >= end:
            continue
        if p["title"] in INCOMPLETE_TITLES:
            return False
        covered += min(p["stop"], end) - max(p["start"], start)
    return covered >= (end - start) * COMPLETE_RATIO


# ---------------------------------------------------------------- mapping / cache
def valid_mapping(channels):
    """Channels of channel_list.json that have a yes_id and/or hot_id."""
    out = []
    for ch in channels:
        if not isinstance(ch, dict) or not TVGID_RE.match(str(ch.get("tvgid", ""))):
            continue
        entry = {"tvgid": ch["tvgid"]}
        for src in SOURCES:
            sid = ch.get(f"{src}_id")
            if sid is not None and SOURCE_ID_RE.match(str(sid)):
                entry[src] = str(sid)
        if len(entry) > 1:
            out.append(entry)
    return out


def empty_cache():
    return {"format": 1, "yes": {}, "hot": {}, "tried": {}}


# Cache file: {"format": 1, "yes": {id: [programme]}, "hot": {id: [programme]},
#              "tried": {"yes:<id>:<date>" | "hot:<date>": unix time}}
def load_cache(path):
    try:
        if os.path.getsize(path) > MAX_CACHE_BYTES:
            return empty_cache()
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return empty_cache()
    cache = empty_cache()
    if not isinstance(data, dict) or data.get("format") != 1:
        return cache
    for src in SOURCES:
        for sid, progs in (data.get(src) or {}).items():
            if SOURCE_ID_RE.match(str(sid)) and isinstance(progs, list):
                cache[src][str(sid)] = [p for p in progs if valid_programme(p)]
    tried = data.get("tried") or {}
    cache["tried"] = {k: v for k, v in tried.items() if isinstance(k, str) and isinstance(v, (int, float))}
    return cache


def save_cache(cache, path):
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def cached_channel(cache, entry):
    layers = [normalize(cache[src].get(entry[src], [])) for src in SOURCES if src in entry]
    return combine(layers)


def window_days(today):
    return [today + timedelta(days=i) for i in range(-PAST_DAYS, FUTURE_DAYS)]


# What to download: {"yes": {id: {dates}}, "hot": {dates}} - only days a channel
# is missing or has incomplete. A past day is asked only once (yes/HOT may
# not keep old days); today and later are asked until they are complete.
# force=True (manual refresh): every day of the window, again.
def plan_downloads(mapping, cache, today, sources=SOURCES, force=False):
    need = {"yes": {}, "hot": set()}
    for entry in mapping:
        progs = [] if force else cached_channel(cache, entry)
        for d in window_days(today):
            if not force and day_complete(progs, d):
                continue
            if force:
                if "yes" in entry and "yes" in sources:
                    need["yes"].setdefault(entry["yes"], set()).add(d)
                if "hot" in entry and "hot" in sources:
                    need["hot"].add(d)
                continue
            if "yes" in entry and "yes" in sources:
                if d >= today or f"yes:{entry['yes']}:{d}" not in cache["tried"]:
                    need["yes"].setdefault(entry["yes"], set()).add(d)
            if "hot" in entry and "hot" in sources:
                if d >= today or f"hot:{d}" not in cache["tried"]:
                    need["hot"].add(d)
    return need


# Puts a new answer for [first_day, last_day] into a source's cached programmes.
# An empty answer never wipes what is cached. overwrite=True (manual refresh):
# the new answer replaces those days; otherwise the new answer wins where it
# differs and the old data stays only where the new one has nothing.
def merge_days(progs, new, first_day, last_day, overwrite=False):
    if not new:
        return progs
    start = day_window(first_day)[0]
    end = day_window(last_day)[1]
    outside = [p for p in progs if not start <= p["start"] < end]
    if overwrite:
        return outside + new
    inside = [p for p in progs if start <= p["start"] < end]
    return outside + combine([normalize(new), normalize(inside)])


def runs_of_days(days, max_len):
    """Sorted dates -> [(first, last)] of consecutive days, max_len each."""
    runs = []
    for d in sorted(days):
        if runs and d == runs[-1][1] + timedelta(days=1) and (d - runs[-1][0]).days < max_len:
            runs[-1] = (runs[-1][0], d)
        else:
            runs.append((d, d))
    return runs


def prune(cache, now_ts, today):
    oldest = now_ts - PAST_DAYS * 86400
    for src in SOURCES:
        for sid in list(cache[src]):
            kept = [p for p in cache[src][sid] if p["stop"] >= oldest]
            if kept:
                cache[src][sid] = kept
            else:
                del cache[src][sid]
    first = today - timedelta(days=PAST_DAYS + 1)
    cache["tried"] = {
        k: v for k, v in cache["tried"].items()
        if re.search(r"(\d{4}-\d{2}-\d{2})$", k) and k[-10:] >= first.isoformat()
    }


# The whole update. Returns {tvgid: [programme, ...]} for the 7 days back ..
# 7 days ahead window; cache is updated in place. force=True: manual refresh -
# everything is downloaded again and overwrites the cache.
def update(
    channels, cache, now_ts, sources=SOURCES, log=default_log, should_stop=None,
    session=None, force=False,
):
    mapping = valid_mapping(channels)
    if not mapping:
        log("no channel in the channel list has yes_id / hot_id - nothing to download", "warning")
        return {}
    today = il_today(now_ts)
    need = plan_downloads(mapping, cache, today, sources, force)
    yes_days = sum(len(days) for days in need["yes"].values())
    log(
        f"{'manual refresh' if force else 'missing only'}: yes {yes_days} channel-days "
        f"({len(need['yes'])} channels), HOT {len(need['hot'])} days",
        "info",
    )
    if need["yes"] or need["hot"]:
        session = session or new_session()
    stats = {"yes": [0, 0, 0, 0], "hot": [0, 0, 0, 0]}  # asked, answered, empty, programmes

    for yid in sorted(need["yes"]):
        for d in sorted(need["yes"][yid]):
            if should_stop and should_stop():
                break
            stats["yes"][0] += 1
            try:
                new = fetch_yes_day(session, yid, d)
            except (*REQUEST_ERRORS, ValueError) as e:
                log(f"yes {yid} {d}: {e}", "warning")
                continue
            stats["yes"][1] += 1
            stats["yes"][2] += not new
            stats["yes"][3] += len(new)
            cache["yes"][yid] = merge_days(cache["yes"].get(yid, []), new, d, d, force)
            cache["tried"][f"yes:{yid}:{d}"] = int(now_ts)

    hot_ids = sorted({e["hot"] for e in mapping if "hot" in e})
    for first, last in runs_of_days(need["hot"], HOT_MAX_DAYS_PER_REQUEST):
        if should_stop and should_stop():
            break
        stats["hot"][0] += 1
        try:
            result = fetch_hot_range(session, hot_ids, first, last)
        except (*REQUEST_ERRORS, ValueError) as e:
            log(f"HOT {first}..{last}: {e}", "warning")
            continue
        received = sum(len(v) for v in result.values())
        stats["hot"][1] += 1
        stats["hot"][2] += not received
        stats["hot"][3] += received
        for hid, new in result.items():
            cache["hot"][hid] = merge_days(cache["hot"].get(hid, []), new, first, last, force)
        d = first
        while d <= last:
            cache["tried"][f"hot:{d}"] = int(now_ts)
            d += timedelta(days=1)
    prune(cache, now_ts, today)

    for src, name in (("yes", "yes"), ("hot", "HOT")):
        asked, answered, empty, received = stats[src]
        if asked:
            log(
                f"{name}: {asked} requests, {answered} answered "
                f"({empty} empty), {received} programmes received",
                "info" if answered else "warning",
            )
    guide = {}
    for entry in mapping:
        progs = cached_channel(cache, entry)
        if progs:
            guide[entry["tvgid"]] = progs
    total = sum(len(p) for p in guide.values())
    log(f"guide: {total} programmes on {len(guide)} of {len(mapping)} channels", "info")
    asked = stats["yes"][0] + stats["hot"][0]
    answered = stats["yes"][1] + stats["hot"][1]
    if asked and not answered and not guide:
        raise GrabFailed("neither yes nor HOT answered and nothing is cached")
    return guide


def build_xmltv(guide, channels, credit=CREDIT):
    """ElementTree root. Deterministic (same input -> same bytes).
    Every programme's description ends with the credit, like the original."""
    names = {}
    for ch in channels:
        if isinstance(ch, dict) and ch.get("tvgid") in guide:
            names[ch["tvgid"]] = ch.get("name_he") or ch.get("name_en") or ch["tvgid"]
    root = ET.Element("tv")
    order = [t for t in names] + sorted(t for t in guide if t not in names)
    for tvgid in order:
        channel = ET.SubElement(root, "channel", {"id": tvgid})
        ET.SubElement(channel, "display-name").text = clean_text(names.get(tvgid, tvgid), 100)
    for tvgid in order:
        for p in guide[tvgid]:
            elem = ET.SubElement(
                root,
                "programme",
                {"start": xmltv_time(p["start"]), "stop": xmltv_time(p["stop"]), "channel": tvgid},
            )
            ET.SubElement(elem, "title").text = p["title"] or NO_TITLE
            ET.SubElement(elem, "desc").text = (p["desc"] + credit).strip()
    return root


def write_xmltv(root, path, gz=False):
    data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    with open(path, "wb") as raw:
        if gz:  # mtime=0 - git sees only real changes
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as f:
                f.write(data)
        else:
            raw.write(data)
