import random

# Default safari and applewebkit version
DSAV    = "605.1.15"
MOZILLA = "Mozilla/5.0"
KHTML   = "(KHTML, like Gecko)"

# iOS versions and build numbers
ios_versions = ["17_2", "17_3", "18_1", "18_3_2"]
ios_builds = {
    "17_2": ["17B102", "17B103", "17B104"],
    "17_3": ["17E5233e", "17E5234f", "17E5235g"],
    "18_1": ["18A2301", "18A2302"],
    "18_3_2": ["18D101", "18D102", "18D103"],
}

# Define browser version ranges (min, max)
browser_version_ranges = {
    "Chrome": (110, 134),
    "Firefox": (115, 140),
    "Edge": (100, 138),
    "Opera": (80, 106),
    "Safari": (11, 18),
}


# Random platform generation
def generate_platform():
    platforms_mobile = [
        f"Linux; Android {random.randint(13, 16)}",
        f"iPhone; CPU iPhone OS {random.choice(ios_versions)} like Mac OS X",
    ]
    platforms_desktop = [
        "Windows NT 10.0; Win64; x64",
        "Macintosh; Intel Mac OS X 13_5",
        "X11; Linux x86_64",
    ]
    return random.choice(platforms_mobile + platforms_desktop)


# Random iOS build number based on version
def random_ios_build_number(version):
    return random.choice(ios_builds.get(version, [])) if version else "Unknown"


# Random browser version generator within the specified range
def generate_browser_version(browser, platform):
    min_version, max_version = browser_version_ranges.get(browser, (90, 110))
    major = random.randint(min_version, max_version)
    minor = random.randint(0, 9999)
    patch = random.randint(0, 150)
    version = f"{major}.0.{minor}.{patch}"

    # Detect Android with Edge
    if "Android" in platform and browser == "Edge":
        browser = "EdgeA"

    # Detect non-standard engine usage
    use_webkit = True
    if "Linux" in platform and ("Chrome" in browser or "Opera" in browser):
        use_webkit = False

    engine = f"AppleWebKit/{DSAV} {KHTML}" if use_webkit else KHTML

    # Build the user agent string
    return f"{MOZILLA} ({platform}) {engine} {browser}/{version}"


# Firefox version string (special case)
def generate_firefox_version(platform):
    min_version, max_version = browser_version_ranges.get("Firefox", (90, 140))
    version = f"{random.randint(min_version, max_version)}.0"
    return f"{MOZILLA} ({platform}; rv:{version}) Gecko/20100101 Firefox/{version}"


# Generate user agent string
def generate_user_agent():
    platform = generate_platform()

    # if the platform is iOS, handle it separately
    if "iPhone" in platform:
        ios_version = platform.split("OS ")[1].split(" ")[0]
        build_number = random_ios_build_number(ios_version)
        return f"{MOZILLA} ({platform}) AppleWebKit/{DSAV} {KHTML} Version/{ios_version.replace('_', '.')} Mobile/{build_number} Safari/{DSAV}"

    browser_map = {
        "Chrome": lambda platform: generate_browser_version("Chrome", platform),
        "Firefox": lambda platform: generate_firefox_version(platform),
        "Edge": lambda platform: generate_browser_version("Edge", platform),
        "Opera": lambda platform: generate_browser_version("Opera", platform),
    }

    browser = random.choice(list(browser_map.keys()))

    # Call the relevant function from the browser_map
    return browser_map[browser](platform)
