# -*- coding: utf-8 -*-
import sys
import threading
from urllib.parse import parse_qsl, urlencode

import common
import epglist as epg
import url_finder as url_f
from import_xbmc import xbmc, xbmcgui, xbmcplugin, xbmcaddon

# Global variables
addon_handle = common.get_handle()
channels_list = common.load_channels()

SUPPORTED_SRVS_ORDER = url_f.SUPPORTED_SRVS_ORDER
DEFAULT_ENUM_VALUES  = ["ask"] + SUPPORTED_SRVS_ORDER
OVERRIDE_ENUM_VALUES = ["default"] + DEFAULT_ENUM_VALUES
SRV_INLINE_HEADERS   = url_f.SRV_INLINE_HEADERS
SRV_LABEL_IDS        = url_f.SRV_LABEL_IDS



# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f"{sys.argv[0]}?{urlencode(kwargs)}"
    except Exception as e:
        xbmc.log(f"Error creating URL: {e}", xbmc.LOGERROR)
        return ""


# Display the categories list with channels and settings
def categories_list():
    title = common.get_locale_string(30402)

    xbmcplugin.setPluginCategory(addon_handle, common.get_label_color(title, bold=True, color="purple"))
    xbmcplugin.setContent(addon_handle, "videos")

    img_tv         = common.get_addon_icon("tv.jpg")
    img_sports     = common.get_addon_icon("sports.jpg")
    channels_label = common.get_locale_string(30504)
    settings_label = common.get_locale_string(30401)
    channels_name  = common.get_label_color(channels_label, bold=True, color="none")
    settings_name  = common.get_label_color(settings_label, bold=True, color="yellow")
    items          = []

    # Channels section
    channels_url = get_url(mode=7)
    if not channels_url:
        xbmc.log("Failed to create channels URL", xbmc.LOGERROR)
        return

    li = xbmcgui.ListItem(label=channels_name)
    li.setArt({"thumb": img_sports, "icon": img_sports, "fanart": img_sports})
    info = li.getVideoInfoTag()
    info.setTitle(str(channels_label))
    items.append((channels_url, li, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        li = xbmcgui.ListItem(label=settings_name)
        li.setArt({"thumb": img_tv, "icon": img_tv, "fanart": img_tv})
        info = li.getVideoInfoTag()
        info.setTitle(str(settings_label))
        items.append((settings_url, li, False))

    xbmcplugin.addDirectoryItems(addon_handle, items)
    xbmcplugin.endOfDirectory(addon_handle)


# Play video from the selected channel
def play_video(channel_nid):
    if not channel_nid:
        xbmc.log("[play_video] Channel ID is missing.", xbmc.LOGERROR)
        return

    channel = next((ch for ch in channels_list if ch.get("nid") == channel_nid), None)
    if not channel:

        xbmc.log(f"[play_video] Channel with ID {channel_nid} not found.", xbmc.LOGERROR)
        return

    threading.Thread(target=common.update_files, daemon=True).start()

    addon_live = xbmcaddon.Addon(common.Addon_ID)
    try:
        global_idx = addon_live.getSettingInt("source.default")
    except Exception:
        global_idx = int(addon_live.getSetting("source.default") or "0")
    try:
        per_idx = addon_live.getSettingInt(f"source.override.{channel_nid}")
    except Exception:
        per_idx = int(addon_live.getSetting(f"source.override.{channel_nid}") or "0")

    global_choice = (
        DEFAULT_ENUM_VALUES[global_idx]
        if 0 <= global_idx < len(DEFAULT_ENUM_VALUES)
        else "ask"
    )
    per_choice = (
        OVERRIDE_ENUM_VALUES[per_idx]
        if 0 <= per_idx < len(OVERRIDE_ENUM_VALUES)
        else "default"
    )
    chosen = global_choice if per_choice == "default" else per_choice
    sources = channel.get("source", {}) or {}

    if chosen == "ask":
        return ask_and_play(channel_nid, sources)

    url_tuple, srv_used = resolve_srv_on_demand(chosen, sources, channel_nid)
    if url_tuple:
        return play_resolved(channel_nid, sources, url_tuple, srv_used)

    xbmc.log(f"[play_video] chosen '{chosen}' unavailable/failed for {channel_nid}; opening picker", xbmc.LOGINFO)
    common.notify(30702, 30714)
    return ask_and_play(channel_nid, sources)


def ask_and_play(channel_nid, sources):

    avail     = []
    canceled  = False
    monitor   = xbmc.Monitor()
    progress  = xbmcgui.DialogProgress()
    title_txt = common.get_locale_string(30716)
    sub_txt   = common.get_locale_string(30715)

    try:
        progress.create(title_txt, sub_txt)
        total = len(SUPPORTED_SRVS_ORDER)
        for i, srv in enumerate(SUPPORTED_SRVS_ORDER, 1):
            if progress.iscanceled() or monitor.abortRequested():
                canceled = True
                break
            label_id = SRV_LABEL_IDS.get(srv)
            label_txt = common.get_locale_string(label_id) if label_id else srv.upper()
            try:
                progress.update(int(100.0 * i / max(total, 1)), label_txt)
            except Exception:
                pass
            url_tuple, srv_used = resolve_srv_on_demand(srv, sources, channel_nid)
            if url_tuple:
                display_srv = "ap" if srv_used in ("ap", "ap2") else srv_used
                display_id = SRV_LABEL_IDS.get(display_srv)
                display_txt = (
                    common.get_locale_string(display_id)
                    if display_id
                    else display_srv.upper()
                )
                avail.append((display_txt, url_tuple, srv_used))
    finally:
        try:
            progress.close()
        except Exception:
            pass
    if canceled:

        xbmc.log(f"[ask_and_play] canceled by user for nid={channel_nid}", xbmc.LOGDEBUG)
        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())

        return
    if not avail:

        xbmc.log(f"[ask_and_play] No available sources for {channel_nid}", xbmc.LOGWARNING)
        common.notify(30700, 30717)
        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())

        return
    labels = [label_txt for (label_txt, _url_tuple, _srv_used) in avail]
    choice = xbmcgui.Dialog().select(common.get_locale_string(30904), labels)
    if choice < 0:

        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())
        return
    label_txt, url_tuple, srv_used = avail[choice]
    return play_resolved(channel_nid, sources, url_tuple, srv_used)


def resolve_srv_on_demand(srv, sources, channel_nid):
    key = srv if srv in sources else None
    if not key:
        return None, srv
    idval = sources.get(key)
    try:
        link, hdrs = url_f.url_origin(key, idval, channel_nid)
        if not link:
            return None, key
        return ((link, hdrs), key)
    except Exception as e:
        xbmc.log(f"[resolve] error for {channel_nid} srv={key}: {e}", xbmc.LOGERROR)
        return None, key


def play_resolved(channel_nid, sources, url_tuple, srv_used):
    if isinstance(url_tuple, (list, tuple)) and len(url_tuple) == 2:
        m3u8_link, headers = url_tuple
    elif isinstance(url_tuple, str):
        m3u8_link, headers = url_tuple, {}
    else:
        xbmc.log("[play_resolved] invalid resolver return", xbmc.LOGERROR)

        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())
        return ask_and_play(channel_nid, sources)
    try:
        inline = srv_used in SRV_INLINE_HEADERS
        ok, code, reason = url_f.check_url_status(m3u8_link, headers, inline=inline)
        if not ok:
            if code and 400 <= code < 500:
                common.notify(30702, 30714)

            xbmc.log(f"[play_resolved] preflight failed ({code} {reason}) for nid={channel_nid}, srv={srv_used}", xbmc.LOGWARNING)
            xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())

            return ask_and_play(channel_nid, sources)
    except Exception as e:
        xbmc.log(f"[play_resolved] preflight error: {e}", xbmc.LOGERROR)
        common.notify(30702, 30714)

        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())
        return ask_and_play(channel_nid, sources)
    try:
        if srv_used in SRV_INLINE_HEADERS:
            # inline headers

            link = (f"{m3u8_link}|{urlencode(headers)}" if (headers and isinstance(headers, dict)) else m3u8_link)
            play_item = xbmcgui.ListItem(path=link)

        # With inputstream.adaptive
        else:
            play_item = xbmcgui.ListItem(path=m3u8_link)
            play_item.setProperty("inputstream", "inputstream.adaptive")
            play_item.setProperty("IsLive", "true")
            play_item.setProperty("inputstream.adaptive.play_timeshift_buffer", "false")
            if headers and isinstance(headers, dict) and headers:
                h = urlencode(headers)
                play_item.setProperty("inputstream.adaptive.manifest_headers", h)
                play_item.setProperty("inputstream.adaptive.stream_headers", h)

        xbmcplugin.setResolvedUrl(
            handle=addon_handle, succeeded=True, listitem=play_item
        )
    except Exception as e:
        xbmc.log(f"[play_resolved] playback error: {e}", xbmc.LOGERROR)
        common.notify(30702, 30714)

        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=False, listitem=xbmcgui.ListItem())
        return ask_and_play(channel_nid, sources)


# Get all channels sorted by user preferences
def get_all_channels():
    for channel in channels_list:

        xbmc.log(f"Checking channel: nid={channel['nid']}, index={channel['index']}", xbmc.LOGDEBUG)
        if not isinstance(channel["index"], int):
            xbmc.log(f"Invalid index value detected: {channel['index']}", xbmc.LOGERROR)

    user_channels = [
        channel
        for channel in channels_list
        if common.get_int_setting(channel["nid"], channel["index"]) > 0
    ]
    sorted_channels = sorted(user_channels, key=lambda k: k["index"])
    return sorted_channels


# Create IPTV files and launch the addon
def make_iptv_files():
    epg.generate_iptv_list(get_all_channels())


# Perform actions during the first run of the addon
def first_run():
    make_iptv_files()
    epg.set_iptv_client_settings()
    common.notify(30500, 30412)


# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f"Addon.OpenSettings({common.Addon_ID})")


# Launch the EPG window
def launch_epg():
    if epg.pvr_refreshing:
        common.notify(30420, 30407)
        return
    xbmc.executebuiltin("ActivateWindow(TVGuide,pvr://channels/tv)")


# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin("ActivateWindow(pvrsettings)")


# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get("mode")
    url = params.get("url")

    actions = {
        "-1": categories_list,
        "1": lambda: play_video(url),
        "2": open_settings,
        "3": lambda: (epg.open_iptv_client_settings(), sys.exit()),
        "4": lambda: (make_iptv_files(), common.notify(30805, 30413), sys.exit()),

        "5": lambda: (epg.set_iptv_client_settings(), common.notify(30414, 30415), sys.exit()),

        "6": lambda: (epg.fetch_and_save_epg(), common.notify(30407, 30408)),
        "7": launch_epg,
        "8": lambda: (open_pvrsettings(), sys.exit()),
        "9": lambda: (first_run(), sys.exit()),
        "10": lambda: (common.save_links_json(), common.notify(30409, 30410)),
        "11": lambda: (common.check_version(), sys.exit()),
    }

    if mode in actions:
        actions[mode]()
    else:
        if params:
            xbmc.log(f"Invalid mode: {mode}", xbmc.LOGERROR)
            sys.exit()
        else:
            categories_list()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
