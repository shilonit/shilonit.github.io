# -*- coding: utf-8 -*-
import sys, os, io, json, collections, time, random, re, requests
from import_xbmc import xbmc, xbmcaddon, xbmcvfs
from UA import userAgents
import epglist as epg

#########################################################
# Common variables and functions
Addon_ID        = 'plugin.video.tvisrael'
Addon_Name      = 'TV Israel'
Addon           = xbmcaddon.Addon(Addon_ID)
Addon_Ver       = Addon.getAddonInfo('version')
Addon_Path      = Addon.getAddonInfo('path')
Addon_Icon      = Addon.getAddonInfo('icon')
Old_Links_File  = 'ddy_url.json'
Links_File      = 'urls.json'
M3U_Name        = 'tvisrael.m3u'
Epg_Name        = 'epg.json'
Xml_Name        = 'epg.xml'
user_agent       = random.choice(userAgents)

# Define file paths
profile_dir      = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
images_dir       = xbmcvfs.translatePath(os.path.join(Addon_Path, 'resources', 'images'))
m3u_file         = os.path.join(profile_dir, M3U_Name)
xml_file         = os.path.join(profile_dir, Xml_Name)
links_file_path  = os.path.join(profile_dir, Links_File)
app_logo         = os.path.join(images_dir, 'tv.jpg')
epg_file         = os.path.join(profile_dir, Epg_Name)
github_base      = 'https://raw.githubusercontent.com/shilonit'
github_url       = f'{github_base}/epgtools/main/sport'
epg_url          = f'{github_url}/{Epg_Name}'

##########################################################

# Make sure profile directory exists
if not os.path.exists(profile_dir):
    os.makedirs(profile_dir)

# Utility function to safely get handle from arguments
def get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1

# Get Addon_Icon full path
def get_addon_icon(Addon_Icon):
    return os.path.join(images_dir, Addon_Icon)

# Check if an addon is installed
def is_addon_installed(addonid):
    return xbmc.getCondVisibility(f'System.HasAddon({addonid})')

# Install addon
def install_addon(addonid):
    xbmc.executebuiltin(f'InstallAddon({addonid})')

# Check if addon is enabled
def is_addon_enabled(addonid):
    try:
        json_request = (
            f'{{"jsonrpc":"2.0",'
            f'"method":"Addons.GetAddonDetails",'
            f'"params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'
        )
        response = json.loads(xbmc.executeJSONRPC(json_request))

        return response['result']['addon']['enabled']
    except json.JSONDecodeError:
        return False

# Get localized string
def get_locale_string(id):
    return Addon.getLocalizedString(id)

# Get label color
def get_label_color(text, key_color=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(key_color)
    if bold:
        text = f'[B]{text}[/B]'
    return text if color == 'none' else f'[COLOR {color}]{text}[/COLOR]'

# Read and return settings from addon
def get_addon_setting(key):
    return Addon.getSetting(key)

# Read a list from a file
def read_list(fileName):
    try:
        with io.open(fileName, 'r', encoding='utf-8') as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except Exception as ex:
        xbmc.log(str(ex), 3)
        return []

# Escape XML special characters
def escape_xml(text):
    if isinstance(text, bytes):
        text = text.decode('utf-8')
    return text.replace('&', '&amp;').replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")

# Check if file is older than a given threshold
def is_file_old(filename, deltaInSec=10800):
    last_update = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - last_update) > deltaInSec

# Get integer setting, defaulting if necessary
def get_int_setting(k, v=0):
    setting = Addon.getSetting(k)
    if not setting or not setting.isdigit():
        xbmc.log(f"[get_int_setting] Invalid setting detected for key '{k}', defaulting to {v}", xbmc.LOGWARNING)
        Addon.setSetting(k, str(v))
        return v
    return int(setting)

# Get text content from a file
def get_text_file(filename):
    if os.path.isfile(filename):
        with io.open(filename, 'r', encoding="utf-8") as f:
            return f.read()
    return ''

# Fetches the EPG data and saves it to a file.
def save_links_json():
    # Check if the links file is 'ddy_url.json' and rename it to 'urls.json' - ver > 2.4.3
    old_links_path = os.path.join(profile_dir, Old_Links_File)
    if os.path.exists(old_links_path):
        try:
            os.rename(old_links_path, links_file_path)
            xbmc.log(f"Renamed {Old_Links_File} to {Links_File}", xbmc.LOGDINFO)
        except Exception as e:
            xbmc.log(f"Error renaming file: {e}", xbmc.LOGERROR)

    links_file = os.path.join(profile_dir, Links_File)
    links_url = f'{github_url}/{Links_File}'
    try:
        response = requests.get(links_url, timeout=10)
        response.raise_for_status()
        json_data = response.json()
        # Ensure json_data is valid before dumping to file
        if isinstance(json_data, (dict, list)):
            with open(links_file, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
            xbmc.log("Fetched data successfully and saved to links_File.", xbmc.LOGDEBUG)
        else:
            xbmc.log("Fetched data is not in JSON format", xbmc.LOGERROR)
    except requests.RequestException as e:
        xbmc.log(f"Error fetching links_File: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Unexpected error while fetching links_File: {e}", xbmc.LOGERROR)

# Check if the links file is old and needs to be updated
def update_files():
    epgDeltaInSec = Addon.getSettingInt("update_EPG_interval") * 3600  # Convert hours to seconds
    if is_file_old(epg_file, epgDeltaInSec):
        try:
            epg.fetch_and_save_epg()
        except Exception as e:
            xbmc.log(f"Failed to update EPG file: {e}", xbmc.LOGERROR)

    linksDeltaInSec = Addon.getSettingInt("update_links_interval") * 3600  # Convert hours to seconds
    if is_file_old(links_file_path, linksDeltaInSec):
        try:
            save_links_json()
        except Exception as e:
            xbmc.log(f"Failed to update links file: {e}", xbmc.LOGERROR)


def notify(title_id: int, message_id: int, duration: int = 5000, icon: str = None) -> None:
    title = get_locale_string(title_id)
    message = get_locale_string(message_id)
    # app_logo default
    if icon is None:
        icon = app_logo
    xbmc.executebuiltin(f'Notification({title}, {message}, {duration}, "{icon}")')

# Compare two version strings
def compare_versions(v1, v2):
    parts1 = list(map(int, v1.split('.')))
    parts2 = list(map(int, v2.split('.')))
    return parts1 > parts2

# Check for updates and notify if available
def check_version(startup=False):
    url = f'{github_base}/shilonit.github.io/master/addons.xml'
    response = requests.get(url)

    if not response.ok:
        xbmc.log(f"[check_version] Failed to fetch addons.xml", xbmc.LOGERROR)
        return

    pattern = rf'<addon id="{Addon_ID}".*?version="([\d\.]+)"'
    match = re.search(pattern, response.text)
    if not match:
        xbmc.log(f"[check_version] Failed to find version in addons.xml", xbmc.LOGERROR)
        return

    remote_version = match.group(1)
    if compare_versions(remote_version, Addon_Ver):
        notify(30703, 30712)
        xbmc.executebuiltin("UpdateAddonRepos()")
        time.sleep(3)
        xbmc.executebuiltin("UpdateLocalAddons()")
        return
    xbmc.log(f"[check_version] No update available. startup={startup}", xbmc.LOGDEBUG)
    # If the version is up-to-date and NOT in startup mode, notify the user
    if not startup:
        notify(30702, 30713)