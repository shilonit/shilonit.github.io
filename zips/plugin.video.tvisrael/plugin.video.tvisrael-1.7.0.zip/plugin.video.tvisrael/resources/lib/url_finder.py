import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse

def url_origin(channel_id, srv):
    if srv == 'top':
        # Step 1: Extract the channel number from channel_id
        channel_number = ''.join(filter(str.isdigit, channel_id))  # Get the digits from channel_id
        
        # Create the URL using the channel number
        url = f'https://topembed.pw/channel/YesSport{channel_number}[Israel]'

        # Step 2: Send a request to the URL and parse the response
        response = requests.get(url)
        response.raise_for_status()  # Check for HTTP errors

        # Parse the response content
        soup = BeautifulSoup(response.text, 'html.parser')
        script_tags = soup.find_all('script')
        m3u8_link = None

        for script in script_tags:
            if 'source:' in script.text:
                start = script.text.find("source: '") + len("source: '")
                end = script.text.find("'", start)
                m3u8_link = script.text[start:end]
                break

        if m3u8_link:
            #origin = urlparse(url).scheme + "://" + urlparse(url).netloc
            origin = 'https://topembed.pw'
            return m3u8_link, origin
        else:
            raise ValueError('m3u8 link not found in the response.')
    
    elif srv == 'ddy':
        url = f'https://daddylive.sx/embed/stream-{channel_id}.php'
        response = requests.get(url)
        response.raise_for_status()  # Check for HTTP errors

        content_type = response.headers.get('Content-Type', '') # Check content type
        if 'text/html' in content_type:
            # Parse the response content
            soup = BeautifulSoup(response.text, 'html.parser')
            iframe = soup.find('iframe') # First iframe

            if iframe and iframe.has_attr('src'):
                iframe_src = iframe['src']
                response = requests.get(iframe_src)
                response.raise_for_status()  # Check for HTTP errors

                # Parse the second response content
                soup = BeautifulSoup(response.text, 'html.parser')
                script_tags = soup.find_all('script')
                m3u8_link = None

                for script in script_tags:
                    if 'source:' in script.text:
                        start = script.text.find("source: '") + len("source: '")
                        end = script.text.find("'", start)
                        m3u8_link = script.text[start:end]
                        break

                if m3u8_link:
                    origin = urlparse(iframe_src).scheme + "://" + urlparse(iframe_src).netloc
                    return m3u8_link, origin 
                else:
                    raise ValueError('m3u8 link not found in the response.')

        raise ValueError('No iframe source found for DDY service.')
    
    else:
        raise ValueError('Unsupported service type.')