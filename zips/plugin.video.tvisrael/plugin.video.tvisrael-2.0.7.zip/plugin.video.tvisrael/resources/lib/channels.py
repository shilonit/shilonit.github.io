﻿# -*- coding: utf-8 -*-
Tvs = [
    { 'nid': 'sport1', 'index': 50, 'name': 30602, 'thumb': 'sport_1.jpg', 'srv': 'ddy', 'id': '140', 'tvgid': 'sport1' },
    { 'nid': 'sport2', 'index': 51, 'name': 30603, 'thumb': 'sport_2.jpg', 'srv': 'ddy', 'id': '141', 'tvgid': 'sport2' },
    { 'nid': 'sport3', 'index': 52, 'name': 30604, 'thumb': 'sport_3.jpg', 'srv': 'ddy', 'id': '142', 'tvgid': 'sport3' },
    { 'nid': 'sport4', 'index': 53, 'name': 30605, 'thumb': 'sport_4.jpg', 'srv': 'ddy', 'id': '143', 'tvgid': 'sport4' },
    { 'nid': 'sport5', 'index': 54, 'name': 30606, 'thumb': 'sport_5.jpg', 'srv': 'ddy', 'id': '144', 'tvgid': 'sport5' },
    { 'nid': '5plus', 'index': 55, 'name': 30607, 'thumb': '5_plus.jpg', 'srv': 'ddy', 'id': '145', 'tvgid': '5plus' },
    { 'nid': '5live', 'index': 56, 'name': 30608, 'thumb': '5_live.jpg', 'srv': 'ddy', 'id': '146', 'tvgid': '5live' },
    { 'nid': '5star', 'index': 57, 'name': 30609, 'thumb': '5_stars.jpg', 'srv': 'ddy', 'id': '147', 'tvgid': '5stars' },
    { 'nid': '5gold', 'index': 58, 'name': 30610, 'thumb': '5_gold.jpg', 'srv': 'ddy', 'id': '148', 'tvgid': '5gold'},
    { 'nid': 'one', 'index': 59, 'name': 30611, 'thumb': 'One.jpg', 'srv': 'ddy', 'id': '541', 'tvgid': 'ONE' },
    { 'nid': 'one2', 'index': 60, 'name': 30612, 'thumb': 'One_2.jpg', 'srv': 'ddy', 'id': '542', 'tvgid': 'ONE2' }
]
