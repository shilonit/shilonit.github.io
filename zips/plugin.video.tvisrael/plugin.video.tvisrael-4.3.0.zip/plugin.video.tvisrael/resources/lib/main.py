# -*- coding: utf-8 -*-
import shutil
import sys
import os
import requests
from urllib.parse import parse_qsl, urlencode, urlparse

import common
import epglist as epg
from import_xbmc import xbmc, xbmcgui, xbmcplugin

# Global variables
addon_handle = common.get_handle()
channels_list = common.load_channels()


# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f"{sys.argv[0]}?{urlencode(kwargs)}"
    except Exception as e:
        xbmc.log(f"Error creating URL: {e}", xbmc.LOGERROR)
        return ""


# Display the categories list with channels and settings
def categories_list():
    title = common.get_locale_string(30402)
    xbmcplugin.setPluginCategory(
        addon_handle, common.get_label_color(title, bold=True, color="purple")
    )
    xbmcplugin.setContent(addon_handle, "videos")
    img_tv = common.get_addon_icon("tv.jpg")
    img_sports = common.get_addon_icon("sports.jpg")
    channels_label = common.get_locale_string(30504)
    settings_label = common.get_locale_string(30401)
    channels_name = common.get_label_color(channels_label, bold=True, color="none")
    settings_name = common.get_label_color(settings_label, bold=True, color="yellow")
    items = []
    # Channels section
    channels_url = get_url(mode=7)
    if not channels_url:
        xbmc.log("Failed to create channels URL", xbmc.LOGERROR)
        return

    li = xbmcgui.ListItem(label=channels_name)
    li.setArt({"thumb": img_sports, "icon": img_sports, "fanart": img_sports})
    info = li.getVideoInfoTag()
    info.setTitle(str(channels_label))
    items.append((channels_url, li, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        li = xbmcgui.ListItem(label=settings_name)
        li.setArt({"thumb": img_tv, "icon": img_tv, "fanart": img_tv})
        info = li.getVideoInfoTag()
        info.setTitle(str(settings_label))
        items.append((settings_url, li, False))

    xbmcplugin.addDirectoryItems(addon_handle, items)
    xbmcplugin.endOfDirectory(addon_handle)


def get_playlist_url_and_access_key(reset_token=True):
    access_key = common.Addon.getSetting("access_key").strip()
    if not access_key:
        common.notify(30700, 30714)
        return None, None
    if reset_token:
        common.Addon.setSetting("user_token", "")
    playlist_url = f"http://af-play.com/playlist/{access_key}.m3u8"
    xbmc.log(f"[Playlist] Generated URL: {playlist_url}", xbmc.LOGDEBUG)
    return playlist_url, access_key


# Fetch user token from the playlist using the access key
def fetch_token_from_access_key():
    playlist_url, access_key = get_playlist_url_and_access_key(reset_token=True)
    headers = {"User-Agent": common.user_agent}
    try:
        r = requests.get(playlist_url, headers=headers, timeout=10)
        r.raise_for_status()
        text = r.text
    except Exception as e:
        xbmc.log(f"[TOKEN] Failed fetching playlist: {e}", xbmc.LOGERROR)
        return False

    user_token = None
    for line in text.splitlines():
        line = line.strip()
        if "/s/" in line and "/video.m3u8" in line:
            # http://bethoven.af-stream.com:8080/s/{user_token}/{nid}/video.m3u8
            parts = line.split("/s/", 1)[1].split("/")
            if len(parts) >= 2:
                user_token = parts[0]
                break

    if not user_token and access_key:
        xbmc.log("[TOKEN] Token not found in playlist", xbmc.LOGERROR)
        common.notify(30700, 30716)
        return False

    common.Addon.setSetting("user_token", user_token)
    xbmc.log(f"[TOKEN] Token stored: {user_token}", xbmc.LOGINFO)
    common.notify(30702, 30717)
    return True


# Download channel logos based on the playlist
def download_channel_logos():
    common.notify(30702, 30611)
    playlist_url, access_key = get_playlist_url_and_access_key(reset_token=False)

    if not playlist_url:
        xbmc.log("[Logos] No access_key – cannot download logos", xbmc.LOGWARNING)
        return False

    headers = {"User-Agent": common.user_agent}
    try:
        r = requests.get(playlist_url, headers=headers, timeout=15)
        r.raise_for_status()
        text = r.text
    except Exception as e:
        xbmc.log(f"[Logos] Failed to fetch playlist: {e}", xbmc.LOGERROR)
        return False

    if os.path.exists(common.logos_dir):
        shutil.rmtree(common.logos_dir, ignore_errors=True)
    os.makedirs(common.logos_dir)

    playlist_to_internal_tvgid = {}
    for ch in channels_list:
        nid = ch.get("nid")
        internal_tvgid = ch.get("tvgid")
        if nid and internal_tvgid:
            playlist_to_internal_tvgid[nid] = internal_tvgid

    downloaded = 0
    failed = 0

    for line in text.splitlines():
        line = line.strip()
        if 'tvg-logo="' in line:
            start = line.find('tvg-logo="') + len('tvg-logo="')
            end = line.find('"', start)
            logo_url = line[start:end]

            tvg_start = line.find('tvg-id="') + len('tvg-id="')
            tvg_end = line.find('"', tvg_start)
            playlist_tvgid = line[tvg_start:tvg_end].strip()

            if not playlist_tvgid:
                continue

            internal_tvgid = playlist_to_internal_tvgid.get(playlist_tvgid)
            if not internal_tvgid:
                xbmc.log(
                    f"[Logos] No internal tvgid found for playlist tvg-id: {playlist_tvgid}",
                    xbmc.LOGWARNING,
                )
                continue

            ext = os.path.splitext(urlparse(logo_url).path)[1]
            if not ext:
                ext = ".png"

            filename = f"{internal_tvgid}{ext}"
            local_path = os.path.join(common.logos_dir, filename)
            try:
                img_r = requests.get(logo_url, headers=headers, timeout=10, stream=True)
                img_r.raise_for_status()
                with open(local_path, "wb") as f:
                    for chunk in img_r.iter_content(8192):
                        f.write(chunk)
                xbmc.log(
                    f"[Logos] Saved as internal tvgid: {filename} (from {playlist_tvgid})",
                    xbmc.LOGDEBUG,
                )
                downloaded += 1
            except Exception as e:
                xbmc.log(
                    f"[Logos] Failed {internal_tvgid} ({playlist_tvgid}): {e}",
                    xbmc.LOGWARNING,
                )
                failed += 1
    xbmc.log(f"[Logos] Finished: {downloaded} saved, {failed} failed", xbmc.LOGINFO)
    common.notify(30702, 30612)
    return True


# Perform actions during the first run of the addon
def clean_profile_dir():
    keep_files = {
        common.M3U_Name,
        common.Xml_Name,
        os.path.basename(common.user_settings),
    }
    try:
        for item in os.listdir(common.profile_dir):
            item_path = os.path.join(common.profile_dir, item)
            if item not in keep_files:
                try:
                    os.remove(item_path)
                    xbmc.log(
                        f"[first_run] Removed leftover file: {item}", xbmc.LOGDEBUG
                    )
                except Exception as e:
                    xbmc.log(f"[first_run] Failed removing {item}: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"[first_run] Failed cleaning profile dir: {e}", xbmc.LOGERROR)


def first_run():
    clean_profile_dir()
    if not fetch_token_from_access_key():
        xbmc.log(
            "[first_run] Token validation failed – aborting setup", xbmc.LOGWARNING
        )
        common.notify(30700, 30716)
        return
    download_channel_logos()
    common.channel_list_features()
    epg.set_iptv_client_settings()
    common.clean_user_settings()
    common.notify(30500, 30412)


# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f"Addon.OpenSettings({common.Addon_ID})")


# Launch the EPG window
def launch_epg():
    if epg.pvr_refreshing:
        common.notify(30420, 30407)
        return
    xbmc.executebuiltin("ActivateWindow(TVGuide,pvr://channels/tv)")


# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin("ActivateWindow(pvrsettings)")


# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get("mode")

    actions = {
        "-1": categories_list,
        "1": lambda: (first_run(), sys.exit()),
        "2": open_settings,
        "3": lambda: (epg.open_iptv_client_settings(), sys.exit()),
        "4": lambda: (
            common.make_iptv_files(),
            common.notify(30805, 30413),
            sys.exit(),
        ),
        "5": lambda: (
            epg.set_iptv_client_settings(),
            common.notify(30414, 30415),
            sys.exit(),
        ),
        "6": lambda: (epg.fetch_and_build_epg(), common.notify(30407, 30408)),
        "7": launch_epg,
        "8": lambda: (open_pvrsettings(), sys.exit()),
        "9": lambda: (common.check_version(), sys.exit()),
        "10": lambda: common.open_window("guide-qr.xml"),
        "11": lambda: common.open_window("register-qr.xml"),
        "12": download_channel_logos,
    }

    if mode in actions:
        actions[mode]()
    else:
        if params:
            xbmc.log(f"Invalid mode: {mode}", xbmc.LOGERROR)
            sys.exit()
        else:
            categories_list()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
