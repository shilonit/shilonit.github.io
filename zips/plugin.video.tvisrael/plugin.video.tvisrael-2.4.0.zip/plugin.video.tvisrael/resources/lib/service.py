# -*- coding: utf-8 -*-
import xbmc, time
import common

monitor = xbmc.Monitor()

def run_scheduler():
    epg_interval = common.Addon.getSettingInt("updateEPGInterval") * 3600
    links_interval = common.Addon.getSettingInt("updateLinksInterval") * 3600

    next_epg = time.time()
    next_links = time.time()

    while not monitor.abortRequested():
        now = time.time()

        if now >= next_epg:
            try:
                common.update_files()
                xbmc.log("Running EPG scheduler", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"Error in EPG scheduler: {e}", xbmc.LOGERROR)
            next_epg = now + epg_interval

        if now >= next_links:
            try:
                common.update_files()
                xbmc.log("Running Links scheduler", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"Error in Links scheduler: {e}", xbmc.LOGERROR)
            next_links = now + links_interval

        xbmc.sleep(1000)

    xbmc.log("Service stopped gracefully", xbmc.LOGINFO)
