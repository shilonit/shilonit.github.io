# -*- coding: utf-8 -*-
import time
import common
import main
from import_xbmc import xbmc


class MyMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        xbmc.log(
            "[service] Check if settings changed to applying changes", xbmc.LOGDEBUG
        )
        try:
            main.make_iptv_files()
        except Exception as e:
            xbmc.log(f"[service] Error applying changes: {e}", xbmc.LOGERROR)


monitor = MyMonitor()

if common.Addon.getSettingBool("version_check_startup"):
    common.check_version(startup=True)


def run_scheduler():
    epg_interval = common.Addon.getSettingInt("update_EPG_interval") * 3600
    next_epg = time.time() + epg_interval
    xbmc.log("[run_scheduler] Service.py started", xbmc.LOGDEBUG)

    while not monitor.abortRequested():
        now = time.time()

        if now >= next_epg:
            try:
                common.update_files()
                xbmc.log("[run_scheduler] update_files executed", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"[run_scheduler] Error in scheduler: {e}", xbmc.LOGERROR)

            next_epg = now + epg_interval

        if monitor.waitForAbort(5):
            break

    xbmc.log("[run_scheduler] Service stopped gracefully", xbmc.LOGINFO)


run_scheduler()
