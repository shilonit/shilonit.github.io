# -*- coding: utf-8 -*-
import collections
import io
import json
import os
import re
import sys
import time
import xml.etree.ElementTree as ET

import requests

from import_xbmc import xbmc, xbmcaddon, xbmcvfs, xbmcgui

import user_agent
import epglist


#########################################################
# Common variables and functions

Addon_ID   = "plugin.video.tvisrael"
Addon_Name = "TV Israel"
Addon      = xbmcaddon.Addon(Addon_ID)
Addon_Ver  = Addon.getAddonInfo("version")
Addon_Path = Addon.getAddonInfo("path")
Addon_Icon = Addon.getAddonInfo("icon")
M3U_Name   = "tvisrael.m3u"
Epg_Name   = "epg.xml.gz"
Xml_Name   = "epg.xml"
user_agent = user_agent.generate_user_agent()

# Define file paths
profile_dir   = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
logos_dir     = xbmcvfs.translatePath(os.path.join(profile_dir, "logos"))
images_dir    = xbmcvfs.translatePath(os.path.join(Addon_Path, "resources", "images"))
m3u_file      = os.path.join(profile_dir, M3U_Name)
xml_file      = os.path.join(profile_dir, Xml_Name)
user_settings = os.path.join(profile_dir, "settings.xml")
app_logo      = os.path.join(images_dir, "tv.jpg")
epg_file      = os.path.join(profile_dir, Epg_Name)
github_base   = "https://raw.githubusercontent.com/shilonit"

##########################################################

# Make sure profile directory exists
if not os.path.exists(profile_dir):
    os.makedirs(profile_dir)

channels_cache = None


def load_channels():
    global channels_cache
    if channels_cache is not None:
        return channels_cache
    try:
        json_path = os.path.join(Addon_Path, "resources", "channel_list.json")
        with open(json_path, "r", encoding="utf-8") as f:
            channels_cache = json.load(f)
        return channels_cache
    except Exception as e:
        xbmc.log(f"[main] Failed loading channel_list.json: {e}", xbmc.LOGERROR)
        channels_cache = []
        return channels_cache


# Utility function to safely get handle from arguments
def get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


# Get Addon_Icon full path
def get_addon_icon(Addon_Icon):
    return os.path.join(images_dir, Addon_Icon)


# Check if an addon is installed
def is_addon_installed(addonid):
    return xbmc.getCondVisibility(f"System.HasAddon({addonid})")


# Install addon
def install_addon(addonid):
    xbmc.executebuiltin(f"InstallAddon({addonid})")


# Check if addon is enabled
def is_addon_enabled(addonid):
    try:
        json_request = (
            f'{{"jsonrpc":"2.0",'
            f'"method":"Addons.GetAddonDetails",'
            f'"params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'
        )
        response = json.loads(xbmc.executeJSONRPC(json_request))

        return response["result"]["addon"]["enabled"]
    except json.JSONDecodeError:
        return False


# Get localized string
def get_locale_string(id):
    return Addon.getLocalizedString(id)


# Get label color
def get_label_color(text, key_color=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(key_color)
    if bold:
        text = f"[B]{text}[/B]"
    return text if color == "none" else f"[COLOR {color}]{text}[/COLOR]"


# Read and return settings from addon
def get_addon_setting(key):
    return Addon.getSetting(key)


# Read a list from a file
def read_list(fileName):
    try:
        with io.open(fileName, "r", encoding="utf-8") as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except Exception as ex:
        xbmc.log(str(ex), 3)
        return []


# Escape XML special characters
def escape_xml(text):
    if isinstance(text, bytes):
        text = text.decode("utf-8")
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


# Check if file is older than a given threshold
def is_file_old(filename, deltaInSec=10800):
    last_update = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - last_update) > deltaInSec


# Get integer setting, defaulting if necessary
def get_int_setting(k, v=0):
    setting = Addon.getSetting(k)
    if not setting or not setting.isdigit():

        xbmc.log(f"[get_int_setting] Invalid setting detected for key '{k}', defaulting to {v}", xbmc.LOGWARNING)
        Addon.setSetting(k, str(v))
        return v
    return int(setting)


# Get text content from a file
def get_text_file(filename):
    if os.path.isfile(filename):
        with io.open(filename, "r", encoding="utf-8") as f:
            return f.read()
    return ""


def clean_user_settings():
    resource_settings_path = xbmcvfs.translatePath(
        os.path.join(Addon_Path, "resources", "settings.xml")
    )

    active_keys = set()
    try:
        tree = ET.parse(resource_settings_path)
        root = tree.getroot()
        for category in root.findall("category"):
            for setting in category.findall("setting"):
                sid = setting.get("id")
                if sid:
                    active_keys.add(sid)
    except Exception as e:
        xbmc.log(f"Error reading resource settings file: {e}", xbmc.LOGERROR)
        return
    try:
        with io.open(user_settings, "r", encoding="utf-8") as f:
            content = f.read()

        pattern = r'<setting id="([^"]+)"[^>]*?(?:>(.*?)</setting>|/>)'
        content = re.sub(
            pattern, lambda m: m.group(0) if m.group(1) in active_keys else "", content
        )

        # Remove empty lines
        cleaned_lines = [line for line in content.splitlines() if line.strip()]
        final_content = "\n".join(cleaned_lines) + "\n"

        with io.open(user_settings, "w", encoding="utf-8") as f:
            f.write(final_content)

        xbmc.log("Unused settings cleaned successfully", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"Error cleaning user settings: {e}", xbmc.LOGERROR)


# Check if the links file is old and needs to be updated
def update_files():
    # Convert hours to seconds
    epg_delta_sec = Addon.getSettingInt("update_EPG_interval") * 3600
    if is_file_old(epg_file, epg_delta_sec):
        xbmc.log("[update_files] Updating EPG file", xbmc.LOGDEBUG)
        try:
            epglist.fetch_and_build_epg()
        except Exception as e:
            xbmc.log(f"Failed to update EPG file: {e}", xbmc.LOGERROR)



def notify(title_id: int, message_id: int, duration: int = 2500, icon: str = None) -> None:
    title = get_locale_string(title_id)
    message = get_locale_string(message_id)
    # app_logo default
    if icon is None:
        icon = app_logo
    xbmc.executebuiltin(f'Notification({title}, {message}, {duration}, "{icon}")')


# Compare two version strings
def compare_versions(v1, v2):
    parts1 = list(map(int, v1.split(".")))
    parts2 = list(map(int, v2.split(".")))
    return parts1 > parts2


# Check for updates and notify if available
def check_version(startup=False):
    url = f"{github_base}/shilonit.github.io/master/addons.xml"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:

        xbmc.log(f"[check_version] Error fetching addons.xml: {e} (URL: {url})", xbmc.LOGERROR)
        return

    pattern = rf'<addon id="{Addon_ID}".*?version="([\d\.]+)"'
    match = re.search(pattern, response.text)
    if not match:
        xbmc.log(f"[check_version] Failed to find version in addons.xml", xbmc.LOGERROR)
        return

    remote_version = match.group(1)
    if compare_versions(remote_version, Addon_Ver):
        notify(30703, 30712)
        xbmc.executebuiltin("UpdateAddonRepos()")
        return

    xbmc.log(f"[check_version] No update available. startup={startup}", xbmc.LOGDEBUG)

    # If the version is up-to-date and NOT in startup mode, notify the user
    if not startup:
        notify(30702, 30713)


def open_window(xml_file):
    dialog = xbmcgui.WindowXMLDialog(xml_file, Addon_Path)
    dialog.doModal()
    del dialog
