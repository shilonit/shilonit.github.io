# -*- coding: utf-8 -*-
import base64, json, re
from typing import Optional, Tuple, Dict
from urllib.parse import urlparse, quote

import requests
from bs4 import BeautifulSoup

import common
import channels
from import_xbmc import xbmc

# Globals
BASE_URL = "https://daddylive.sx"
TOP_URL = "https://topembed.pw/"
TE_URL = "https://1.zhdcdn.zip"

channels_list = channels.Tvs

session = requests.Session()
session.headers.update({"User-Agent": common.user_agent})

SRV_INLINE_HEADERS = {"ddy", "ap2", "top", "te"}


# Config helpers
def get_value(key: str) -> Optional[str]:
    try:
        with open(common.links_path, "r", encoding="utf-8") as f:
            return json.load(f).get(key)
    except Exception as e:
        xbmc.log(f"[get_value] Error reading {key}: {e}", xbmc.LOGERROR)
        return None


def get_url(key: str) -> str:
    global BASE_URL, TOP_URL, TE_URL
    m = {"base_url": "BASE_URL", "top_url": "TOP_URL", "te_url": "TE_URL"}
    if key in m:
        val = get_value(key)
        if val:
            globals()[m[key]] = val
        return globals()[m[key]]
    return ""


# HTTP helpers
def http_get(
    url: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    allow_redirects: bool = False,
    timeout: int = 15,
    retries: int = 3,
    delay_ms: int = 1000,
) -> Optional[requests.Response]:
    for attempt in range(1, retries + 1):
        try:
            r = session.get(
                url,
                headers=headers or {},
                timeout=timeout,
                allow_redirects=allow_redirects,
            )
            if 400 <= r.status_code:
                r.raise_for_status()
            return r
        except Exception as e:
            xbmc.log(
                f"[http_get] {attempt}/{retries} failed for {url} hdrs={headers}: {e}",
                xbmc.LOGERROR,
            )
            xbmc.sleep(delay_ms)
    xbmc.log(f"[http_get] all {retries} attempts failed for {url}", xbmc.LOGERROR)
    return None


def make_same_origin_headers(origin: str) -> Dict[str, str]:
    o = origin.rstrip("/")
    return {"Origin": o, "Referer": o + "/", "User-Agent": common.user_agent}


# Shared regex helpers
def assign(name: str) -> re.Pattern:
    return re.compile(
        rf"(?:^|[;\s])(?:var|let|const)\s+{name}\s*=\s*(['\"])(?P<val>.*?)\1\s*;?",
        re.IGNORECASE | re.DOTALL,
    )


SCRIPT_BLOCKS_RE = re.compile(r"<script[^>]*>(.*?)</script>", re.DOTALL | re.IGNORECASE)
EMBED_BASE_RE = re.compile(
    r"""["'](https?://[^"' ]+/embed(?:2|4)\.php)["']""", re.IGNORECASE
)
EMBED_FALLBK_RE = re.compile(r"""https?://[^"' ]+/embed(?:2|4)\.php""", re.IGNORECASE)


def extract_first(p: re.Pattern, text: str, name: str) -> str:
    m = p.search(text)
    if not m:
        raise RuntimeError(f"Missing '{name}' in the HTML/JS (pattern not found).")
    return m.groupdict().get("val") or m.group(1)


def extract_embed_base(html: str) -> str:
    m = EMBED_BASE_RE.search(html)
    if m:
        return m.group(1)
    m2 = EMBED_FALLBK_RE.search(html)
    if m2:
        return m2.group(0)
    raise RuntimeError("Missing embed base URL (embed2.php/embed4.php) in the HTML/JS.")


# DDY/AP/TOP
def build_iframe_url(base_iframe_url: str, srv: str, channel_id: str) -> Optional[str]:
    if not base_iframe_url:
        return None
    base_iframe_url = base_iframe_url.rstrip("/")

    if srv in ("ddy", "ap2"):
        path = "premiumtv/daddyhd.php" if srv == "ddy" else "maxsport.php"
        return f"{base_iframe_url}/{path}?id={channel_id}"
    elif srv == "top":
        return f"{get_url('top_url')}/channel/YesSport{channel_id}[Israel]"
    elif srv == "te":
        return f"{get_url('te_url')}/daddy.php?a={channel_id}"
    return None


def extract_auth_data(page_content: str) -> dict:
    ck = re.search(r'const\s+CHANNEL_KEY\s*=\s*"([^"]+)"', page_content)
    channel_key = ck.group(1) if ck else None
    xjz = re.search(r'const\s+XJZ\s*=\s*"([^"]+)"', page_content)
    if not xjz:
        return {}
    try:
        decoded_json = base64.b64decode(xjz.group(1)).decode()
        parts = json.loads(decoded_json)
        for k, v in list(parts.items()):
            try:
                val = base64.b64decode(v).decode()
                # Temp fix for DaddyLive change
                if k == "b_script" and val == "a.php":
                    val = "auth.php"
                parts[k] = val
            except Exception:
                pass
        return {
            "channel_key": channel_key,
            "auth_ts": parts.get("b_ts"),
            "auth_rnd": parts.get("b_rnd"),
            "auth_sig": parts.get("b_sig"),
            "auth_url": (parts.get("b_host") or "") + (parts.get("b_script") or ""),
        }
    except Exception as e:
        xbmc.log(f"[extract_auth_data] {e}", xbmc.LOGERROR)
        return {}


def authenticate(
    channel_key,
    auth_ts,
    auth_rnd,
    auth_sig,
    auth_url,
    ddy_final,
    headers: Optional[dict] = None,
) -> bool:
    if not auth_url:
        xbmc.log("[authenticate] missing auth_url", xbmc.LOGERROR)
        return False
    url = f"{auth_url}?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    hdrs = dict(headers or {})
    hdrs["Host"] = ddy_final or ""
    resp = http_get(url, headers=hdrs)
    if not resp:
        return False
    try:
        return resp.json().get("status") == "ok"
    except Exception:
        xbmc.log("authenticate: invalid JSON", xbmc.LOGERROR)
        return False


def get_server_key(channel_key, origin) -> Optional[str]:
    try:
        r = session.get(
            f"{origin}/server_lookup.php?channel_id={channel_key}", timeout=5
        )
        return r.json().get("server_key")
    except Exception as e:
        xbmc.log(f"get_server_key: {e}", xbmc.LOGERROR)
        return None


def build_m3u8_url(channel_key, server_key, dynamic_domain) -> str:
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"


def resolve_ddy_like(channel_id: str, srv: str) -> Tuple[Optional[str], Optional[dict]]:
    base_iframe_url = get_value("iframe_url")
    iframe_url = build_iframe_url(base_iframe_url, srv, channel_id)
    ddy_final = get_value("ddy_final")
    if not iframe_url:
        xbmc.log("[resolve_ddy_like] failed to build iframe_url", xbmc.LOGERROR)
        return None, {}

    # Fetch iframe page ONCE
    resp = http_get(iframe_url)
    if not resp:
        xbmc.log("[resolve_ddy_like] failed to fetch iframe content", xbmc.LOGERROR)
        return None, {}

    page = resp.text or ""
    auth = extract_auth_data(page)
    channel_key = auth.get("channel_key") or (
        "premium" + str(channel_id) if srv == "ddy" else None
    )
    if not channel_key:
        xbmc.log("[resolve_ddy_like] missing channel_key", xbmc.LOGERROR)
        return None, {}

    origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
    if all(auth.get(k) for k in ("auth_ts", "auth_rnd", "auth_sig", "auth_url")):
        hdrs = make_same_origin_headers(origin)
        if not authenticate(
            channel_key,
            auth["auth_ts"],
            auth["auth_rnd"],
            auth["auth_sig"],
            auth["auth_url"],
            ddy_final,
            headers=hdrs,
        ):
            xbmc.log("[resolve_ddy_like] auth failed", xbmc.LOGERROR)
            return None, {}

    server_key = get_server_key(channel_key, origin)
    if not server_key:
        xbmc.log("[resolve_ddy_like] server_key not found", xbmc.LOGERROR)
        return None, {}

    m3u8 = build_m3u8_url(channel_key, server_key, ddy_final)
    return m3u8, make_same_origin_headers(origin)


def get_m3u8_ddy(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    ch = next((c for c in channels_list if c["id"] == channel_id), None)
    srv = ch.get("srv", "ddy") if ch else "ddy"
    return resolve_ddy_like(channel_id, srv)


# AP
def normalize_stream_id(stream_id: str) -> str:
    if not stream_id:
        return ""
    m = re.match(r"^(SPORT\d+)([A-Z]+)?IL$", stream_id.upper())
    return m.group(1) + m.group(2) if m and m.group(2) else stream_id


def extract_m3u8_url(stream_id: str) -> Tuple[Optional[str], dict]:
    AP_URL = get_value("ap_url")
    hdrs = {"User-Agent": common.user_agent, "Referer": AP_URL}
    sid = normalize_stream_id(stream_id)

    r1_text = http_get(f"{AP_URL}/{stream_id.lower()}.php", headers=hdrs)
    if not r1_text:
        xbmc.log("[extract_m3u8_url] first page fetch failed", xbmc.LOGERROR)
        return None, hdrs
    first = BeautifulSoup(r1_text.text, "html.parser").find(
        "iframe", src=re.compile(f"stream={sid}", re.I)
    )
    if not first or not first.has_attr("src"):
        xbmc.log("[extract_m3u8_url] first iframe not found", xbmc.LOGERROR)
        return None, hdrs

    url2 = first["src"] or ""
    if url2.startswith("//"):
        url2 = "https:" + url2

    r2 = http_get(url2, headers=hdrs)
    if not r2:
        xbmc.log("[extract_m3u8_url] second page fetch failed", xbmc.LOGERROR)
        return None, hdrs
    second_iframe = BeautifulSoup(r2.text, "html.parser").find(
        "iframe", src=re.compile(f"{sid}/embed", re.I)
    )
    if not second_iframe or not second_iframe.has_attr("src"):
        xbmc.log("[extract_m3u8_url] second iframe not found", xbmc.LOGERROR)
        return None, hdrs

    second = second_iframe["src"]
    dom = urlparse(second)
    m = re.search(r"token=([A-Za-z0-9\-]+)", second)
    if not m:
        xbmc.log("[extract_m3u8_url] token not found", xbmc.LOGERROR)
        return None, hdrs
    token = m.group(1)
    final = f"{dom.scheme}://{dom.hostname}/{sid}/index.fmp4.m3u8?token={token}"
    return final, hdrs


# TE
ID_RE = assign("id")
SESSION_RE = assign("sessionId")
IP_RE = assign("ip")
UA_RE = assign("useragent")


def build_embed_url(
    base_url: str, id_: str, session_id: str, ip: str, useragent_raw: str
) -> str:
    a_q, s_q, ip_q = quote(id_, safe=""), quote(session_id, safe=""), quote(ip, safe="")
    ua = useragent_raw
    looks_encoded = any(x in ua for x in ("%25", "%2F", "%20", "+", "%28"))
    if not looks_encoded:
        ua = quote(ua, safe="")
    return f"{base_url}?a={a_q}&s={s_q}&ip={ip_q}&useragent={ua}"


def decode_crf_input(html: str) -> str:
    el = BeautifulSoup(html, "html.parser").find(id="crf__")
    if not el or not el.has_attr("value"):
        raise RuntimeError("Missing <input id='crf__' value='...'>")
    return base64.b64decode(el["value"].strip()).decode("utf-8", errors="strict")


def te_resolve_final_url(a_value: str) -> Optional[str]:
    te_root = (get_url("te_url") or TE_URL).rstrip("/")
    daddy_url = f"{te_root}/daddy.php?a={a_value}"
    try:
        dresp = http_get(daddy_url, allow_redirects=False)
        if not dresp:
            return None
        html = dresp.text or ""
        target = None
        for s in SCRIPT_BLOCKS_RE.findall(html):
            if (
                "sessionId" in s
                and "useragent" in s
                and ("embed2.php" in s or "embed4.php" in s or "embed" in s)
            ):
                target = s
                break
        target = target or html
        id_ = extract_first(ID_RE, target, "id")
        session_id = extract_first(SESSION_RE, target, "sessionId")
        ip = extract_first(IP_RE, target, "ip")
        useragent = extract_first(UA_RE, target, "useragent")
        embed_base = extract_embed_base(target)
        embed_url = build_embed_url(embed_base, id_, session_id, ip, useragent)

        hdrs = make_same_origin_headers(te_root)
        eresp = http_get(embed_url, headers=hdrs, allow_redirects=False)
        body = (eresp.text if eresp else "") or ""
        if not body.strip():
            return None

        return decode_crf_input(body)

    except Exception as e:
        xbmc.log(f"[te_resolve_final_url] a={a_value} error: {e}", xbmc.LOGERROR)
        return None


def get_m3u8_te(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    te_root = (get_url("te_url") or TE_URL).rstrip("/")
    final_url = te_resolve_final_url(channel_id)
    if not final_url:
        xbmc.log("[get_m3u8_te] Could not resolve final URL", xbmc.LOGERROR)
        return None, {}
    return final_url, make_same_origin_headers(te_root)


#  Common entry point
def url_origin(channel_nid) -> Tuple[Optional[str], Optional[dict]]:
    ch = next((x for x in channels_list if x["nid"] == channel_nid), None)
    if not ch:
        xbmc.log(f"url_origin: nid {channel_nid} not found", xbmc.LOGERROR)
        return None, None

    channel_id, srv = ch["id"], ch["srv"].lower()
    xbmc.log(f"url_origin: id={channel_id}, srv={srv}", xbmc.LOGDEBUG)

    if srv in ("ddy", "ap2", "top"):
        return resolve_ddy_like(channel_id, srv)

    if srv == "ap":
        return extract_m3u8_url(channel_id)

    if srv == "te":
        return get_m3u8_te(channel_id)

    xbmc.log(f"url_origin: unsupported srv {srv}", xbmc.LOGERROR)
    return None, None
