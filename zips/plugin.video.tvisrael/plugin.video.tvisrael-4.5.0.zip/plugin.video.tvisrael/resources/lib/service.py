import os
import time

import common
import epglist as epg
from import_xbmc import xbmc

EPG_RETRY_DELAY = 600  # seconds


class MyMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.epg_interval = read_epg_interval()

    def onSettingsChanged(self):
        xbmc.log(
            "[service] Check if settings changed to applying changes", xbmc.LOGDEBUG
        )
        self.epg_interval = read_epg_interval()
        try:
            common.make_iptv_files(show_progress=True)
        except (OSError, RuntimeError, TypeError, ValueError) as e:
            xbmc.log(f"[service] Error applying changes: {e}", xbmc.LOGERROR)


# EPG refresh interval from the settings, in seconds.
def read_epg_interval():
    return common.Addon.getSettingInt("update_EPG_interval") * 3600


# When the EPG file is due: its last change + the interval
def next_epg_update(interval):
    try:
        return os.path.getmtime(common.epg_file) + interval
    except OSError:
        return 0  # no file - now


monitor = MyMonitor()

if common.Addon.getSettingBool("version_check_startup"):
    common.check_version(startup=True)


def run_scheduler():
    xbmc.log("[run_scheduler] Service.py started", xbmc.LOGDEBUG)
    if not common.channel_list_features(restart=False):
        common.download_channel_logos(silent=True, max_age=common.LOGOS_MAX_AGE)
    retry_after = 0

    while not monitor.abortRequested():
        now = time.time()

        if now >= next_epg_update(monitor.epg_interval) and now >= retry_after:
            try:
                common.update_epg_files()
            except (OSError, RuntimeError, TypeError, ValueError) as e:
                xbmc.log(f"[run_scheduler] Error in scheduler: {e}", xbmc.LOGERROR)
            retry_after = now + EPG_RETRY_DELAY

        # A restart requested during the startup grace period runs once allowed
        try:
            epg.run_pending_restart()
        except (OSError, RuntimeError, TypeError, ValueError) as e:
            xbmc.log(f"[run_scheduler] Pending restart failed: {e}", xbmc.LOGERROR)

        if monitor.waitForAbort(5):
            break

    xbmc.log("[run_scheduler] Service stopped gracefully", xbmc.LOGINFO)


run_scheduler()
