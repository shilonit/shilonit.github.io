import bisect
import glob
import gzip
import itertools
import json
import os
import re
import time
import zlib
from collections import defaultdict
from datetime import datetime, timezone
from xml.etree import ElementTree as ET

import common
import requests
from import_xbmc import xbmc, xbmcaddon, xbmcgui, xbmcvfs


def get_af_base():
    server_choice = common.Addon.getSettingInt("server")
    servers = {
        0: "bethoven",
        1: "chopin",
        2: "tchaikovsky",
    }
    return f"http://{servers.get(server_choice, servers[0])}.af-stream.com:8080"


AF_EPG_URL = "http://af-play.com/xmltv.xml.gz"
EPG_PAST_DAYS = 7
IPTV_ADDON_ID = "pvr.iptvsimple"
IPTV_NAME = "IPTV Simple Client"
SESSION_PROP = "tvisrael.session_start"
RESTART_STARTUP_GRACE = 60


# Records when this Kodi session started
def mark_session_start():
    try:
        home = xbmcgui.Window(10000)
        if not home.getProperty(SESSION_PROP):
            home.setProperty(SESSION_PROP, str(time.time()))
    except (AttributeError, RuntimeError):
        pass


mark_session_start()


# Opens an XMLTV file (plain or gzip) for streaming reads.
def open_xmltv(path):
    with open(path, "rb") as f:
        magic = f.read(2)
    return gzip.open(path, "rb") if magic == b"\x1f\x8b" else open(path, "rb")


# Downloads an XMLTV file straight to disk.
def download_xmltv(url, dest, timeout=60):
    try:
        with requests.get(
            url,
            headers={"User-Agent": common.user_agent},
            timeout=timeout,
            stream=True,
        ) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                f.writelines(r.iter_content(chunk_size=256 * 1024))
        with open_xmltv(dest) as f:
            head = f.read(100)
        start = head.lstrip(b"\xef\xbb\xbf \t\r\n").lower()  # BOM / whitespace
        if not start.startswith(b"<") or start.startswith(
            (b"<html", b"<!doctype html")
        ):
            xbmc.log(
                f"[EPG] Invalid XML from {url}, first bytes={head[:100]!r}",
                xbmc.LOGERROR,
            )
            remove_file(dest)
            return False
        xbmc.log(
            f"[EPG] Downloaded {url} ({os.path.getsize(dest)} bytes)", xbmc.LOGDEBUG
        )
        return True
    except (requests.RequestException, OSError, EOFError, zlib.error, ValueError) as e:
        xbmc.log(f"[EPG] Failed downloading {url}: {e}", xbmc.LOGERROR)
        remove_file(dest)
        return False


def remove_file(path):
    try:
        os.remove(path)
    except OSError:
        pass


# Converts an XMLTV time to a Unix timestamp.
def parse_xmltv_time(value):
    if not value:
        return None
    value = value.strip()
    try:
        return datetime.strptime(value, "%Y%m%d%H%M%S %z").timestamp()
    except ValueError:
        pass
    try:
        return (
            datetime.strptime(value[:14], "%Y%m%d%H%M%S")
            .replace(tzinfo=timezone.utc)
            .timestamp()
        )
    except ValueError:
        return None


# Streams through an XMLTV document and keeps only channels/programmes
# whose channel id passes keep(). Reads the file as a stream (plain or gzip).
def parse_xmltv(path, keep):
    channels, programmes = {}, []
    root = None
    with open_xmltv(path) as f:
        for event, elem in ET.iterparse(f, events=("start", "end")):
            if event == "start":
                if root is None:
                    root = elem
                continue
            if elem.tag == "channel":
                if keep(elem.get("id")):
                    channels[elem.get("id")] = elem
            elif elem.tag == "programme":
                if keep(elem.get("channel")):
                    programmes.append(elem)
            else:
                continue
            try:
                root.remove(elem)  # release the parsed element from the tree
            except ValueError:
                pass
    return channels, programmes


def strip_lang(prog):
    for elem in prog.findall("title") + prog.findall("desc"):
        elem.attrib.pop("lang", None)


# Per-channel index of accepted programmes for fast overlap checks:
# sorted starts + running maximum of ends (handles overlapping source data).
def build_overlap_index(accepted):
    index = {}
    for tvgid, items in accepted.items():
        ranges = sorted((s, e) for s, e, _ in items)
        index[tvgid] = (
            [r[0] for r in ranges],
            list(itertools.accumulate((r[1] for r in ranges), max)),
        )
    return index


# True if [start, stop) overlaps any range in the channel index.
def overlaps(start, stop, channel_index):
    if not channel_index:
        return False
    starts, max_ends = channel_index
    i = bisect.bisect_left(starts, stop)  # ranges[:i] start before our stop
    return i > 0 and max_ends[i - 1] > start


# Reads programmes from an XMLTV file as (tvgid, start, stop, element).
# to_tvgid maps the source channel id to our tvgid (None = skip);
# keep(start, stop) filters by time.
def read_programmes(path, to_tvgid, keep):
    channels, progs = parse_xmltv(path, lambda cid: to_tvgid(cid) is not None)
    items = []
    for p in progs:
        start = parse_xmltv_time(p.get("start"))
        if start is None:
            continue
        stop = parse_xmltv_time(p.get("stop")) or start + 1
        if not keep(start, stop):
            continue
        tvgid = to_tvgid(p.get("channel"))
        p.set("channel", tvgid)
        items.append((tvgid, start, stop, p))
    return channels, items


# Merges EPG layers by priority. A programme is added only if it doesn't overlap
# a programme from a higher-priority layer on the same channel:
#   1. previous_path  - our existing file, finished programmes only (past data is kept)
#   2. primary_path   - common.github_epg (keyed by tvgid)
#   3. secondary_path - AF EPG (keyed by nid)
# All sources are file paths (plain or gzip XMLTV), read as streams.
# Programmes that ended more than EPG_PAST_DAYS ago are dropped.
def merge_epg(primary_path, secondary_path, channels, previous_path=None):
    nid_to_tvgid = {
        ch["nid"]: ch["tvgid"] for ch in channels if ch.get("nid") and ch.get("tvgid")
    }
    tvgids = [ch["tvgid"] for ch in channels if ch.get("tvgid")]
    tvgid_set = set(tvgids)
    now = time.time()
    min_ts = now - EPG_PAST_DAYS * 86400

    def own_id(cid):
        return cid if cid in tvgid_set else None

    def in_window(start, stop):
        return stop >= min_ts

    def finished(start, stop):
        return min_ts <= stop <= now

    layers = []
    channel_elems = {}
    if previous_path:
        try:
            chs, items = read_programmes(previous_path, own_id, finished)
            layers.append(("previous", items))
            channel_elems.update(chs)
        except (ET.ParseError, OSError, EOFError, zlib.error) as e:
            # a corrupt existing file must not block updates
            xbmc.log(f"[EPG] Ignoring invalid existing EPG: {e}", xbmc.LOGWARNING)
    if primary_path:
        chs, items = read_programmes(primary_path, own_id, in_window)
        layers.append(("primary", items))
        channel_elems.update(chs)  # primary channel info wins
    if secondary_path:
        _, items = read_programmes(secondary_path, nid_to_tvgid.get, in_window)
        for item in items:
            strip_lang(item[3])
        layers.append(("af", items))

    accepted = defaultdict(list)  # tvgid -> [(start, stop, element)]
    stats = []
    for name, items in layers:
        index = build_overlap_index(accepted)
        added = dropped = 0
        for tvgid, start, stop, p in items:
            if overlaps(start, stop, index.get(tvgid)):
                dropped += 1
                continue
            accepted[tvgid].append((start, stop, p))
            added += 1
        stats.append(f"{name}={added} (overridden {dropped})")

    root = ET.Element("tv", {"generator-info-name": common.Addon_ID})
    for ch in channels:
        tvgid = ch.get("tvgid")
        if not tvgid:
            continue
        ch_elem = channel_elems.get(tvgid)
        if ch_elem is None:
            ch_elem = ET.Element("channel", {"id": tvgid})
            ET.SubElement(ch_elem, "display-name").text = (
                common.get_local_lang_name(ch) or tvgid
            )
        root.append(ch_elem)

    total = 0
    for tvgid in tvgids:
        for _, _, p in sorted(accepted.get(tvgid, []), key=lambda x: x[0]):
            root.append(p)
            total += 1

    xbmc.log(f"[EPG] Merged {total} programmes: {', '.join(stats)}", xbmc.LOGINFO)
    return root, total


# Small non-blocking progress bar in the top corner (DialogProgressBG), shared by
# the EPG build and the PVR restart so one action shows one bar. Never shown while
# something plays. span(lo, hi) maps the next step's 0-100 into a part of the bar.
class BgProgress:
    def __init__(self, enabled=True):
        self.dialog = None
        self.lo, self.hi = 0, 100
        if not enabled or xbmc.Player().isPlaying():
            return
        try:
            self.dialog = xbmcgui.DialogProgressBG()
            self.dialog.create(
                common.get_locale_string(30403), common.get_locale_string(30423)
            )
        except (AttributeError, RuntimeError):
            self.dialog = None

    def span(self, lo, hi):
        self.lo, self.hi = lo, hi

    def update(self, percent, message=None):
        if not self.dialog:
            return
        value = int(self.lo + (self.hi - self.lo) * percent / 100)
        try:
            if message:
                self.dialog.update(value, message=message)
            else:
                self.dialog.update(value)
        except (AttributeError, RuntimeError):
            pass

    def close(self):
        if self.dialog:
            try:
                self.dialog.close()
            except (AttributeError, RuntimeError):
                pass
            self.dialog = None


# Fetches both EPG sources, merges them and saves the result to common.epg_file.
# The refresh interval is checked by the caller (common.update_epg_files);
# force=True marks a manual refresh from settings.
def fetch_and_build_epg(force=False, notify=None, progress=None):
    if common.get_addon_setting("use_IPTV") != "true":
        return
    if notify is None:
        notify = force
    channels = common.get_visible_channels()
    if not channels:
        return

    own_progress = progress is None
    if own_progress:
        progress = BgProgress(enabled=notify)
        if notify:
            progress.span(0, 60)  # the restart fills the rest

    def step(percent):
        progress.update(percent)

    started = time.time()
    saved = False
    primary_file = common.epg_file + ".primary.tmp"
    af_file = common.epg_file + ".af.tmp"
    tmp_file = common.epg_file + ".tmp"
    try:
        primary_path = (
            primary_file if download_xmltv(common.github_epg, primary_file) else None
        )
        step(20)
        secondary_path = (
            af_file if download_xmltv(AF_EPG_URL, af_file, timeout=90) else None
        )
        step(50)
        downloaded = time.time()
        if not primary_path and not secondary_path:
            xbmc.log(
                "[EPG] Both EPG sources failed - keeping the existing file",
                xbmc.LOGERROR,
            )
            return

        # The existing file keeps priority for past programmes
        previous_path = common.epg_file if os.path.isfile(common.epg_file) else None

        try:
            root, total = merge_epg(
                primary_path, secondary_path, channels, previous_path
            )
        except (
            AttributeError,
            KeyError,
            TypeError,
            ValueError,
            ET.ParseError,
            OSError,
            EOFError,
            zlib.error,
        ) as e:
            xbmc.log(
                f"[EPG] Failed merging EPG due to invalid data: {e}", xbmc.LOGERROR
            )
            return
        step(80)
        merged = time.time()
        if total == 0:
            xbmc.log(
                "[EPG] Merged EPG is empty - keeping the existing file",
                xbmc.LOGWARNING,
            )
            return

        # Write to a temp file and swap atomically, so IPTV Simple never reads a half-written file
        try:
            ET.ElementTree(root).write(tmp_file, encoding="utf-8", xml_declaration=True)
            os.replace(tmp_file, common.epg_file)
            saved = True
            step(100)
            xbmc.log(
                f"[EPG] EPG XML saved in {time.time() - started:.1f}s "
                f"(download {downloaded - started:.1f}s, merge {merged - downloaded:.1f}s, "
                f"write {time.time() - merged:.1f}s)",
                xbmc.LOGINFO,
            )
        except (OSError, TypeError, ValueError) as e:
            xbmc.log(f"[EPG] Failed writing EPG XML: {e}", xbmc.LOGERROR)
    finally:
        for path in (primary_file, af_file, tmp_file):
            remove_file(path)

    if own_progress:
        if saved and notify:
            # Manual refresh - load the new guide now, on the same progress bar;
            # the restart closes it and reports the result
            progress.span(60, 100)
            restart_pvr_client(progress=progress)
        else:
            progress.close()


# Lock that prevents simultaneous PVR restarts.
# The value is the start time, so a lock left by a crashed call expires on its own.
REFRESH_PROP = "tvisrael.pvr_refreshing"
REFRESH_LOCK_TIMEOUT = 60


def is_pvr_refreshing():
    try:
        started = float(xbmcgui.Window(10000).getProperty(REFRESH_PROP) or 0)
    except (AttributeError, RuntimeError, ValueError):
        return False
    return started > 0 and time.time() - started < REFRESH_LOCK_TIMEOUT


def acquire_refresh_lock():
    if is_pvr_refreshing():
        return False
    try:
        xbmcgui.Window(10000).setProperty(REFRESH_PROP, str(time.time()))
    except (AttributeError, RuntimeError):
        pass
    return True


def release_refresh_lock():
    try:
        xbmcgui.Window(10000).clearProperty(REFRESH_PROP)
    except (AttributeError, RuntimeError):
        pass


# Seconds since this Kodi session started (None if unknown).
def session_age():
    try:
        started = float(xbmcgui.Window(10000).getProperty(SESSION_PROP))
    except (AttributeError, RuntimeError, ValueError):
        return None
    return time.time() - started


# Returns why a restart should be skipped, or None if it is safe.
# IPTV Manager and IPTV Merge also skip the restart while a PVR stream plays.
def restart_blocked_reason():
    if is_pvr_playing():
        return "a PVR stream is playing"
    age = session_age()
    if age is not None and age < RESTART_STARTUP_GRACE:
        return f"Kodi started only {age:.0f}s ago (PVR is still connecting)"
    return None


def is_pvr_playing():
    return xbmc.getCondVisibility(
        "PVR.IsPlayingTv | PVR.IsPlayingRadio | PVR.IsPlayingRecording"
    )


# Pending restart
PENDING_PROP = "tvisrael.pending_restart"
PENDING_RESTART_MAX_AGE = 270


# force=True: restart even if the channels already match
def set_pending_restart(force=False):
    try:
        home = xbmcgui.Window(10000)
        current = home.getProperty(PENDING_PROP)
        requested = current.split(":")[0] if current else str(time.time())
        force = force or current.endswith(":force")  # keep the first request time
        home.setProperty(PENDING_PROP, requested + (":force" if force else ""))
    except (AttributeError, RuntimeError):
        pass


def clear_pending_restart():
    try:
        xbmcgui.Window(10000).clearProperty(PENDING_PROP)
    except (AttributeError, RuntimeError):
        pass


# Called by the service loop: runs a pending restart once it is allowed.
def run_pending_restart():
    try:
        value = xbmcgui.Window(10000).getProperty(PENDING_PROP)
        requested = float(value.split(":")[0] or 0) if value else 0
    except (AttributeError, RuntimeError, ValueError):
        return
    force = value.endswith(":force")
    if not requested:
        return
    age = time.time() - requested
    if age > PENDING_RESTART_MAX_AGE and not force:
        clear_pending_restart()
        xbmc.log(
            f"[pending_restart] Dropped after {age:.0f}s - "
            "IPTV Simple's auto refresh has loaded the changes",
            xbmc.LOGINFO,
        )
        return
    if restart_blocked_reason() or is_pvr_refreshing():
        return
    state, clients = read_pvr_clients()
    if state == "unavailable":
        return
    clear_pending_restart()
    up_to_date = False
    if state == "ok" and clients:
        our_id = find_our_client(clients, all_channel_labels())
        up_to_date = clients.get(our_id) == expected_channel_labels()
    if up_to_date and not force:
        xbmc.log(
            "[pending_restart] Channels already up to date - restart not needed",
            xbmc.LOGINFO,
        )
        return
    xbmc.log(
        f"[pending_restart] Running restart requested {age:.0f}s ago", xbmc.LOGINFO
    )
    restart_pvr_client()


JSONRPC_INVALID_PARAMS = -32602  # e.g. a property this Kodi version doesn't know


# Sends a JSON-RPC request. Returns (result, error_code)
def json_rpc_call(method, params=None):
    try:
        response = json.loads(
            xbmc.executeJSONRPC(
                json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "method": method,
                        "params": params or {},
                        "id": 1,
                    }
                )
            )
        )
    except (TypeError, ValueError, RuntimeError):
        return None, 0
    if "error" in response:
        error = response["error"]
        xbmc.log(f"[json_rpc] {method} failed: {error}", xbmc.LOGDEBUG)
        return None, error.get("code", 0) if isinstance(error, dict) else 0
    return response.get("result"), None


# Sends a JSON-RPC request and returns its "result" (None on error).
def json_rpc(method, params=None):
    return json_rpc_call(method, params)[0]


# Returns True/False for the add-on's enabled state, or None if unknown.
def addon_enabled_state(addon_id):
    result = json_rpc(
        "Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]}
    )
    try:
        return bool(result["addon"]["enabled"])
    except (KeyError, TypeError):
        return None


# Enables/disables an add-on and waits until Kodi reports the new state.
def set_addon_enabled(addon_id, enabled, timeout=8000, check_interval=250):
    json_rpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": enabled})
    waited = 0
    while waited < timeout:
        if addon_enabled_state(addon_id) == enabled:
            return True
        xbmc.sleep(check_interval)
        waited += check_interval
    return False


# True when the PVR Manager is up and its clients are connected.
def pvr_available():
    result = json_rpc("PVR.GetProperties", {"properties": ["available"]})
    return bool(result and result.get("available"))


# Our channel names exactly as written to the M3U.
def expected_channel_labels():
    return {
        common.get_local_lang_name(ch)
        for ch in common.get_visible_channels()
        if common.get_local_lang_name(ch)
    }


# All channel names this add-on knows (shown and hidden)
def all_channel_labels():
    return {
        common.get_local_lang_name(ch)
        for ch in common.channels_loaded
        if common.get_local_lang_name(ch)
    }


# Reads Kodi's channels grouped by PVR client. Returns (state, clients):
#   ("ok", {clientid: {label, ...}})
def read_pvr_clients():
    if not pvr_available():
        return "unavailable", None
    result, error = json_rpc_call(
        "PVR.GetChannels", {"channelgroupid": "alltv", "properties": ["clientid"]}
    )
    if error == JSONRPC_INVALID_PARAMS:
        return "unsupported", None
    if result is None:
        return "unavailable", None
    clients = defaultdict(set)
    for ch in result.get("channels", []):
        clients[ch.get("clientid")].add(ch.get("label", ""))
    return "ok", clients


# Picks our client: the one whose channels are most purely ours
def find_our_client(clients, ours):
    best, best_score = None, None
    for clientid, labels in clients.items():
        if not labels:
            continue
        common_count = len(labels & ours)
        score = (common_count / len(labels), common_count)
        if best_score is None or score > best_score:
            best, best_score = clientid, score
    return best


# Waits until the PVR is back up with our changes loaded, looking only at our client
def wait_for_channels(
    expected, our_id=None, before=None, timeout=60000, check_interval=1000
):
    added = expected - before if before is not None else None
    removed = before - expected if before is not None else None
    xbmc.log(
        f"[wait_for_channels] Waiting for client {our_id}: {len(expected)} channels "
        f"(added={sorted(added) if added is not None else '?'}, "
        f"removed={sorted(removed) if removed is not None else '?'})",
        xbmc.LOGINFO,
    )
    ours = all_channel_labels()
    waited = 0
    labels = None
    state = None
    while waited < timeout:
        state, clients = read_pvr_clients()
        if state == "unsupported":
            xbmc.log(
                "[wait_for_channels] No clientid support - PVR is up, not verifying channels",
                xbmc.LOGWARNING,
            )
            return True
        if state == "ok" and clients:
            clientid = our_id if our_id in clients else find_our_client(clients, ours)
            labels = clients.get(clientid, set())
            if labels == expected or (
                added is not None
                and (added or removed)
                and added <= labels
                and not removed & labels
            ):
                xbmc.log(
                    f"[wait_for_channels] Success after {waited / 1000:.0f}s - "
                    f"client {clientid} has {len(labels)} channels",
                    xbmc.LOGINFO,
                )
                return True
        xbmc.sleep(check_interval)
        waited += check_interval
    if labels is not None:
        xbmc.log(
            f"[wait_for_channels] Timeout - our client has {len(labels)} channels, "
            f"M3U has {len(expected)}; missing={sorted(expected - labels)[:20]} "
            f"extra={sorted(labels - expected)[:20]}",
            xbmc.LOGWARNING,
        )
    else:
        xbmc.log(
            f"[wait_for_channels] Timeout (last state={state}) - no channels read",
            xbmc.LOGWARNING,
        )
    return False


# Restarts the IPTV Simple Client by disabling and re-enabling it
def restart_pvr_client(show_progress=False, progress=None):
    xbmc.log(
        f"[restart_pvr_client] {IPTV_NAME} Starting (show_progress={show_progress})",
        xbmc.LOGDEBUG,
    )

    if progress is None:
        progress = BgProgress(enabled=False)
        own_bar = show_progress
    else:
        own_bar = False

    reason = restart_blocked_reason()
    if reason:
        progress.close()
    if reason and not is_pvr_playing():
        set_pending_restart()
        xbmc.log(
            f"[restart_pvr_client] Deferring restart - {reason}. "
            "The service will run it when the startup grace period ends.",
            xbmc.LOGINFO,
        )
        return False
    if not reason and not acquire_refresh_lock():
        progress.close()
        set_pending_restart()
        xbmc.log(
            "[restart_pvr_client] Another restart is in progress - "
            "this one is pending and runs right after it",
            xbmc.LOGINFO,
        )
        return False
    if reason:
        xbmc.log(
            f"[restart_pvr_client] Skipping restart - {reason}. "
            "IPTV Simple's auto refresh will apply the changes.",
            xbmc.LOGINFO,
        )
        common.notify(30702, 30420)
        return False

    clear_pending_restart()
    lock_held = True
    ok = False
    try:
        if own_bar:
            progress = BgProgress()
        progress.update(10, common.get_locale_string(30424).format(IPTV=IPTV_NAME))

        expected = expected_channel_labels()
        our_id = before = None
        state, clients = read_pvr_clients()
        if state == "ok" and clients:
            our_id = find_our_client(clients, all_channel_labels())
            before = clients.get(our_id)

        if not set_addon_enabled(IPTV_ADDON_ID, False):
            xbmc.log(f"[restart_pvr_client] {IPTV_NAME} did not stop", xbmc.LOGERROR)
        xbmc.sleep(1000)
        started = set_addon_enabled(IPTV_ADDON_ID, True)
        release_refresh_lock()
        lock_held = False
        if started:
            progress.update(50, common.get_locale_string(30425))
            ok = wait_for_channels(expected, our_id, before)
            progress.update(100)
        else:
            xbmc.log(f"[restart_pvr_client] {IPTV_NAME} did not start", xbmc.LOGERROR)
            set_addon_enabled(IPTV_ADDON_ID, True)

        xbmc.log(
            f"[restart_pvr_client] Finished - channels {'updated' if ok else 'not updated yet'}",
            xbmc.LOGINFO,
        )
        progress.close()
        common.notify(30702, 30421 if ok else 30420)
    finally:
        progress.close()
        if lock_held:
            release_refresh_lock()
    return ok


# Generates the IPTV list in M3U format.
def generate_iptv_list(videos, show_progress=False, restart=True):
    iptv_list = '#EXTM3U catchup-type="shift"\n'
    base_url = f'{get_af_base()}/s/{common.get_addon_setting("user_token")}'
    group = f' group-title="{common.get_locale_string(30300)}"'
    logos = logo_files()

    for video in videos:
        try:
            tvg_id = video.get("tvgid", "")
            if tvg_id:
                logo_filename = logos.get(tvg_id, f"{tvg_id}.png")
                tvg_logo = f"special://userdata/addon_data/{common.Addon_ID}/logos/{logo_filename}"
            else:
                tvg_logo = ""
            view_name = common.get_local_lang_name(video)
            url = f'{base_url}/{video.get("nid", "")}/video.m3u8'
            iptv_list += f'\n#EXTINF:-1 tvg-id="{tvg_id}"{group} tvg-logo="{tvg_logo}" catchup-days="7",{view_name}\n{url}\n'
        except (AttributeError, KeyError, TypeError, ValueError) as ex:
            xbmc.log(
                f'Error processing video {video.get("name", "Unknown")}: {ex}',
                xbmc.LOGERROR,
            )

    # Compare and write the new IPTV list to file if changed
    if not is_list_equal(common.m3u_file, iptv_list):
        xbmc.log(
            "[generate_iptv_list] Channels list changed – applying changes",
            xbmc.LOGDEBUG,
        )
        # Temp file + swap, so IPTV Simple never reads a half-written list
        tmp_path = common.m3u_file + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(iptv_list)
        os.replace(tmp_path, common.m3u_file)
        # A channel was shown again (or added) - rebuild the EPG before the restart
        visible_ids = {v.get("tvgid") for v in videos if v.get("tvgid")}
        missing = visible_ids - epg_channel_ids()
        # One corner progress bar for the whole change (EPG rebuild + restart)
        progress = BgProgress(enabled=show_progress and restart)
        if missing:
            xbmc.log(f"[EPG] No EPG for {sorted(missing)} - rebuilding", xbmc.LOGINFO)
            progress.span(0, 60)
            fetch_and_build_epg(force=True, notify=False, progress=progress)
            progress.span(60, 100)
        if restart:
            restart_pvr_client(progress=progress)
        else:
            progress.close()
        return True
    return False


# {tvgid: file name} of the downloaded logos. Logos keep their extension
def logo_files():
    files = {}
    try:
        names = sorted(os.listdir(common.logos_dir))
    except OSError:
        return files
    for name in names:
        stem, ext = os.path.splitext(name)
        if ext and (stem not in files or ext.lower() == ".png"):
            files[stem] = name
    return files


# Returns the channel ids in the existing EPG file (channels are written first).
def epg_channel_ids():
    ids = set()
    if not os.path.isfile(common.epg_file):
        return ids
    try:
        for _, elem in ET.iterparse(common.epg_file, events=("end",)):
            if elem.tag == "channel":
                ids.add(elem.get("id"))
            elif elem.tag == "programme":
                break  # no more channels
    except (ET.ParseError, OSError):
        pass
    return ids


# Checks if the new IPTV list is different from the old one.
def is_list_equal(file_path, new_list):
    if os.path.isfile(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            old_list = f.read()
        return old_list == new_list
    return False


# Installs (if needed) and enables the IPTV client
def enable_iptv_client(install_timeout=60000):
    if not common.is_addon_installed(IPTV_ADDON_ID):
        common.install_addon(IPTV_ADDON_ID)
        waited = 0
        while not common.is_addon_installed(IPTV_ADDON_ID):
            if waited >= install_timeout:
                xbmc.log(f"[IPTV setup] {IPTV_NAME} was not installed", xbmc.LOGERROR)
                return False
            xbmc.sleep(1000)
            waited += 1000
    if addon_enabled_state(IPTV_ADDON_ID) is False and not set_addon_enabled(
        IPTV_ADDON_ID, True
    ):
        xbmc.log(f"[IPTV setup] Could not enable {IPTV_NAME}", xbmc.LOGERROR)
        return False
    return True


# Opens the IPTV client settings.
def open_iptv_client_settings():
    if enable_iptv_client():
        xbmc.executebuiltin(f"Addon.OpenSettings({IPTV_ADDON_ID})")


INSTANCE_FILE_RE = re.compile(r"instance-settings-(\d+)\.xml$")


# Returns {index: path} of IPTV Simple instance settings files.
def list_instance_files(profile_dir):
    files = {}
    for path in glob.glob(os.path.join(profile_dir, "instance-settings-*.xml")):
        match = INSTANCE_FILE_RE.search(path)
        if match:
            files[int(match.group(1))] = path
    return files


def read_instance_settings(path):
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as ex:
        xbmc.log(f"[IPTV setup] Cannot read {path}: {ex}", xbmc.LOGWARNING)
        return None
    return {s.get("id"): (s.text or "") for s in root.findall("setting")}


# Finds this plugin's instance file (by instance name or M3U path).
def find_instance_file(profile_dir):
    files = list_instance_files(profile_dir)
    for index in sorted(files):
        values = read_instance_settings(files[index])
        if not values:
            continue
        if (
            values.get("kodi_addon_instance_name") == common.Addon_Name
            or values.get("m3uPath") == common.m3u_file
        ):
            return files[index]
    new_index = max(files, default=0) + 1
    path = os.path.join(profile_dir, f"instance-settings-{new_index}.xml")
    xbmc.log(f"[IPTV setup] Creating new settings file: {path}", xbmc.LOGINFO)
    return path


# Writes the given settings into an instance file. Returns True if anything changed.
def update_instance_file(path, settings):
    root = None
    if os.path.isfile(path):
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as ex:
            xbmc.log(
                f"[IPTV setup] Invalid XML in {path}, recreating: {ex}", xbmc.LOGWARNING
            )
    if root is None or root.tag != "settings":
        root = ET.Element("settings")

    changed = False
    if root.get("version") != "2":
        root.set("version", "2")
        changed = True

    existing = {s.get("id"): s for s in root.findall("setting")}
    for key, val in settings.items():
        elem = existing.get(key)
        if elem is None:
            elem = ET.SubElement(root, "setting", {"id": key})
        elif (elem.text or "") == val:
            continue
        elem.text = val
        elem.attrib.pop("default", None)
        changed = True

    if changed:
        if hasattr(ET, "indent"):
            ET.indent(root, space="    ")
        tmp_path = path + ".tmp"
        ET.ElementTree(root).write(tmp_path, encoding="utf-8")
        os.replace(tmp_path, path)
    return changed


# Sets the IPTV client settings.
def set_iptv_client_settings(restart=True):
    if not enable_iptv_client():
        return False
    settings = {
        "kodi_addon_instance_name": common.Addon_Name,
        "kodi_addon_instance_enabled": "true",
        "m3uPathType": "0",
        "m3uPath": common.m3u_file,
        "epgPathType": "0",
        "epgPath": common.epg_file,
        "startNum": "1",
        "m3uRefreshMode": "1",
        "m3uRefreshIntervalMins": "5",
        "timeshiftEnabled": "true",
        "catchupEnabled": "true",
        "catchupDays": "7",
    }
    try:
        iptv_addon = xbmcaddon.Addon(IPTV_ADDON_ID)
        profile_dir = xbmcvfs.translatePath(iptv_addon.getAddonInfo("profile"))
        os.makedirs(profile_dir, exist_ok=True)
        target_file = find_instance_file(profile_dir)
        if update_instance_file(target_file, settings):
            xbmc.log(
                f"[IPTV setup] Updated IPTV settings in {target_file}", xbmc.LOGINFO
            )
            if restart:
                restart_pvr_client()
            return True
        xbmc.log("[IPTV setup] No changes needed in IPTV settings", xbmc.LOGDEBUG)
    except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as ex:
        xbmc.log(f"[IPTV setup] IPTV setup error: {ex}", xbmc.LOGERROR)
    return False
