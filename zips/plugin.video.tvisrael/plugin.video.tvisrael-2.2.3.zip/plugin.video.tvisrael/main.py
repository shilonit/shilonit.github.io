# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl
import requests, threading
import xbmcgui, xbmcplugin, xbmc
import resources.lib.common as common
import resources.lib.channels as channels
import resources.lib.epglist as epg
from resources.lib.url_finder import url_origin, links_file_path

# Global variables
addon_handle = common.get_handle()
channels_list = channels.Tvs

# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f'{sys.argv[0]}?{urlencode(kwargs)}'
    except Exception as e:
        xbmc.log(f'Error creating URL: {e}', xbmc.LOGERROR)
        return ''

# Display the categories list with channels and settings
def categories_list():
    label = common.get_locale_string(30402)
    formatted_label = common.get_label_color(label, bold=True, color="purple")
    xbmcplugin.setPluginCategory(addon_handle, formatted_label)
    xbmcplugin.setContent(addon_handle, 'videos')
    img_tv = common.get_icon_full_path('tv.jpg')
    img_sports = common.get_icon_full_path('sports.jpg')
    channels_name = common.get_label_color(common.get_locale_string(30600), bold=True, color="none")
    settings_name = common.get_label_color(common.get_locale_string(30401), bold=True, color="yellow")
    list_items = []

    # Channels section
    channels_url = get_url(mode=7)
    if channels_url:
        channels_list_item = xbmcgui.ListItem(label=channels_name)
        channels_list_item.setArt({'thumb': img_sports, 'icon': img_sports, 'fanart': img_sports})
        channels_list_item.setInfo('video', {'title': channels_name, 'genre': channels_name, 'mediatype': 'video'})
        list_items.append((channels_url, channels_list_item, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        settings_list_item = xbmcgui.ListItem(label=settings_name)
        settings_list_item.setArt({'thumb': img_tv, 'icon': img_tv, 'fanart': img_tv})
        settings_list_item.setInfo('video', {'title': settings_name, 'genre': settings_name, 'mediatype': 'video'})
        list_items.append((settings_url, settings_list_item, False))

    xbmcplugin.addDirectoryItems(addon_handle , list_items)
    xbmcplugin.endOfDirectory(addon_handle)

# Check if the links file is old and needs to be updated
def update_files():
    if common.is_file_old(common.epgFile):
        epg.fetch_and_save_epg()

    deltaInSec = common.Addon.getSettingInt("updateLinksInterval") * 3600  # Convert hours to seconds
    if common.is_file_old(links_file_path, deltaInSec):
        try:
            common.save_links_json()
        except Exception as e:
            xbmc.log(f"Failed to update links file: {e}", xbmc.LOGERROR)

# Play video from the selected channel
def play_video(channel_nid):
    if not channel_nid:
        xbmc.log('Channel ID is missing.', xbmc.LOGERROR)
        return

    channel = next((ch for ch in channels_list if ch['nid'] == channel_nid), None)
    if not channel:
        xbmc.log(f'Channel with ID {channel_nid} not found.', xbmc.LOGERROR)
        return

    threading.Thread(target=update_files).start()

    try:
        m3u8_link, headers = url_origin(channel_nid, links_file_path)
        if not m3u8_link:
            xbmc.log(f"[play_video] No m3u8 link found for {channel_nid}", xbmc.LOGERROR)
            return

        # For ddy
        if 'mono.m3u8' in m3u8_link:
            if headers and isinstance(headers, dict):
                link = f'{m3u8_link}|{urlencode(headers)}'
            else:
                xbmc.log("[play_video] Headers are not a valid dictionary.", xbmc.LOGERROR)
                link = m3u8_link
            play_item = xbmcgui.ListItem(path=link)

        # With inputstream.adaptive
        else:
            play_item = xbmcgui.ListItem(path=m3u8_link)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('IsLive', 'true')
            play_item.setProperty('StartOffset', 'live')
            play_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            if headers and isinstance(headers, dict):
                play_item.setProperty('inputstream.adaptive.stream_headers', urlencode(headers))

        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=True, listitem=play_item)

    except requests.RequestException as e:
        xbmc.log(f'Network error: {e}', xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f'An unexpected error occurred: {e}', xbmc.LOGERROR)

# Get all channels sorted by user preferences
def get_all_channels():
    for channel in channels_list:
        xbmc.log(f"Checking channel: nid={channel['nid']}, index={channel['index']}", xbmc.LOGDEBUG)
        if not isinstance(channel['index'], int):
            xbmc.log(f"Invalid index value detected: {channel['index']}", xbmc.LOGERROR)

    user_channels = [channel for channel in channels_list if common.get_int_setting(channel['nid'], channel['index']) > 0]
    sorted_channels = sorted(user_channels, key=lambda k: k['index'])
    return sorted_channels

# Create IPTV files and update EPG when needed or launch the addon
def make_iptv_files():
    epg.generate_iptv_list(get_all_channels())
    update_files()

# Perform actions during the first run of the addon
def first_run():
    make_iptv_files()
    epg.set_iptv_client_settings()

# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f'Addon.OpenSettings({common.AddonID})')

# Launch the EPG window
def launch_epg():
    xbmc.executebuiltin('ActivateWindow(TVGuide,pvr://channels/tv)')

# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin('ActivateWindow(pvrsettings)')

# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        mode = params.get('mode')
        url = params.get('url')

        mode_action_map = {
            '-1': categories_list,
            '1': lambda: play_video(url),
            '2': open_settings,
            '3': lambda: (epg.open_iptv_client_settings(), sys.exit()),
            '4': lambda: (make_iptv_files(), sys.exit()),
            '5': lambda: (epg.set_iptv_client_settings(), sys.exit()),
            '6': lambda: epg.fetch_and_save_epg(),
            '7': launch_epg,
            '8': lambda: (open_pvrsettings(), sys.exit()),
            '9': lambda: (first_run(), sys.exit()),
            '10': lambda: common.save_links_json()
        }

        action = mode_action_map.get(mode)
        if action:
            action()
        else:
            xbmc.log(f'Invalid mode value: {mode}', xbmc.LOGERROR)
            sys.exit()
    else:
        categories_list()

if __name__ == '__main__':
    router(sys.argv[2][1:])
