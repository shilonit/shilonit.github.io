# Add-on identity, file names and paths. Kept apart from common.py
import os

from import_xbmc import xbmcaddon, xbmcvfs

Addon_ID = "plugin.video.tvisrael"
Addon_Name = "TV Israel"
Addon = xbmcaddon.Addon(Addon_ID)
Addon_Ver = Addon.getAddonInfo("version")
Addon_Path = Addon.getAddonInfo("path")

M3U_Name = "tvisrael.m3u"
epg_name = "epg.xml"
Settings_Name = "settings.xml"
Channels_list = "channel_list.json"
LOGOS_MAX_AGE = 12 * 3600  # 12 hours

profile_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
logos_dir = xbmcvfs.translatePath(os.path.join(profile_dir, "logos"))
images_dir = xbmcvfs.translatePath(os.path.join(Addon_Path, "resources", "images"))
m3u_file = os.path.join(profile_dir, M3U_Name)
user_settings = os.path.join(profile_dir, Settings_Name)
main_settings = os.path.join(Addon_Path, "resources", Settings_Name)
channels_path = os.path.join(profile_dir, Channels_list)
app_logo = os.path.join(images_dir, "tv.jpg")
epg_file = os.path.join(profile_dir, epg_name)

github_base = "https://raw.githubusercontent.com/shilonit"
github_epg = f"{github_base}/epgtools/main/sport/{epg_name}.gz"
github_chlist = f"{github_base}/epgtools/main/sport/{Channels_list}"

# Make sure profile directory exists
os.makedirs(profile_dir, exist_ok=True)
