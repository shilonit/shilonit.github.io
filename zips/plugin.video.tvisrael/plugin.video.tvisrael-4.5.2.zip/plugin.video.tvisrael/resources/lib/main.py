import os
import re
import sys
from urllib.parse import parse_qsl, urlencode

import constants as const
from import_xbmc import xbmc, xbmcgui, xbmcplugin


# The menu imports only what it needs to show itself (constants is light).
def get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


addon_handle = get_handle()


def lazy_common():
    import common

    return common


def lazy_epg():
    import epglist

    return epglist


# Label in a color ("none" = default color), optionally bold
def get_label_color(text, bold=False, color="none"):
    if bold:
        text = f"[B]{text}[/B]"
    return text if color == "none" else f"[COLOR {color}]{text}[/COLOR]"


def get_addon_icon(name):
    return os.path.join(const.images_dir, name)


def open_window(xml_file):
    dialog = xbmcgui.WindowXMLDialog(xml_file, const.Addon_Path)
    dialog.doModal()
    del dialog


# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f"{sys.argv[0]}?{urlencode(kwargs)}"
    except (TypeError, ValueError) as e:
        xbmc.log(f"Error creating URL: {e}", xbmc.LOGERROR)
        return ""


# Display the categories list with channels and settings
def categories_list():
    title = const.Addon.getLocalizedString(30402)
    xbmcplugin.setPluginCategory(
        addon_handle, get_label_color(title, bold=True, color="purple")
    )
    xbmcplugin.setContent(addon_handle, "videos")
    img_tv = get_addon_icon("tv.jpg")
    img_sports = get_addon_icon("sports.jpg")
    channels_label = const.Addon.getLocalizedString(30504)
    settings_label = const.Addon.getLocalizedString(30401)
    channels_name = get_label_color(channels_label, bold=True, color="none")
    settings_name = get_label_color(settings_label, bold=True, color="yellow")
    items = []

    # Channels section
    channels_url = get_url(mode=7)
    if not channels_url:
        xbmc.log("Failed to create channels URL", xbmc.LOGERROR)
        return

    li = xbmcgui.ListItem(label=channels_name)
    li.setArt({"thumb": img_sports, "icon": img_sports, "fanart": img_sports})
    info = li.getVideoInfoTag()
    info.setTitle(str(channels_label))
    items.append((channels_url, li, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        li = xbmcgui.ListItem(label=settings_name)
        li.setArt({"thumb": img_tv, "icon": img_tv, "fanart": img_tv})
        info = li.getVideoInfoTag()
        info.setTitle(str(settings_label))
        items.append((settings_url, li, False))

    xbmcplugin.addDirectoryItems(addon_handle, items)
    xbmcplugin.endOfDirectory(addon_handle)


# Token in a stream URL: http://<server>:8080/s/{user_token}/{nid}/video.m3u8
TOKEN_RE = re.compile(r"/s/([^/\s]+)/[^/\s]+/video\.m3u8")


# Fetch user token from the playlist using the access key.
def fetch_token_from_access_key():
    import requests

    common = lazy_common()
    playlist_url = common.get_playlist_url()
    if not playlist_url:
        return False

    try:
        r = requests.get(
            playlist_url, headers={"User-Agent": common.user_agent}, timeout=10
        )
    except requests.RequestException as e:
        xbmc.log(f"[TOKEN] Failed fetching playlist: {e}", xbmc.LOGERROR)
        common.notify(30700, 30718)
        return False
    if r.status_code in (401, 403, 404):
        xbmc.log(f"[TOKEN] Access key rejected (HTTP {r.status_code})", xbmc.LOGERROR)
        common.notify(30700, 30716)
        return False
    if not r.ok:
        xbmc.log(f"[TOKEN] Server error (HTTP {r.status_code})", xbmc.LOGERROR)
        common.notify(30700, 30718)
        return False

    match = TOKEN_RE.search(r.text)
    if not match:
        xbmc.log("[TOKEN] Token not found in playlist", xbmc.LOGERROR)
        common.notify(30700, 30716)
        return False

    user_token = match.group(1)
    if common.get_addon_setting("user_token") != user_token:
        const.Addon.setSetting("user_token", user_token)
    xbmc.log(f"[TOKEN] Token stored: {user_token}", xbmc.LOGINFO)
    common.notify(30702, 30717)
    return True


# Perform actions during the first run of the addon
def clean_profile_dir():
    keep_files = {
        const.M3U_Name,
        const.epg_name,
        os.path.basename(const.user_settings),
    }
    try:
        for item in os.listdir(const.profile_dir):
            item_path = os.path.join(const.profile_dir, item)
            if item not in keep_files and os.path.isfile(item_path):
                try:
                    os.remove(item_path)
                    xbmc.log(
                        f"[first_run] Removed leftover file: {item}", xbmc.LOGDEBUG
                    )
                except OSError as e:
                    xbmc.log(f"[first_run] Failed removing {item}: {e}", xbmc.LOGERROR)
    except OSError as e:
        xbmc.log(f"[first_run] Failed cleaning profile dir: {e}", xbmc.LOGERROR)


def first_run():
    clean_profile_dir()
    if not fetch_token_from_access_key():
        xbmc.log(
            "[first_run] Token validation failed – aborting setup", xbmc.LOGWARNING
        )
        return
    common = lazy_common()
    common.channel_list_features()
    common.notify(30500, 30412)


# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f"Addon.OpenSettings({const.Addon_ID})")


# Launch the EPG window
def launch_epg():
    xbmc.executebuiltin("ActivateWindow(TVGuide,pvr://channels/tv)")


# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin("ActivateWindow(pvrsettings)")


# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get("mode")

    actions = {
        "-1": categories_list,
        "1": lambda: (first_run(), sys.exit()),
        "2": open_settings,
        "3": lambda: (lazy_epg().open_iptv_client_settings(), sys.exit()),
        "4": lambda: (
            lazy_common().make_iptv_files(),
            lazy_common().notify(30805, 30413),
            sys.exit(),
        ),
        "5": lambda: (
            lazy_epg().set_iptv_client_settings(),
            lazy_common().notify(30414, 30415),
            sys.exit(),
        ),
        "6": lambda: lazy_epg().fetch_and_build_epg(force=True),
        "7": launch_epg,
        "8": lambda: (open_pvrsettings(), sys.exit()),
        "9": lambda: (lazy_common().check_version(), sys.exit()),
        "10": lambda: open_window("guide-qr.xml"),
        "11": lambda: open_window("register-qr.xml"),
        "12": lambda: lazy_common().download_channel_logos(),
    }

    if mode in actions:
        actions[mode]()
    else:
        if params:
            xbmc.log(f"Invalid mode: {mode}", xbmc.LOGERROR)
            sys.exit()
        else:
            categories_list()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
