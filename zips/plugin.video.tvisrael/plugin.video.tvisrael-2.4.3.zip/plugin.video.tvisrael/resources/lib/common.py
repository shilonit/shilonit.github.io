# -*- coding: utf-8 -*-
import sys, os, io, json, collections, time, random
import requests
from import_xbmc import xbmc, xbmcaddon, xbmcvfs
from UA import userAgents
import epglist as epg

#########################################################
# Common variables and functions
AddonID         = 'plugin.video.tvisrael'
AddonName       = 'TV Israel'
Addon           = xbmcaddon.Addon(AddonID)
AddonVer        = Addon.getAddonInfo('version')
AddonPath       = Addon.getAddonInfo('path')
AddonIcon       = Addon.getAddonInfo('icon')
Old_LinksFile   = 'ddy_url.json'
LinksFile       = 'urls.json'
M3UName         = 'tvisrael.m3u'
EpgName         = 'epg.json'
XmlName         = 'epg.xml'
userAgent       = random.choice(userAgents)

# Define file paths
profileDir      = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
imagesDir       = xbmcvfs.translatePath(os.path.join(AddonPath, 'resources', 'images'))
m3uFile         = os.path.join(profileDir, M3UName)
xmlFile         = os.path.join(profileDir, XmlName)
links_file_path = os.path.join(profileDir, LinksFile)
AppLogo         = os.path.join(imagesDir, 'tv.jpg')
epgFile         = os.path.join(profileDir, EpgName)
github_utl      = 'https://raw.githubusercontent.com/shilonit/epgtools/main/sport'
epg_url         = f'{github_utl}/{EpgName}'

##########################################################

# Make sure profile directory exists
if not os.path.exists(profileDir):
    os.makedirs(profileDir)

# Utility function to safely get handle from arguments
def get_handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1

# Get AddonIcon full path
def get_addon_icon(AddonIcon):
    return os.path.join(imagesDir, AddonIcon)

# Check if an addon is installed
def is_addon_installed(addonid):
    return xbmc.getCondVisibility(f'System.HasAddon({addonid})')

# Install addon
def install_addon(addonid):
    xbmc.executebuiltin(f'InstallAddon({addonid})')

# Check if addon is enabled
def is_addon_enabled(addonid):
    try:
        json_request = (
            f'{{"jsonrpc":"2.0",'
            f'"method":"Addons.GetAddonDetails",'
            f'"params":{{"addonid":"{addonid}", "properties": ["enabled"]}},"id":1}}'
        )
        response = json.loads(xbmc.executeJSONRPC(json_request))

        return response['result']['addon']['enabled']
    except json.JSONDecodeError:
        return False

# Get localized string
def get_locale_string(id):
    return Addon.getLocalizedString(id)

# Get label color
def get_label_color(text, key_color=None, bold=False, color=None):
    if not color:
        color = Addon.getSetting(key_color)
    if bold:
        text = f'[B]{text}[/B]'
    return text if color == 'none' else f'[COLOR {color}]{text}[/COLOR]'

# Read and return settings from addon
def get_addon_setting(key):
    return Addon.getSetting(key)

# Read a list from a file
def read_list(fileName):
    try:
        with io.open(fileName, 'r', encoding='utf-8') as f:
            return json.load(f, object_pairs_hook=collections.OrderedDict)
    except Exception as ex:
        xbmc.log(str(ex), 3)
        return []

# Escape XML special characters
def escape_xml(text):
    if isinstance(text, bytes):
        text = text.decode('utf-8')
    return text.replace('&', '&amp;').replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")

# Check if file is older than a given threshold
def is_file_old(filename, deltaInSec=10800):
    last_update = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
    return (time.time() - last_update) > deltaInSec

# Get integer setting, defaulting if necessary
def get_int_setting(k, v=0):
    setting = Addon.getSetting(k)
    if not setting or not setting.isdigit():
        xbmc.log(f"[get_int_setting] Invalid setting detected for key '{k}', defaulting to {v}", xbmc.LOGWARNING)
        Addon.setSetting(k, str(v))
        return v
    return int(setting)

# Get text content from a file
def get_text_file(filename):
    if os.path.isfile(filename):
        with io.open(filename, 'r', encoding="utf-8") as f:
            return f.read()
    return ''

# Fetches the EPG data and saves it to a file.
def save_links_json():
    # Check if the links file is 'ddy_url.json' and rename it to 'urls.json' - ver > 3.4.2
    old_links_path = os.path.join(profileDir, Old_LinksFile)
    if os.path.exists(old_links_path):
        try:
            os.rename(old_links_path, links_file_path)
            xbmc.log(f"Renamed {Old_LinksFile} to {LinksFile}", xbmc.LOGDINFO)
        except Exception as e:
            xbmc.log(f"Error renaming file: {e}", xbmc.LOGERROR)

    links_file = os.path.join(profileDir, LinksFile)
    links_url = f'{github_utl}/{LinksFile}'
    try:
        response = requests.get(links_url, timeout=10)
        response.raise_for_status()
        json_data = response.json()
        # Ensure json_data is valid before dumping to file
        if isinstance(json_data, (dict, list)):
            with open(links_file, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
            xbmc.log("Fetched data successfully and saved to links_File.", xbmc.LOGDEBUG)
        else:
            xbmc.log("Fetched data is not in JSON format", xbmc.LOGERROR)
    except requests.RequestException as e:
        xbmc.log(f"Error fetching links_File: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Unexpected error while fetching links_File: {e}", xbmc.LOGERROR)

# Check if the links file is old and needs to be updated
def update_files():
    epgDeltaInSec = Addon.getSettingInt("updateEPGInterval") * 3600  # Convert hours to seconds
    if is_file_old(epgFile, epgDeltaInSec):
        try:
            epg.fetch_and_save_epg()
        except Exception as e:
            xbmc.log(f"Failed to update EPG file: {e}", xbmc.LOGERROR)

    linksDeltaInSec = Addon.getSettingInt("updateLinksInterval") * 3600  # Convert hours to seconds
    if is_file_old(links_file_path, linksDeltaInSec):
        try:
            save_links_json()
        except Exception as e:
            xbmc.log(f"Failed to update links file: {e}", xbmc.LOGERROR)


def notify(title_id: int, message_id: int, duration: int = 5000, icon: str = None) -> None:
    title = get_locale_string(title_id)
    message = get_locale_string(message_id)
    # AddonIcon default
    if icon is None:
        icon = AppLogo
    xbmc.executebuiltin(f'Notification({title}, {message}, {duration}, "{icon}")')