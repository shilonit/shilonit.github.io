# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui, xbmcplugin, xbmc
import resources.lib.common as common
import resources.lib.channels as channels
import resources.lib.epglist as epg

# Global variables
addon_handle = common.GetHandle()
channels_list = channels.Tvs

def get_url(**kwargs):
    """Constructs plugin URL with query parameters."""
    return '{0}?{1}'.format(sys.argv[0], urlencode(kwargs))

def CategoriesList():
    xbmcplugin.setPluginCategory(addon_handle, 'הערוצים שלי')
    xbmcplugin.setContent(addon_handle, 'videos')
    img_tv = common.GetIconFullPath('tv.jpg')
    img_sports = common.GetIconFullPath('sports.jpg')
    channels_name = "ערוצים"
    settings_name = "הגדרות"
    list_items = []

    channels_url = get_url(mode=7)
    channels_list_item = xbmcgui.ListItem(label=channels_name)
    channels_list_item.setArt({'thumb': img_sports, 'icon': img_sports, 'fanart': img_sports})
    channels_list_item.setInfo('video', {'title': channels_name, 'genre': channels_name, 'mediatype': 'video'})
    list_items.append((channels_url, channels_list_item, False))


    settings_url = get_url(mode=2)
    settings_list_item = xbmcgui.ListItem(label=settings_name)
    settings_list_item.setArt({'thumb': img_tv, 'icon': img_tv, 'fanart': img_tv})
    settings_list_item.setInfo('video', {'title': settings_name, 'genre': settings_name, 'mediatype': 'video'})
    list_items.append((settings_url, settings_list_item, False))

    xbmcplugin.addDirectoryItems(addon_handle , list_items)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(addon_handle)

def list_videos():
    """Lists videos (channels)."""
    xbmcplugin.setPluginCategory(addon_handle, 'הערוצים שלי')
    xbmcplugin.setContent(addon_handle, 'videos')
    
    list_items = []
    
    for video in channels_list:
        list_item = xbmcgui.ListItem(label=video['name'])
        list_item.setInfo('video', {'title': video['name'], 'genre': video['genre'], 'mediatype': 'video'})
        
        channel_img = common.GetIconFullPath(video['thumb'])
        list_item.setArt({'thumb': channel_img, 'icon': channel_img, 'fanart': channel_img})
        list_item.setProperty('IsPlayable', 'true')
        
        # Constructing the plugin URL with channel_id
        channel_id = video['id']
        list_items.append((get_url(mode=1, url=channel_id), list_item, False))

    xbmcplugin.addDirectoryItems(addon_handle, list_items)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(addon_handle)

def play_video(channel_id):
    """Plays a video specified by channel_id."""
    if channel_id:
#        base_url = f'https://ddy1.mizhls.ru/ddy1/premium{channel_id}/playlist.m3u8'
        base_url = f'https://webhdrunns.mizhls.ru/lb/premium{channel_id}/index.m3u8'
#        base_url = f'https://ddy1.mizhls.ru/ddy1/premium{channel_id}/tracks-v1a1/mono.m3u8'
#        base_url = f'https://eu-fls4.mizhls.ru/eu-fls4/premium{channel_id}/playlist.m3u8'

        headers = {
             'Accept': '*/*',
             'Accept-Language': 'q=0.8,en-US;q=0.5,en;q=0.3',
             'Accept-Encoding': 'gzip, deflate, br, zstd',
             'DNT': '1',
             'Connection': 'keep-alive',
             'Referer': 'https://lewblivehdplay.ru/',
             'Origin': 'https://lewblivehdplay.ru',
             'User-Agent': common.userAgent
    }
   
        link = f'{base_url}|{urlencode(headers)}'
        
        play_item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=True, listitem=play_item)

def GetAllChannels():
	all_channels = []
	channels = channels_list
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] != 0:
			all_channels.append(channel)
	all_channels = sorted(all_channels, key=lambda k: k['index'])
	return all_channels

def MakeIPTVfiles():
	epg.MakeIPTVlist(GetAllChannels())
	if common.isFileOld(common.epgFile):
		epg.GetEPG()
	epg.MakeChannelsGuide()

def open_settings():
    xbmc.executebuiltin('Addon.OpenSettings(' + common.AddonID + ')')

def launch_EPG():
     xbmc.executebuiltin('ActivateWindow(TVGuide,pvr://channels/tv/TVIsrael)')

def router(paramstring):
    """Routes requests based on parameters."""
    params = dict(parse_qsl(paramstring))
    
    if params:
        mode = params.get('mode')
        url = params.get('url')
        if mode == '-1':
            CategoriesList()
        elif mode == '1' and url:
            play_video(url)
        elif mode == '2':
            open_settings()
        elif mode == '3':
            epg.OpenIptvClientSettings()
        elif mode == '4':
            MakeIPTVfiles()
            sys.exit()
        elif mode == '5':
            epg.SetIptvClientSettings()
        elif mode == '6':
            epg.GetEPG()
        elif mode == '7':
            launch_EPG()
        else:
            raise ValueError(f'Invalid mode value: {mode}')
    else:
        CategoriesList()

if __name__ == '__main__':
    router(sys.argv[2][1:])