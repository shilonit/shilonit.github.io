# -*- coding: utf-8 -*-
import base64
import json
import re
from typing import Optional, Tuple
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

import common
import channels
from import_xbmc import xbmc

# Global parameters.
BASE_URL = "https://daddylive.sx"
TOP_URL  = "https://topembed.pw/"

channels_list = channels.Tvs
session = requests.Session()

def get_value(key: str) -> Optional[str]:
    try:
        with open(common.links_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get(key)
    except Exception as e:
        xbmc.log(f"[get_value] Error reading {key}: {e}", xbmc.LOGERROR)
        return None


def get_url(key: str) -> str:
    global BASE_URL, TOP_URL

    globals_map = {
        "base_url": "BASE_URL",
        "top_url": "TOP_URL"
    }

    if key in globals_map:
        url = get_value(key)
        if url:
            globals()[globals_map[key]] = url

        return globals()[globals_map[key]]

    return ""


def build_iframe_url(base_iframe_url: str, srv: str, channel_id: str) -> Optional[str]:
    if not base_iframe_url:

        return None
    base_iframe_url = base_iframe_url.rstrip("/")

    if srv in ("ddy", "ap2"):
        # Path base on srv
        path = "premiumtv/daddyhd.php" if srv == "ddy" else "maxsport.php"
        return f"{base_iframe_url}/{path}?id={channel_id}"
    elif srv == "top":
        top_url = get_url("top_url")
        return f"{top_url}/channel/YesSport{channel_id}[Israel]"

    return None


def initialize_globals(channel_id: str, srv: str) -> Optional[dict]:
    base_url = get_url("base_url")
    base_iframe_url = get_value("iframe_url")
    iframe_url = build_iframe_url(base_iframe_url, srv, channel_id)
    ddy_final = get_value("ddy_final")
    if not iframe_url:
        xbmc.log("initialize_globals: failed to build iframe_url", xbmc.LOGERROR)
        return None

    page_content = fetch_with_retries(iframe_url)
    if not page_content:
        xbmc.log("initialize_globals: failed to fetch iframe content", xbmc.LOGERROR)
        return None

    try:
        auth = extract_auth_data(page_content) or {}
        channel_key = auth.get("channel_key")
        if not channel_key and srv == "ddy":
            channel_key = "premium" + str(channel_id)

        origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"

        return {
            "page_content": page_content,
            "channel_key": channel_key,
            "auth_ts": auth.get("auth_ts"),
            "auth_rnd": auth.get("auth_rnd"),
            "auth_sig": auth.get("auth_sig"),
            "auth_url": auth.get("auth_url"),
            "origin": origin,
            "base_url": base_url,
            "iframe_url": iframe_url,
            "ddy_final": ddy_final,
        }
    except Exception as e:
        xbmc.log(f"initialize_globals: error extracting auth: {e}", xbmc.LOGERROR)
        return None


def fetch_with_retries(
    url: str, retries: int = 3, delay: int = 1000, headers: Optional[dict] = None
) -> Optional[str]:
    for attempt in range(1, retries + 1):
        try:
            res = session.get(url, headers=headers, timeout=5)
            res.raise_for_status()
            return res.text
        except Exception as e:
            xbmc.log(f"[fetch_with_retries] {attempt}/{retries} failed for {url} headers {headers}: {e}", xbmc.LOGERROR)
            xbmc.sleep(delay)
    xbmc.log(f"[fetch_with_retries] all {retries} attempts failed for {url}", xbmc.LOGERROR)

    return None

def extract_auth_data(page_content: str) -> dict:
    ck_match = re.search(r'const\s+CHANNEL_KEY\s*=\s*"([^"]+)"', page_content)
    channel_key = ck_match.group(1) if ck_match else None
    xjz_match = re.search(r'const\s+XJZ\s*=\s*"([^"]+)"', page_content)
    if not xjz_match:
        return {}
    try:
        decoded_json = base64.b64decode(xjz_match.group(1)).decode()
        parts = json.loads(decoded_json)
        for k, v in parts.items():
            try:
                val = base64.b64decode(v).decode()
                # Temp fix
                if k == "b_script" and val == "a.php":
                    val = "auth.php"
                parts[k] = val
            except:
                pass
        return {
            "channel_key": channel_key,
            "auth_ts": parts.get("b_ts"),
            "auth_rnd": parts.get("b_rnd"),
            "auth_sig": parts.get("b_sig"),
            "auth_url": (parts.get("b_host") or "") + (parts.get("b_script") or "")
        }
    except Exception as e:
        print(f"[extract_auth_data] Error extracting auth data: {e}")
        return {}


def authenticate(channel_key, auth_ts, auth_rnd, auth_sig, auth_url, ddy_final, headers: Optional[dict] = None) -> bool:
    if not auth_url:
        xbmc.log("[authenticate] missing auth_url", xbmc.LOGERROR)
        return False

    url = f"{auth_url}?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    if headers is None:
        headers = {}
    headers["Host"] = ddy_final or ""
    txt = fetch_with_retries(url, headers=headers)
    if not txt:
        return False
    try:
        data = json.loads(txt)
        return data.get("status") == "ok"
    except:
        xbmc.log("authenticate: invalid JSON", xbmc.LOGERROR)

        return False


def get_server_key(channel_key, origin) -> Optional[str]:
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        data = session.get(url, timeout=5).json()
        return data.get("server_key")
    except Exception as e:
        xbmc.log(f"get_server_key: {e}", xbmc.LOGERROR)

        return None


def build_m3u8_url(channel_key, server_key, dynamic_domain) -> str:
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"


def build_headers(iframe_url: str) -> dict:
    parsed = urlparse(iframe_url)
    origin = f"{parsed.scheme}://{parsed.netloc}"
    return {
        "Origin": origin,
        "Referer": origin + "/",
        "User-Agent": common.user_agent
    }


def process_iframe_url(iframe_url: str, ddy_final: Optional[str]) -> Tuple[Optional[str], Optional[dict]]:
    page_content = fetch_with_retries(iframe_url)
    if not page_content:
        return None, None
    auth = extract_auth_data(page_content)
    server_key = get_server_key(auth["channel_key"], f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}")
    if not server_key:
        return None, None
    url = build_m3u8_url(auth["channel_key"], server_key, ddy_final)
    headers = build_headers(iframe_url)

    return url, headers


def get_m3u8_ddy(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    channel = next((ch for ch in channels_list if ch["id"] == channel_id), None)
    srv = channel.get("srv", "ddy") if channel else "ddy"
    globals_data = initialize_globals(channel_id, srv)
    if not globals_data:
        xbmc.log(f"[get_m3u8_ddy] Failed to initialize globals for srv={srv}", xbmc.LOGERROR)
        return None, {}
    iframe_url = globals_data.get("iframe_url")
    if not iframe_url:
        xbmc.log(f"[get_m3u8_ddy] Could not build iframe URL for srv={srv}", xbmc.LOGERROR)
        return None, {}

    return process_iframe_url(iframe_url, globals_data["ddy_final"])


def normalize_stream_id(stream_id: str) -> str:
    if not stream_id:
        return ""
    m = re.match(r"^(SPORT\d+)([A-Z]+)?IL$", stream_id.upper())
    return m.group(1) + m.group(2) if m and m.group(2) else stream_id


def extract_m3u8_url(stream_id: str) -> Tuple[Optional[str], dict]:
    AP_URL = get_value("ap_url")
    hdrs   = {"User-Agent": common.user_agent, "Referer": AP_URL}
    sid    = normalize_stream_id(stream_id)
    r1     = session.get(f"{AP_URL}/{stream_id.lower()}.php", headers=hdrs).text
    first  = BeautifulSoup(r1, "html.parser").find("iframe", src=re.compile(f"stream={sid}", re.I))
    url2   = first["src"]

    if url2.startswith("//"):
        url2 = "https:" + url2
    r2          = session.get(url2, headers=hdrs).text
    second      = BeautifulSoup(r2, "html.parser").find("iframe", src=re.compile(f"{sid}/embed", re.I))["src"]
    dom         = urlparse(second)
    token_match = re.search(r"token=([A-Za-z0-9\-]+)", second)

    if not token_match:
        xbmc.log("[extract_m3u8_url] Error: token not found", xbmc.LOGERROR)
        return None, hdrs
    token = token_match.group(1)
    final = f"{dom.scheme}://{dom.hostname}/{sid}/index.fmp4.m3u8?token={token}"

    return final, hdrs


def url_origin(channel_nid) -> Tuple[Optional[str], Optional[dict]]:
    ch = next((x for x in channels_list if x["nid"] == channel_nid), None)
    if not ch:
        xbmc.log(f"url_origin: nid {channel_nid} not found", xbmc.LOGERROR)
        return None, None

    channel_id, srv = ch["id"], ch["srv"]
    xbmc.log(f"url_origin: id={channel_id}, srv={srv}", xbmc.LOGDEBUG)

    if srv in ("ddy", "ap2", "top"):
        glob = initialize_globals(channel_id, srv)
        if not glob:
            xbmc.log("url_origin: failed to initialize globals", xbmc.LOGERROR)
            return None, None

        headers = build_headers(glob["iframe_url"])

        if not authenticate(
            glob["channel_key"],
            glob["auth_ts"],
            glob["auth_rnd"],
            glob["auth_sig"],
            glob["auth_url"],
            glob["ddy_final"],
            headers=headers,
        ):
            xbmc.log("url_origin: auth failed", xbmc.LOGERROR)
            return None, None
        return get_m3u8_ddy(channel_id)

    if srv == "ap":
        return extract_m3u8_url(channel_id)

    xbmc.log(f"url_origin: unsupported srv {srv}", xbmc.LOGERROR)
    return None, None
