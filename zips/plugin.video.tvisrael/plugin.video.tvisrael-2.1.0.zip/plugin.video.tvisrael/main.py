# -*- coding: utf-8 -*-
import sys, requests
import xbmcgui, xbmcplugin, xbmc
import resources.lib.common as common
import resources.lib.channels as channels
import resources.lib.epglist as epg
from resources.lib.url_finder import url_origin, github_url
from urllib.parse import urlencode, parse_qsl

# Global variables
addon_handle = common.GetHandle()
channels_list = channels.Tvs

# Create a URL with parameters
def get_url(**kwargs):
    try:
        return f'{sys.argv[0]}?{urlencode(kwargs)}'
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Error creating URL: {e}')
        return ''

# Display the categories list with channels and settings
def CategoriesList():
    xbmcplugin.setPluginCategory(addon_handle, common.GetLabelColor(common.GetLocaleString(30402), bold=True, color="purple"))
    xbmcplugin.setContent(addon_handle, 'videos')
    img_tv = common.GetIconFullPath('tv.jpg')
    img_sports = common.GetIconFullPath('sports.jpg')
    channels_name = common.GetLabelColor(common.GetLocaleString(30600), bold=True, color="none")
    settings_name = common.GetLabelColor(common.GetLocaleString(30401), bold=True, color="yellow")
    list_items = []
    
    # Channels section
    channels_url = get_url(mode=7)
    if channels_url:
        channels_list_item = xbmcgui.ListItem(label=channels_name)
        channels_list_item.setArt({'thumb': img_sports, 'icon': img_sports, 'fanart': img_sports})
        channels_list_item.setInfo('video', {'title': channels_name, 'genre': channels_name, 'mediatype': 'video'})
        list_items.append((channels_url, channels_list_item, False))

    # Settings section
    settings_url = get_url(mode=2)
    if settings_url:
        settings_list_item = xbmcgui.ListItem(label=settings_name)
        settings_list_item.setArt({'thumb': img_tv, 'icon': img_tv, 'fanart': img_tv})
        settings_list_item.setInfo('video', {'title': settings_name, 'genre': settings_name, 'mediatype': 'video'})
        list_items.append((settings_url, settings_list_item, False))

    xbmcplugin.addDirectoryItems(addon_handle , list_items)
    xbmcplugin.endOfDirectory(addon_handle)

# Play video from the selected channel
def play_video(channel_id):
    if not channel_id:
        xbmcgui.Dialog().ok('Error', 'Channel ID is missing.')
        return

    channel = next((ch for ch in channels_list if ch['id'] == channel_id), None)
    if not channel:
        xbmcgui.Dialog().ok('Error', f'Channel with ID {channel_id} not found.')
        return

    srv = channel['srv']
    try:
        m3u8_link, origin = url_origin(channel_id, srv, github_url)
        headers = {
            'Accept': '*/*',
            'Accept-Language': 'q=0.8,en-US;q=0.5,en;q=0.3',
            'Connection': 'keep-alive',
            'Origin': origin,
            'Referer': origin + '/',
            'User-Agent': common.userAgent
        }

        link = f'{m3u8_link}|{urlencode(headers)}'
        play_item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(handle=addon_handle, succeeded=True, listitem=play_item)

    except requests.RequestException as e:
        xbmcgui.Dialog().ok('Error', f'Network error: {e}')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'An unexpected error occurred: {e}')

# Get all channels sorted by user preferences
def GetAllChannels():
    user_channels = [channel for channel in channels_list if (common.GetIntSetting(channel['nid'], channel['index']) != 0)]
    sorted_channels = sorted(user_channels, key=lambda k: k['index'])
    return sorted_channels

# Create IPTV files and update EPG
def MakeIPTVfiles():
    epg.generate_iptv_list(GetAllChannels())
    if common.isFileOld(common.epgFile):
        epg.fetch_and_save_epg()
    epg.generate_channels_guide()

# Perform actions during the first run of the addon
def first_run():
    MakeIPTVfiles()
    epg.set_iptv_client_settings()

# Open the addon settings
def open_settings():
    xbmc.executebuiltin(f'Addon.OpenSettings({common.AddonID})')

# Launch the EPG window
def launch_EPG():
    xbmc.executebuiltin('ActivateWindow(TVGuide,pvr://channels/tv)')

# Open the PVR settings window
def open_pvrsettings():
    xbmc.executebuiltin('ActivateWindow(pvrsettings)')

# Route actions based on the URL parameters
def router(paramstring):
    params = dict(parse_qsl(paramstring))    
    if params:
        mode = params.get('mode')
        url = params.get('url')
        
        mode_action_map = {
            '-1': CategoriesList,
            '1': lambda: play_video(url),
            '2': open_settings,
            '3': lambda: (epg.open_iptv_client_settings(), sys.exit()),
            '4': lambda: (MakeIPTVfiles(), sys.exit()),
            '5': lambda: (epg.set_iptv_client_settings(), sys.exit()),
            '6': lambda: epg.fetch_and_save_epg(),
            '7': launch_EPG,
            '8': lambda: (open_pvrsettings(), sys.exit()),
            '9': lambda: (first_run(), sys.exit())
        }
        
        action = mode_action_map.get(mode)
        if action:
            action()
        else:
            xbmcgui.Dialog().ok('Error', f'Invalid mode value: {mode}')
            sys.exit()
    else:
        CategoriesList()

if __name__ == '__main__':
    router(sys.argv[2][1:])
