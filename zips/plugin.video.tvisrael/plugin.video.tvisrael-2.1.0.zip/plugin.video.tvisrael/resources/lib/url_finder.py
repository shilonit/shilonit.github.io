import requests, re, time
from bs4 import BeautifulSoup
from urllib.parse import urlparse

# URL of the GitHub config file
github_url = 'https://raw.githubusercontent.com/shilonit/epgtools/refs/heads/main/sport/ddy_url.json'

# Set up session for persistent connections
session = requests.Session()

# Extracts m3u8 link from the script tags in the page's HTML.
def extract_m3u8_from_script(soup):
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    return None

# Fetch the content of the URL with retry mechanism in case of failure.
def fetch_with_retries(url, retries=3, delay=2):
    for attempt in range(1, retries + 1):
        try:
            response = session.get(url, timeout=5)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            print(f"Attempt {attempt} failed for {url}: {e}")
            if attempt < retries:
                time.sleep(1)  # Exponential backoff
            else:
                print(f"Failed after {retries} attempts for: {url}")
                return None
    return None

# Extracts the channel key from the page content.
def extract_channel_key(page_content):
    match = re.search(r'var channelKey = "(.*?)";', page_content)
    if match:
        return match.group(1)
    else:
        raise ValueError("channelKey Not Found in HTML Page")

# Get the server_key by calling the server_lookup API.
def get_server_key(channel_key, origin):
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        response = session.get(url)
        response.raise_for_status()
        data = response.json()
        server_key = data.get("server_key")
        if server_key:
            return server_key
        else:
            raise ValueError("No server_key received from API")
    except requests.RequestException as e:
        print(f"Error fetching server_key: {e}")
        return None

# Build the m3u8 URL based on the server key.
def build_m3u8_url(channel_key, server_key):
    return f"https://{server_key}new.iosplayer.ru/{server_key}/{channel_key}/mono.m3u8"

# Process the iframe URL to extract the m3u8 link.
def process_iframe_url(iframe_url, channel_id):
    page_content = fetch_with_retries(iframe_url)
    if page_content:
        try:
            channel_key = extract_channel_key(page_content)
            origin = urlparse(iframe_url).scheme + "://" + urlparse(iframe_url).netloc
            server_key = get_server_key(channel_key, origin)
            if server_key:
                return build_m3u8_url(channel_key, server_key), origin
        except Exception as e:
            print(f"Error processing iframe URL for channel {channel_id}: {e}")
    return None, None

# Get the m3u8 link for 'ddy' service.
def get_m3u8_ddy(channel_id, github_url=None):
    if github_url:
        m3u8_link, origin = get_m3u8_from_github(channel_id, github_url)
        if m3u8_link:
            return m3u8_link, origin

    urls = [f'https://{domain}/tele/stream-{channel_id}.php' for domain in ['daddylive.sx', 'miztv.ru']]
    
    for url in urls:
        page_content = fetch_with_retries(url)
        if page_content:
            soup = BeautifulSoup(page_content, 'html.parser')
            iframe = soup.find('iframe')
            if iframe and iframe.has_attr('src'):
                iframe_src = iframe['src']
                m3u8_link, origin = process_iframe_url(iframe_src, channel_id)
                if m3u8_link:
                    return m3u8_link, origin
    return None, None

# Get the iframe URL from GitHub configuration.
def get_iframe_url_from_github(github_url):
    try:
        response = session.get(github_url)
        response.raise_for_status()
        config = response.json()
        iframe_url = config.get('iframe_url')
        if iframe_url:
            return iframe_url
        else:
            print("No iframe URL found in GitHub config.")
            return None
    except (requests.RequestException, ValueError) as e:
        print(f"Error fetching config from GitHub: {e}")
        return None

# Get the m3u8 link by processing iframe URL from GitHub config.
def get_m3u8_from_github(channel_id, github_url):
    iframe_url = get_iframe_url_from_github(github_url)
    if iframe_url:
        iframe_url = iframe_url.format(channel_id=channel_id)  
        return process_iframe_url(iframe_url, channel_id)
    return None, None

# Get the m3u8 URL based on the service type.
def url_origin(channel_id, srv, github_url=None):
    if srv == 'ddy':
        return get_m3u8_ddy(channel_id, github_url)
    else:
        raise ValueError('Unsupported service type.')