import xbmc
from time import time

end_pause = time() + 10
monitor = xbmc.Monitor()

while not monitor.abortRequested() and time() < end_pause:
    monitor.waitForAbort(1)

if time() >= end_pause:
    refreshCommand = 'RunPlugin(plugin://plugin.video.tvisrael/?mode=4)'
    xbmc.executebuiltin(refreshCommand)
    xbmc.executebuiltin('AlarmClock(tvisrael,{0},10:00:00,silent,loop)'.format(refreshCommand))