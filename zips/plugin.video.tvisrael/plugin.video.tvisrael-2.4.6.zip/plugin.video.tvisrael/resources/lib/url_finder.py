# -*- coding: utf-8 -*-
import json, re, requests, base64
from typing import Optional, Tuple
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import common, channels
from import_xbmc import xbmc

channels_list = channels.Tvs
session       = requests.Session()

# Global parameters.
BASE_URL = "https://daddylive.sx"
TOP_URL  = "https://topembed.pw/"

def get_value(key: str) -> Optional[str]:
    try:
        with open(common.links_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get(key)
    except Exception as e:
        xbmc.log(f"[get_value] Error reading {key}: {e}", xbmc.LOGERROR)
        return None

def get_url(key: str) -> str:
    global BASE_URL, TOP_URL

    globals_map = {
        'base_url': 'BASE_URL',
        'top_url': 'TOP_URL'
    }

    if key in globals_map:
        url = get_value(key)
        if url:
            globals()[globals_map[key]] = url
        return globals()[globals_map[key]]
    return ""

def build_iframe_url(base_iframe_url: str, srv: str, channel_id: str) -> Optional[str]:
    if not base_iframe_url:
        return None
    base_iframe_url = base_iframe_url.rstrip('/')
    if srv == 'ddy' or srv == 'ap2':
        # Path base on srv
        path = 'premiumtv/daddyhd.php' if srv == 'ddy' else 'maxsport.php'
        return f"{base_iframe_url}/{path}?id={channel_id}"
    elif srv == 'top':
        top_url = get_url('top_url')
        return f"{top_url}/channel/YesSport{channel_id}[Israel]"
    return None

def initialize_globals(channel_id: str, srv: str) -> Optional[dict]:
    base_url = get_url('base_url')
    base_iframe_url = get_value('iframe_url')
    iframe_url = build_iframe_url(base_iframe_url, srv, channel_id)
    if not iframe_url:
        xbmc.log("initialize_globals: failed to build iframe_url", xbmc.LOGERROR)
        return None

    page_content = fetch_with_retries(iframe_url)
    if not page_content:
        xbmc.log("initialize_globals: failed to fetch iframe content", xbmc.LOGERROR)
        return None

    try:
        auth = extract_auth_data(page_content)
        origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
        return {
            "page_content": page_content,
            "channel_key":  auth["channel_key"],
            "auth_ts":      auth["auth_ts"],
            "auth_rnd":     auth["auth_rnd"],
            "auth_sig":     auth["auth_sig"],
            "origin":       origin,
            "base_url":     base_url,
            "iframe_url":   iframe_url
        }
    except Exception as e:
        xbmc.log(f"initialize_globals: error extracting auth: {e}", xbmc.LOGERROR)
        return None

def fetch_with_retries(url: str, retries: int = 3, delay: int = 1000, headers: Optional[dict] = None) -> Optional[str]:
    for attempt in range(1, retries+1):
        try:
            res = session.get(url, headers=headers, timeout=5)
            res.raise_for_status()
            return res.text
        except Exception as e:
            xbmc.log(f"[fetch_with_retries] {attempt}/{retries} failed for {url} headers {headers}: {e}", xbmc.LOGERROR)
            xbmc.sleep(delay)
    xbmc.log(f"[fetch_with_retries] all {retries} attempts failed for {url}", xbmc.LOGERROR)
    return None

def extract_auth_data(page_content: str) -> dict:
    def extract_var(name):
        p = rf'var\s+{name}\s*=\s*atob\("([^"]+)"\)'
        m = re.search(p, page_content)
        return base64.b64decode(m.group(1)).decode() if m else None

    m = re.search(r'var\s+channelKey\s*=\s*"([^"]+)"', page_content)
    return {
        "channel_key": m.group(1) if m else None,
        "auth_ts":     extract_var("__c"),
        "auth_rnd":    extract_var("__d"),
        "auth_sig":    extract_var("__e"),
    }

def authenticate(channel_key, auth_ts, auth_rnd, auth_sig, headers: Optional[dict] = None) -> bool:
    auth_url       = get_value('auth_url')
    dynamic_domain = get_value('ddy_final')
    if not auth_url:
        xbmc.log("authenticate: missing auth_url", xbmc.LOGERROR)
        return False
    url = f"https://{auth_url}{dynamic_domain}/auth.php?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}"
    if headers is None:
        headers = {}
    headers['Host'] = dynamic_domain
    txt = fetch_with_retries(url, headers=headers)
    if not txt:
        return False
    try:
        data = json.loads(txt)
        return data.get("status")=="ok"
    except:
        xbmc.log("authenticate: invalid JSON", xbmc.LOGERROR)
        return False

def get_server_key(channel_key, origin) -> Optional[str]:
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        data = session.get(url, timeout=5).json()
        return data.get("server_key")
    except Exception as e:
        xbmc.log(f"get_server_key: {e}", xbmc.LOGERROR)
        return None

def build_m3u8_url(channel_key, server_key, dynamic_domain) -> str:
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"

def build_headers(iframe_url: str, final_url: Optional[str] = None) -> dict:
    origin = f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}"
    host   = urlparse(final_url).netloc if final_url else "dady.com"
    return {
        'Origin':     origin,
        'Referer':    origin + '/',
        'User-Agent': common.user_agent
    }

def process_iframe_url(iframe_url: str) -> Tuple[Optional[str], Optional[dict]]:
    page_content = fetch_with_retries(iframe_url)
    if not page_content:
        return None, None
    auth = extract_auth_data(page_content)
    server_key = get_server_key(auth["channel_key"], f"{urlparse(iframe_url).scheme}://{urlparse(iframe_url).netloc}")
    if not server_key:
        return None, None
    dom = get_value('ddy_final')
    url = build_m3u8_url(auth["channel_key"], server_key, dom)
    headers = build_headers(iframe_url, url)
    return url, headers

def get_m3u8_ddy(channel_id: str) -> Tuple[Optional[str], Optional[dict]]:
    channel = next((ch for ch in channels_list if ch['id'] == channel_id), None)
    srv = channel.get('srv', 'ddy') if channel else 'ddy'
    globals_data = initialize_globals(channel_id, srv)
    if not globals_data:
        xbmc.log(f"[get_m3u8_ddy] Failed to initialize globals for srv={srv}", xbmc.LOGERROR)
        return None, {}
    iframe_url = globals_data.get("iframe_url")
    if not iframe_url:
        xbmc.log(f"[get_m3u8_ddy] Could not build iframe URL for srv={srv}", xbmc.LOGERROR)
        return None, {}
    return process_iframe_url(iframe_url)

def normalize_stream_id(stream_id: str) -> str:
    m = re.match(r'^(SPORT\d+)([A-Z]+)?IL$', stream_id.upper())
    return m.group(1)+m.group(2) if m and m.group(2) else stream_id

def extract_m3u8_url(stream_id: str) -> Tuple[Optional[str], dict]:
    AP_URL = get_value('ap_url')
    hdrs   = {'User-Agent': common.user_agent, 'Referer': AP_URL}
    sid    = normalize_stream_id(stream_id)
    r1     = session.get(f"{AP_URL}/{stream_id.lower()}.php", headers=hdrs).text
    first  = BeautifulSoup(r1,'html.parser').find("iframe", src=re.compile(f"stream={sid}",re.I))
    url2   = first["src"]
    if url2.startswith("//"): url2="https:"+url2
    r2     = session.get(url2, headers=hdrs).text
    second = BeautifulSoup(r2,'html.parser').find("iframe", src=re.compile(f"{sid}/embed",re.I))["src"]
    dom    = urlparse(second)
    token  = re.search(r'token=([A-Za-z0-9\-]+)', second).group(1)
    final  = f"{dom.scheme}://{dom.hostname}/{sid}/index.fmp4.m3u8?token={token}"
    return final, hdrs

def url_origin(channel_nid) -> Tuple[Optional[str], Optional[dict]]:
    ch = next((x for x in channels_list if x['nid']==channel_nid), None)
    if not ch:
        xbmc.log(f"url_origin: nid {channel_nid} not found", xbmc.LOGERROR)
        return None, None

    channel_id, srv = ch['id'], ch['srv']
    xbmc.log(f"url_origin: id={channel_id}, srv={srv}", xbmc.LOGDEBUG)

    if srv in ('ddy','ap2','top'):
        glob = initialize_globals(channel_id, srv)
        if not glob:
            xbmc.log("url_origin: failed to initialize globals", xbmc.LOGERROR)
            return None, None

        headers = build_headers(glob["iframe_url"])

        if not authenticate(glob["channel_key"], glob["auth_ts"], glob["auth_rnd"], glob["auth_sig"], headers=headers):
            xbmc.log("url_origin: auth failed", xbmc.LOGERROR)
            return None, None

        return get_m3u8_ddy(channel_id)

    if srv == 'ap':
        return extract_m3u8_url(channel_id)

    xbmc.log(f"url_origin: unsupported srv {srv}", xbmc.LOGERROR)
    return None, None
