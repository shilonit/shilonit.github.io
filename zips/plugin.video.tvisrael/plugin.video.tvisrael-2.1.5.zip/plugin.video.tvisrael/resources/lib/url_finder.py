import os, json, time, re
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import resources.lib.common as common
import requests
import xbmc

# Set up session for persistent connections
session = requests.Session()

# Url of the links file containing the ddy URL
links_file_path = os.path.join(common.profileDir, 'ddy_url.json')

def extract_m3u8_from_script(soup):
    """
    Extracts the m3u8 link from the script tags in the page's HTML.

    Args:
    soup (BeautifulSoup): The BeautifulSoup object containing the parsed HTML.

    Returns:
    str: The extracted m3u8 link, or None if not found.
    """
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'source:' in script.text:
            start = script.text.find("source: '") + len("source: '")
            end = script.text.find("'", start)
            return script.text[start:end]
    return None

def fetch_with_retries(url, retries=3):
    """
    Fetches the content of the URL with a retry mechanism in case of failure.

    Args:
    url (str): The URL to fetch content from.
    retries (int): The number of retries to attempt if the request fails (default is 3).

    Returns:
    str: The content of the page if successful, or None if all attempts fail.
    """
    for attempt in range(1, retries + 1):
        try:
            response = session.get(url, timeout=5)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            xbmc.log(f"Attempt {attempt} failed for {url}: {e}", xbmc.LOGERROR)
            if attempt < retries:
                time.sleep(1)  # Exponential backoff
            else:
                xbmc.log(f"Failed after {retries} attempts for: {url}", xbmc.LOGERROR)
                return None
    return None

def extract_channel_key(page_content):
    """
    Extracts the channel key from the page content using a regular expression.

    Args:
    page_content (str): The HTML content of the page.

    Returns:
    str: The extracted channel key.

    Raises:
    ValueError: If the channel key is not found in the HTML content.
    """
    match = re.search(r'var channelKey = "(.*?)";', page_content)
    if match:
        return match.group(1)
    else:
        raise ValueError("channelKey Not Found in HTML Page")

def get_server_key(channel_key, origin):
    """
    Gets the server key by calling the server_lookup API.

    Args:
    channel_key (str): The channel key to use in the API request.
    origin (str): The origin URL to make the API request to.

    Returns:
    str: The server key, or None if an error occurs.
    """
    url = f"{origin}/server_lookup.php?channel_id={channel_key}"
    try:
        response = session.get(url)
        response.raise_for_status()
        data = response.json()
        server_key = data.get("server_key")
        if server_key:
            return server_key
        else:
            raise ValueError("No server_key received from API")
    except requests.RequestException as e:
        xbmc.log(f"Error fetching server_key: {e}", xbmc.LOGERROR)
        return None

def build_m3u8_url(channel_key, server_key, dynamic_domain):
    """
    Builds the m3u8 URL using the provided server key, dynamic domain, and channel key.

    Args:
    channel_key (str): The channel key.
    server_key (str): The server key obtained from the server lookup.
    dynamic_domain (str): The dynamic domain for the stream.

    Returns:
    str: The full m3u8 URL.
    """
    return f"https://{server_key}{dynamic_domain}/{server_key}/{channel_key}/mono.m3u8"

def process_iframe_url(iframe_url, channel_id, links_file_path=None):
    """
    Processes the iframe URL to extract the m3u8 link by parsing the page content.

    Args:
    iframe_url (str): The iframe URL to fetch and process.
    channel_id (str): The channel ID.
    links_file_path (str, optional): The path to the links file containing dynamic domains.

    Returns:
    tuple: A tuple containing the m3u8 link and the origin URL, or (None, None) if an error occurs.
    """
    page_content = fetch_with_retries(iframe_url)
    if page_content:
        try:
            channel_key = extract_channel_key(page_content)
            origin = urlparse(iframe_url).scheme + "://" + urlparse(iframe_url).netloc
            server_key = get_server_key(channel_key, origin)
            if server_key:
                # If links_file_path is provided, try fetching the dynamic domain from links file
                if links_file_path:
                    dynamic_domain = get_dynamic_domain_from_links_file(links_file_path)
                else:
                    # Otherwise, find dynamic domain using regex
                    dynamic_domain = find_dynamic_domain(page_content)

                return build_m3u8_url(channel_key, server_key, dynamic_domain), origin
        except Exception as e:
            xbmc.log(f"Error processing iframe URL for channel {channel_id}: {e}", xbmc.LOGERROR)
    return None, None

def find_dynamic_domain(page_content):
    """
    Finds the dynamic domain from the page content using regex.

    Args:
    page_content (str): The HTML content of the page.

    Returns:
    str: The dynamic domain, or a default domain if not found.
    """
    pattern = r'"https:\/\/" \+ ([^top1][a-zA-Z0-9_-]+) \+ "([a-zA-Z0-9-]+\.[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+)\/" \+ \1 \+ "\/" \+ ([a-zA-Z0-9_-]+) \+ "\/mono\.m3u8"'
    match = re.search(pattern, page_content)
    if match:
        return match.group(2)
    return "new.koskoros.ru"  # Default domain if none found

def get_m3u8_ddy(channel_id, links_file_path=None):
    """
    Gets the m3u8 link for the 'ddy' service by processing the iframe URL.

    Args:
    channel_id (str): The channel ID for the stream.
    links_file_path (str, optional): The path to the links file containing iframe URLs and dynamic domains.

    Returns:
    tuple: A tuple containing the m3u8 link and the origin URL, or (None, None) if an error occurs.
    """
    if links_file_path:
        m3u8_link, origin = get_m3u8_from_links_file(channel_id, links_file_path)
        if m3u8_link:
            return m3u8_link, origin

    urls = [
        f'https://{domain}/tele/stream-{channel_id}.php'
        for domain in ['daddylive.sx', 'miztv.ru']
    ]

    for url in urls:
        page_content = fetch_with_retries(url)
        if page_content:
            soup = BeautifulSoup(page_content, 'html.parser')
            iframe = soup.find('iframe')
            if iframe and iframe.has_attr('src'):
                iframe_src = iframe['src']
                m3u8_link, origin = process_iframe_url(iframe_src, channel_id, links_file_path)
                if m3u8_link:
                    return m3u8_link, origin
    return None, None

def get_iframe_url_from_links_file(links_file_path):
    """
    Fetches the iframe URL from the links configuration file.

    Args:
    links_file_path (str): The path to the links config file.

    Returns:
    str: The iframe URL if found, or None if not found or there's an error.
    """
    try:
        with open(links_file_path, 'r') as file:
            config = json.load(file)
            iframe_url = config.get('iframe_url')
            if iframe_url:
                return iframe_url
            else:
                xbmc.log("No iframe URL found in links config.", xbmc.LOGERROR)
                return None
    except (FileNotFoundError, json.JSONDecodeError) as e:
        xbmc.log(f"Error reading links config: {e}", xbmc.LOGERROR)
        return None

def get_dynamic_domain_from_links_file(links_file_path):
    """
    Fetches the dynamic domain from the links configuration file.

    Args:
    links_file_path (str): The path to the links config file.

    Returns:
    str: The dynamic domain if found, or None if not found or there's an error.
    """
    try:
        with open(links_file_path, 'r') as file:
            config = json.load(file)
            dynamic_domain = config.get('ddy_final')
            if dynamic_domain:
                return dynamic_domain
            else:
                xbmc.log("No ddy_final found in links config.", xbmc.LOGERROR)
                return None
    except (FileNotFoundError, json.JSONDecodeError) as e:
        xbmc.log(f"Error reading links config: {e}", xbmc.LOGERROR)
        return None

def get_m3u8_from_links_file(channel_id, links_file_path):
    """
    Get m3u8 link by processing iframe URL from links config.
    """
    iframe_url = get_iframe_url_from_links_file(links_file_path)
    if iframe_url:
        iframe_url = iframe_url.format(channel_id=channel_id)
        return process_iframe_url(iframe_url, channel_id, links_file_path)
    return None, None

# The main entry point to get the m3u8 URL based on the service type.
def url_origin(channel_id, srv, links_file_path=None):
    """
    The main entry point to get the m3u8 URL based on the service type.
    """
    if srv == 'ddy':
        return get_m3u8_ddy(channel_id, links_file_path)
    else:
        raise ValueError('Unsupported service type.')
